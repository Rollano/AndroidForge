# termux-vision (v15 — AndroidForge Build Wrapper & Compatibility)

Includes `gradlew` fallback script alongside the standard Android Gradle project structure for reliable CI builds.
