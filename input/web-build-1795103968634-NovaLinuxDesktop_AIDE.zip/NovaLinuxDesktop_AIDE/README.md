# Nova Linux Desktop — AIDE Android Project

A lightweight Android home launcher with a Linux-desktop inspired interface and an explicit root terminal.

## Included

- Home-screen launcher (`HOME` intent) and normal app-drawer icon
- Desktop-style clock, workspace cards, bottom dock, and searchable app drawer
- File picker and Android Settings shortcuts
- Root terminal that runs a command only after the user taps **RUN**
- `su -c` execution with merged stdout/stderr and exit-code output
- Magisk/SuperSU root authorization check
- Command history (last 20 commands)
- Current working directory remembered between commands
- Quick commands: `id`, `getprop`, `df -h`, and `ls /sdcard`
- No network permission and no third-party library dependency

## Build with AIDE

This is a classic Java Android project layout (manifest + `src/` + `res/` + `project.properties`), not a Gradle-only project.

1. Extract the ZIP into a normal folder on your device.
2. Open AIDE and use **Open existing project** / **Open Android App Project**. Select the extracted `NovaLinuxDesktop_AIDE` folder.
3. If AIDE asks for an Android target that is unavailable, open its SDK settings and install the matching platform, or change `target=android-28` in `project.properties` to an Android platform already installed in AIDE.
4. Tap **Run** to build and install.
5. Press the Android Home button and choose **Nova Linux Desktop**. Select **Always** to make it your default launcher.

If your AIDE build does not directly recognize this folder, create a blank **Android App** project in AIDE first, then copy this project's `AndroidManifest.xml`, `project.properties`, `src/`, and `res/` into the new project (replace the generated files). Keep the package name `com.novalabs.linuxdesktop` consistent.

## Root setup

1. The device must already be rooted. This project does not root the device or bypass the root manager.
2. Open **Root Terminal**. On first use, Magisk/SuperSU should display a superuser request.
3. Approve it, then run:

   ```sh
   id
   ```

4. A successful root session should print an identity containing `uid=0(root)` and show **ROOT: ONLINE**.

The app starts a new `su -c` process per submitted command. It remembers the current working directory and command history, but it does **not** keep a fully interactive shell process open. Full-screen interactive programs such as `top`, `vi`, `nano`, `ssh` password prompts, and other TTY applications are not supported in this first build.

## Command environment

Commands execute in the Android root shell, not in a separate desktop Linux distribution. Android system commands such as `getprop`, `pm`, `settings`, `mount`, `df`, `ls`, and `id` are available depending on the Android ROM. GNU/Linux utilities that are not installed on the device will not magically exist. For a larger Linux userland, install a trusted Linux environment separately (for example, Termux with an appropriate root/chroot setup); this launcher does not bundle Linux packages.

Examples:

```sh
id
getprop ro.build.version.release
uname -a
df -h
ls /sdcard
pm list packages
settings list system
```

## Safety

Every command entered in the terminal is passed to `su -c` with root privileges. Root commands can erase data, break Android, or make the device unbootable. Review commands carefully. Do not run commands copied from unknown sources, and be especially careful with `rm -rf`, `dd`, partition tools, `mount`, and boot or reset commands.

## Project settings

- Package: `com.novalabs.linuxdesktop`
- Minimum SDK: 23 (Android 6.0)
- Compile target configured in AIDE project: Android API 28
- Target SDK: 28 (chosen to keep the classic AIDE project format compatible)
- Language: Java
- External dependencies: none

AIDE versions and SDK bundles differ. This source project is prepared for AIDE's classic Android-app workflow, but the exact build result depends on the SDK/platforms bundled with your AIDE installation.
