# termux-vision (v23 — NetHunter Full-Screen UI & Animations)

- Adds NetHunter-inspired terminal header (`root@kali: /`), box-drawing shell prompt (`┌──(user㉿kali)-[path]
└─$ ▌`), blinking cursor animation, smooth terminal entry animation, and staggered ASCII `neofetch` boot animation.
- Upgrades the bottom extra keys bar into a 2-row key layout (`Esc Alt PgUp Home ^ End ...` / `Ctrl Tab PgDn < v > UNLOCK`) with button press scale animations while keeping the full-screen `ToolsDrawerActivity` (`[]`) and clean drawer.
