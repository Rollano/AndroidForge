package com.example.customterminal;

import android.app.Activity;
import java.util.Arrays;
import java.util.Collections;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Environment;
import android.provider.Settings;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 101;
    private static final int REQ_TOOLS_DRAWER = 77;
    private static final String TERMUX_PACKAGE = "com.termux";
    private static final String RUN_PERMISSION = "com.termux.permission.RUN_COMMAND";
    private static final String DEFAULT_HOME = "/data/data/com.termux/files/home";
    private static final String DEFAULT_REPO_INDEX = "https://packages.termux.dev/apt/termux-main/dists/stable/main/binary-aarch64/Packages";
    private static final String TERMUX_MIRROR_BASE = "https://packages.termux.dev/apt/termux-main";
    private static final AtomicInteger executionIds = new AtomicInteger(1000);
    private static volatile MainActivity activeActivity;

    private static final String[] PALETTE_NAMES = {
        "Classic Slate (Default)",
        "Matrix Dark",
        "Neon Night",
        "Mint Dark",
        "Pure Black + Green"
    };
    private final int[][] palettes = {
        {0xFF546E7A, 0xFF000000, 0xFFFFFFFF, 0xFFB0BEC5, 0xFF263238},
        {0xFF0E2233, 0xFF07111D, 0xFF73FBD3, 0xFF80CBC4, 0xFF112A3A},
        {0xFF2B193D, 0xFF120B1A, 0xFFFF78C8, 0xFFF8BBD0, 0xFF38203A},
        {0xFF1F3324, 0xFF0D140E, 0xFFA6F28A, 0xFFC5E1A5, 0xFF263421},
        {0xFF102810, 0xFF000000, 0xFF39FF14, 0xFF76FF03, 0xFF101F10}
    };
    private static final String[] FONT_NAMES = {"Monospace", "Sans Serif", "Serif", "Casual"};

    private static class TerminalWindow {
        final String id;
        String title;
        final StringBuilder logBuffer = new StringBuilder();
        File workingDir;
        String activeSessionToken;
        int activeExecId = -1;
        boolean activeSessionReceivedLines;
        boolean commandRunning;
        long commandStartedAt = 0L;
        String pendingInstallPackage;
        boolean awaitingConfirm;
        String confirmPromptText;
        String lastLogLine;
        int repeatedLockCount = 0;
        String pendingStandalonePkg;

        TerminalWindow(String id, String title, File dir) {
            this.id = id;
            this.title = title;
            this.workingDir = dir;
        }
    }

    private static class CustomCommand {
        final String name;
        final String command;
        CustomCommand(String name, String command) {
            this.name = name;
            this.command = command;
        }
    }

    private static class AppEntry {
        final String label;
        final String packageName;
        final Drawable icon;
        AppEntry(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    private final ArrayList<TerminalWindow> windows = new ArrayList<>();
    private int activeWindowIndex = 0;

    private final ArrayList<String> commandHistory = new ArrayList<>();
    private int historyCursor = -1;
    private final ArrayList<CustomCommand> customCommands = new ArrayList<>();
    private final ArrayList<String> repoSources = new ArrayList<>();
    private int activeRepoIndex = 0;

    private int palette = 0;
    private int fontFamily = 0;
    private float fontSizeSp = 13f;
    private float pinchBaseFontSize = 13f;
    private boolean isPinching = false;
    private int overlayPercent = 100;

    private boolean ctrlActive = false;
    private boolean altActive = false;
    private Button ctrlKeyBtn;
    private Button altKeyBtn;

    private SharedPreferences preferences;
    private FrameLayout root;
    private ImageView wallpaper;
    private View shade;

    private File standaloneRoot;
    private File standaloneBin;
    private File standaloneUsr;
    private File standaloneHome;
    private File standalonePackagesDir;
    private final ExecutorService bgExecutor = Executors.newCachedThreadPool();

    private LinearLayout topBar;
    private TextView windowSelectorText;
    private LinearLayout windowDropdownChip;
    private TextView menuIconBtn;
    private TextView addWinBtn;
    private TextView closeWinBtn;
    private TextView overflowBtn;

    private ScrollView scroll;
    private LinearLayout terminalContainer;
    private TextView output;
    private LinearLayout mediaPlayerCard;
    private TextView mediaTitleText;
    private TextView mediaStatusText;
    private VideoView inlineVideoView;
    private Button mediaPlayPauseBtn;
    private Button mediaStopBtn;
    private SeekBar mediaSeekBar;
    private MediaPlayer activeAudioPlayer;
    private boolean mediaIsVideo = false;
    private final Runnable mediaProgressUpdater = new Runnable() {
        @Override
        public void run() {
            updateInlineMediaProgress();
            if (mediaPlayerCard != null && mediaPlayerCard.getVisibility() == View.VISIBLE) {
                commandHandler.postDelayed(this, 500L);
            }
        }
    };
    private LinearLayout promptRow;
    private TextView promptLabel;
    private EditText input;
    private String shellUsername = "user";
    private Button stopBtn;

    private TextView zoomIndicatorBadge;

    private LinearLayout confirmBar;
    private TextView confirmMessage;
    private Button confirmYesBtn;
    private Button confirmNoBtn;

    private HorizontalScrollView extraKeysScroll;
    private LinearLayout extraKeysRow;
    private boolean extraKeysVisible = true;

    private HorizontalScrollView quickBarScroll;
    private boolean quickBarVisible = false;
    private LinearLayout customChips;

    private LinearLayout drawerPanel;
    private List<AppEntry> launchableApps;
    private LinearLayout appRows;
    private EditText appSearch;
    private View drawerScrim;
    private boolean drawerOpen = false;
    private int drawerWidth;

    private ScaleGestureDetector scaleDetector;

    private final Handler commandHandler = new Handler(Looper.getMainLooper());
    private final Handler uiAnimHandler = new Handler(Looper.getMainLooper());
    private boolean cursorBlinkVisible = true;
    private final Runnable cursorBlinkTask = new Runnable() {
        @Override
        public void run() {
            if (promptLabel != null && promptLabel.getVisibility() == View.VISIBLE) {
                cursorBlinkVisible = !cursorBlinkVisible;
                String basePrompt = promptLabel.getTag() != null ? String.valueOf(promptLabel.getTag()) : promptLabel.getText().toString();
                if (basePrompt.endsWith("▌") || basePrompt.endsWith(" ")) {
                    basePrompt = basePrompt.substring(0, basePrompt.length() - 1);
                }
                promptLabel.setText(basePrompt + (cursorBlinkVisible ? "▌" : " "));
            }
            uiAnimHandler.postDelayed(this, 530);
        }
    };
    private final Runnable commandTimeout = () -> {
        TerminalWindow w = currentWindow();
        if (w == null || !w.commandRunning) return;
        appendToWindow(w, "\n[Command timed out after 180s. Unlocked automatically - tap UNLOCK / ^C if still busy.]\n");
        forceUnlockWindow(w, false);
    };

    private TerminalWindow currentWindow() {
        if (windows.isEmpty()) return null;
        if (activeWindowIndex < 0 || activeWindowIndex >= windows.size()) activeWindowIndex = 0;
        return windows.get(activeWindowIndex);
    }

    private TerminalWindow findWindowByToken(String token) {
        if (token == null) return null;
        for (TerminalWindow w : windows) {
            if (token.equals(w.activeSessionToken)) return w;
        }
        return null;
    }

    private TerminalWindow findWindowByExecId(int execId) {
        for (TerminalWindow w : windows) {
            if (w.activeExecId == execId) return w;
        }
        return null;
    }

    private TerminalWindow findAnyRunningWindow() {
        for (TerminalWindow w : windows) {
            if (w.commandRunning) return w;
        }
        return null;
    }

    private void initStandaloneDirs() {
        standaloneRoot = new File(getFilesDir(), "standalone");
        standaloneUsr = new File(standaloneRoot, "usr");
        standaloneBin = new File(standaloneUsr, "bin");
        standaloneHome = new File(standaloneRoot, "home");
        standalonePackagesDir = new File(standaloneRoot, "packages");
        standaloneBin.mkdirs();
        standaloneHome.mkdirs();
        standalonePackagesDir.mkdirs();
    }

    private boolean isTermuxAvailable() {
        try {
            getPackageManager().getPackageInfo(TERMUX_PACKAGE, 0);
            return checkSelfPermission(RUN_PERMISSION) == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("custom-terminal", MODE_PRIVATE);
        palette = preferences.getInt("palette", 0);
        fontFamily = preferences.getInt("font_family", 0);
        fontSizeSp = preferences.getFloat("font_size_sp", 13f);
        if (fontSizeSp < 7f || fontSizeSp > 34f) fontSizeSp = 13f;
        overlayPercent = preferences.getInt("overlay", 100);
        quickBarVisible = preferences.getBoolean("quick_bar_visible", false);
        extraKeysVisible = preferences.getBoolean("extra_keys_visible", true);
        String savedName = preferences.getString("shell_username", "");
        if (savedName != null && !savedName.trim().isEmpty()) {
            shellUsername = sanitizeUsername(savedName);
        }

        initStandaloneDirs();
        loadCustomCommands();
        loadCommandHistory();
        loadRepoSources();

        String savedDir = preferences.getString("working_directory", null);
        File initialDir;
        if (savedDir != null && !savedDir.trim().isEmpty()) {
            initialDir = new File(savedDir);
        } else {
            initialDir = isTermuxAvailable() ? new File(DEFAULT_HOME) : standaloneHome;
        }
        if (!initialDir.exists()) {
            initialDir = isTermuxAvailable() ? new File(DEFAULT_HOME) : standaloneHome;
        }

        TerminalWindow win1 = new TerminalWindow(UUID.randomUUID().toString(), "Window 1", initialDir);
        windows.add(win1);
        activeWindowIndex = 0;

        initPinchZoomDetector();
        buildUi();

        String savedWallpaper = preferences.getString("wallpaper", null);
        if (savedWallpaper != null) {
            try {
                wallpaper.setImageURI(Uri.parse(savedWallpaper));
            } catch (Exception ignored) { }
        }

        String modeLabel = isTermuxAvailable() ? "Termux + Standalone Repo" : "Standalone Mode (No Termux needed)";
        appendToWindow(win1, "Termux Vision Shell (" + modeLabel + ")\nType 'tutorial' or 'help' to get started. Pinch (2 fingers) to zoom.\n");
        syncWindowUi();
        animateTerminalEntry(page);
        startNetHunterBootAnimation();
        uiAnimHandler.postDelayed(cursorBlinkTask, 530);
        promptForUsernameIfFirstRun();
        if (input != null) {
            input.post(() -> {
                try {
                    input.requestFocus();
                } catch (Exception ignored) { }
            });
        }
    }

    private void initPinchZoomDetector() {
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                isPinching = true;
                pinchBaseFontSize = fontSizeSp;
                if (scroll != null) {
                    scroll.requestDisallowInterceptTouchEvent(true);
                }
                showZoomBadge(fontSizeSp);
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float factor = detector.getScaleFactor();
                float nextSize = pinchBaseFontSize * factor;
                nextSize = Math.max(7f, Math.min(34f, nextSize));
                pinchBaseFontSize = nextSize;
                fontSizeSp = Math.round(nextSize * 10f) / 10f;
                applyFontSizeOnly();
                showZoomBadge(fontSizeSp);
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                isPinching = false;
                if (scroll != null) {
                    scroll.requestDisallowInterceptTouchEvent(false);
                }
                preferences.edit().putFloat("font_size_sp", fontSizeSp).apply();
                hideZoomBadgeDelayed();
            }
        });
    }

    private void showZoomBadge(float sizeSp) {
        if (zoomIndicatorBadge == null) return;
        commandHandler.removeCallbacks(hideZoomRunnable);
        zoomIndicatorBadge.setText(String.format("Zoom: %.0fsp", sizeSp));
        zoomIndicatorBadge.setVisibility(View.VISIBLE);
    }

    private final Runnable hideZoomRunnable = () -> {
        if (zoomIndicatorBadge != null) {
            zoomIndicatorBadge.setVisibility(View.GONE);
        }
    };

    private void hideZoomBadgeDelayed() {
        commandHandler.removeCallbacks(hideZoomRunnable);
        commandHandler.postDelayed(hideZoomRunnable, 900L);
    }

    private void applyFontSizeOnly() {
        if (output != null) output.setTextSize(fontSizeSp);
        if (promptLabel != null) promptLabel.setTextSize(fontSizeSp);
        if (input != null) input.setTextSize(fontSizeSp);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (scaleDetector != null && ev.getPointerCount() >= 2) {
            scaleDetector.onTouchEvent(ev);
            if (isPinching) {
                if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    isPinching = false;
                }
                return true;
            }
        } else if (isPinching && scaleDetector != null) {
            scaleDetector.onTouchEvent(ev);
            if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                isPinching = false;
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onResume() {
        super.onResume();
        activeActivity = this;
        TerminalWindow w = currentWindow();
        if (w != null && w.commandRunning && w.commandStartedAt > 0L) {
            long elapsed = System.currentTimeMillis() - w.commandStartedAt;
            if (elapsed > 90000L && !w.activeSessionReceivedLines) {
                appendToWindow(w, "\n[Detected stalled session. Unlocked automatically.]\n");
                forceUnlockWindow(w, false);
            }
        }
    }

    @Override
    protected void onPause() {
        if (activeActivity == this) activeActivity = null;
        super.onPause();
    }

    static void receiveTermuxLog(String token, String line) {
        MainActivity a = activeActivity;
        if (a == null || token == null || line == null) return;
        a.runOnUiThread(() -> {
            TerminalWindow w = a.findWindowByToken(token);
            if (w == null) return;
            w.activeSessionReceivedLines = true;
            if (line.contains("Waiting for cache lock") && line.equals(w.lastLogLine)) {
                w.repeatedLockCount++;
                if (w.repeatedLockCount % 5 != 0) return;
            } else {
                w.repeatedLockCount = 0;
            }
            w.lastLogLine = line;
            a.appendToWindow(w, line + "\n");
            a.detectConfirmationPrompt(w, line);
        });
    }

    static void receiveTermuxResult(String token, int execId, String text, int exitCode) {
        MainActivity a = activeActivity;
        if (a == null) return;
        a.runOnUiThread(() -> {
            TerminalWindow w = a.findWindowByToken(token);
            if (w == null && execId > 0) {
                w = a.findWindowByExecId(execId);
            }
            if (w == null) {
                w = a.findAnyRunningWindow();
            }
            if (w == null) return;
            a.commandHandler.removeCallbacks(a.commandTimeout);
            if (!w.activeSessionReceivedLines && text != null && !text.isEmpty()) {
                a.appendToWindow(w, text);
                if (!text.endsWith("\n")) a.appendToWindow(w, "\n");
                a.detectConfirmationPrompt(w, text);
            }
            if (exitCode != 0) {
                a.appendToWindow(w, "[exit " + exitCode + "]\n");
            }
            w.activeSessionToken = null;
            w.activeExecId = -1;
            w.commandRunning = false;
            w.commandStartedAt = 0L;
            if (w == a.currentWindow()) {
                a.updateInputState();
            }
        });
    }

    private void forceUnlockWindow(TerminalWindow w, boolean cleanTermuxLocks) {
        if (w == null) return;
        commandHandler.removeCallbacks(commandTimeout);

        w.activeSessionToken = null;
        w.activeExecId = -1;
        w.commandRunning = false;
        w.commandStartedAt = 0L;
        w.awaitingConfirm = false;
        w.pendingInstallPackage = null;
        w.lastLogLine = null;
        w.repeatedLockCount = 0;
        ctrlActive = false;
        altActive = false;
        updateModifierButtonsUi();
        hideConfirmBanner();
        updateInputState();
        focusTerminalInput();

        if (cleanTermuxLocks && isTermuxAvailable()) {
            try {
                String fixLockCmd =
                    "pkill -f '(^|/)apt(\\s|$)|(^|/)dpkg(\\s|$)|(^|/)pkg(\\s|$)' 2>/dev/null || true; " +
                    "rm -f /data/data/com.termux/files/usr/var/lib/dpkg/lock-frontend " +
                    "/data/data/com.termux/files/usr/var/lib/dpkg/lock " +
                    "/data/data/com.termux/files/usr/var/cache/apt/archives/lock 2>/dev/null || true; " +
                    "dpkg --configure -a 2>/dev/null || true; " +
                    "echo '[Cleared dpkg/apt locks]'";
                Intent fixIntent = new Intent("com.termux.RUN_COMMAND");
                fixIntent.setClassName(TERMUX_PACKAGE, "com.termux.app.RunCommandService");
                fixIntent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
                fixIntent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", fixLockCmd});
                fixIntent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
                if (Build.VERSION.SDK_INT >= 26) {
                    try { startService(fixIntent); } catch (Exception ignored) { }
                } else {
                    startService(fixIntent);
                }
            } catch (Exception ignored) { }
        }
    }

    private void detectConfirmationPrompt(TerminalWindow w, String rawText) {
        if (rawText == null) return;
        String lower = rawText.toLowerCase();
        boolean isYesNoPrompt =
            lower.contains("[y/n]") ||
            lower.contains("(y/n)") ||
            lower.contains("do you want to continue") ||
            lower.contains("proceed? [y/n]") ||
            lower.contains("confirm [y/n]");

        if (isYesNoPrompt) {
            w.awaitingConfirm = true;
            w.confirmPromptText = rawText.trim();
            if (w == currentWindow()) {
                showConfirmBanner(w.confirmPromptText);
                updateInputState();
            }
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);

        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));

        shade = new View(this);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), dp(6), dp(6), dp(6));
        topBar.setElevation(dp(4));

        menuIconBtn = createActionIcon("[=]", "Open drawer");
        menuIconBtn.setOnClickListener(v -> openDrawer());
        topBar.addView(menuIconBtn);

        windowDropdownChip = new LinearLayout(this);
        windowDropdownChip.setOrientation(LinearLayout.HORIZONTAL);
        windowDropdownChip.setGravity(Gravity.CENTER_VERTICAL);
        windowDropdownChip.setPadding(dp(10), dp(6), dp(10), dp(6));
        windowDropdownChip.setOnClickListener(v -> showWindowSwitcherDialog());

        windowSelectorText = new TextView(this);
        windowSelectorText.setText("root@kali: /");
        windowSelectorText.setTextSize(16);
        windowSelectorText.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        windowDropdownChip.addView(windowSelectorText);

        LinearLayout.LayoutParams titleWrapParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleWrapParams.leftMargin = dp(8);
        topBar.addView(windowDropdownChip, titleWrapParams);

        addWinBtn = createActionIcon("+", "New window");
        addWinBtn.setOnClickListener(v -> addNewWindow());
        topBar.addView(addWinBtn);

        closeWinBtn = createActionIcon("x", "Close window");
        closeWinBtn.setOnClickListener(v -> closeCurrentWindow());
        topBar.addView(closeWinBtn);

        TextView toolsActBtn = createActionIcon("[]", "Full Screen Tools Drawer");
        toolsActBtn.setOnClickListener(v -> openFullScreenToolsDrawer());
        topBar.addView(toolsActBtn);

        overflowBtn = createActionIcon(":", "More options");
        overflowBtn.setOnClickListener(v -> showOverflowMenu());
        topBar.addView(overflowBtn);

        page.addView(topBar, new LinearLayout.LayoutParams(-1, dp(48)));

        quickBarScroll = new HorizontalScrollView(this);
        quickBarScroll.setHorizontalScrollBarEnabled(false);
        quickBarScroll.setVisibility(quickBarVisible ? View.VISIBLE : View.GONE);
        quickBarScroll.setPadding(dp(6), dp(4), dp(6), dp(4));

        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER_VERTICAL);

        Button unlockChip = chipButton("UNLOCK");
        unlockChip.setOnClickListener(v -> {
            appendToWindow(currentWindow(), "\n[Unlocked running state]\n");
            forceUnlockWindow(currentWindow(), false);
        });
        chips.addView(unlockChip);

        Button repoListChip = chipButton("REPO LIST");
        repoListChip.setOnClickListener(v -> {
            input.setText("repo list");
            runCommand();
        });
        chips.addView(repoListChip);

        Button pkgBtn = chipButton("PKG INSTALL");
        pkgBtn.setOnClickListener(v -> showPackageInstallerDialog());
        chips.addView(pkgBtn);

        String[] quickCmds = {"ls", "pwd", "repo sources", "repo installed"};
        for (String cmd : quickCmds) {
            Button b = chipButton(cmd);
            b.setOnClickListener(v -> {
                input.setText(cmd);
                runCommand();
            });
            chips.addView(b);
        }

        Button addCustom = chipButton("+ CUSTOM");
        addCustom.setOnClickListener(v -> showAddCustomDialog());
        chips.addView(addCustom);

        Button clearBtn = chipButton("CLEAR");
        clearBtn.setOnClickListener(v -> clearCurrentWindow());
        chips.addView(clearBtn);

        customChips = new LinearLayout(this);
        customChips.setGravity(Gravity.CENTER_VERTICAL);
        chips.addView(customChips);

        quickBarScroll.addView(chips);
        page.addView(quickBarScroll, new LinearLayout.LayoutParams(-1, -2));
        renderCustomCommands();

        confirmBar = new LinearLayout(this);
        confirmBar.setOrientation(LinearLayout.HORIZONTAL);
        confirmBar.setGravity(Gravity.CENTER_VERTICAL);
        confirmBar.setPadding(dp(10), dp(6), dp(10), dp(6));
        confirmBar.setBackgroundColor(0xFF1E293B);
        confirmBar.setVisibility(View.GONE);

        confirmMessage = new TextView(this);
        confirmMessage.setText("Do you want to continue? [Y/n]");
        confirmMessage.setTextColor(0xFFFFFFFF);
        confirmMessage.setTextSize(12);
        confirmMessage.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        confirmMessage.setSingleLine(true);
        confirmMessage.setEllipsize(TextUtils.TruncateAt.END);
        confirmBar.addView(confirmMessage, new LinearLayout.LayoutParams(0, -2, 1f));

        confirmYesBtn = new Button(this);
        confirmYesBtn.setText("Y (Yes)");
        confirmYesBtn.setTextSize(11);
        confirmYesBtn.setTextColor(0xFF000000);
        confirmYesBtn.setBackgroundColor(0xFF4ADE80);
        confirmYesBtn.setMinHeight(dp(30));
        confirmYesBtn.setMinimumHeight(dp(30));
        confirmYesBtn.setPadding(dp(10), 0, dp(10), 0);
        confirmYesBtn.setOnClickListener(v -> sendConfirmationResponse(true));
        LinearLayout.LayoutParams yesParams = new LinearLayout.LayoutParams(-2, -2);
        yesParams.leftMargin = dp(6);
        confirmBar.addView(confirmYesBtn, yesParams);

        confirmNoBtn = new Button(this);
        confirmNoBtn.setText("N (No)");
        confirmNoBtn.setTextSize(11);
        confirmNoBtn.setTextColor(0xFFFFFFFF);
        confirmNoBtn.setBackgroundColor(0xFFEF4444);
        confirmNoBtn.setMinHeight(dp(30));
        confirmNoBtn.setMinimumHeight(dp(30));
        confirmNoBtn.setPadding(dp(10), 0, dp(10), 0);
        confirmNoBtn.setOnClickListener(v -> sendConfirmationResponse(false));
        LinearLayout.LayoutParams noParams = new LinearLayout.LayoutParams(-2, -2);
        noParams.leftMargin = dp(6);
        confirmBar.addView(confirmNoBtn, noParams);

        page.addView(confirmBar, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout terminalFrame = new FrameLayout(this);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        terminalContainer = new LinearLayout(this);
        terminalContainer.setOrientation(LinearLayout.VERTICAL);
        terminalContainer.setPadding(dp(10), dp(6), dp(12), dp(16));
        terminalContainer.setOnClickListener(v -> focusTerminalInput());

        output = new TextView(this);
        output.setTextSize(fontSizeSp);
        output.setTypeface(selectedTypeface());
        output.setTextIsSelectable(true);
        output.setHorizontallyScrolling(false);
        output.setLineSpacing(0, 1.05f);
        output.setOnClickListener(v -> focusTerminalInput());
        buildInlineMediaPlayerCard();
        terminalContainer.addView(mediaPlayerCard, new LinearLayout.LayoutParams(-1, -2));

        terminalContainer.addView(output, new LinearLayout.LayoutParams(-1, -2));

        promptRow = new LinearLayout(this);
        promptRow.setOrientation(LinearLayout.HORIZONTAL);
        promptRow.setGravity(Gravity.CENTER_VERTICAL);

        promptLabel = new TextView(this);
        promptLabel.setTextSize(fontSizeSp);
        promptLabel.setTypeface(selectedTypeface());
        promptRow.addView(promptLabel, new LinearLayout.LayoutParams(-2, -2));

        promptRow.setPadding(dp(4), dp(4), dp(4), dp(6));
        promptLabel.setPadding(dp(2), dp(4), dp(6), dp(4));

        input = new EditText(this);
        input.setSingleLine(true);
        input.setBackground(null);
        input.setPadding(dp(6), dp(6), dp(12), dp(6));
        input.setTextSize(fontSizeSp);
        input.setTypeface(selectedTypeface());
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_SEND ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                handleTerminalEnter();
                return true;
            }
            return false;
        });
        input.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                handleTerminalEnter();
                return true;
            }
            return false;
        });
        promptRow.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));

        stopBtn = new Button(this);
        stopBtn.setText("^C / UNLOCK");
        stopBtn.setTextSize(10);
        stopBtn.setTextColor(0xFFFFFFFF);
        stopBtn.setBackgroundColor(0xFFDC2626);
        stopBtn.setMinHeight(dp(28));
        stopBtn.setMinimumHeight(dp(28));
        stopBtn.setPadding(dp(8), 0, dp(8), 0);
        stopBtn.setVisibility(View.GONE);
        stopBtn.setOnClickListener(v -> cancelAndUnlockCurrentCommand());
        promptRow.addView(stopBtn, new LinearLayout.LayoutParams(-2, -2));

        terminalContainer.addView(promptRow, new LinearLayout.LayoutParams(-1, -2));

        View filler = new View(this);
        filler.setOnClickListener(v -> focusTerminalInput());
        terminalContainer.addView(filler, new LinearLayout.LayoutParams(-1, 0, 1f));

        scroll.addView(terminalContainer, new ScrollView.LayoutParams(-1, -2));
        terminalFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        zoomIndicatorBadge = new TextView(this);
        zoomIndicatorBadge.setText("Zoom: 13sp");
        zoomIndicatorBadge.setTextColor(0xFFFFFFFF);
        zoomIndicatorBadge.setTextSize(11);
        zoomIndicatorBadge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        zoomIndicatorBadge.setBackgroundColor(0xCC1E293B);
        zoomIndicatorBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        zoomIndicatorBadge.setVisibility(View.GONE);
        FrameLayout.LayoutParams badgeParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        badgeParams.topMargin = dp(6);
        badgeParams.rightMargin = dp(8);
        terminalFrame.addView(zoomIndicatorBadge, badgeParams);

        page.addView(terminalFrame, new LinearLayout.LayoutParams(-1, 0, 1f));

        buildExtraKeysBar(page);

        buildDrawer();
        setContentView(root);
        applyStyle();
    }

    private void buildExtraKeysBar(LinearLayout page) {
        extraKeysScroll = new HorizontalScrollView(this);
        extraKeysScroll.setHorizontalScrollBarEnabled(false);
        extraKeysScroll.setVisibility(extraKeysVisible ? View.VISIBLE : View.GONE);

        LinearLayout twoRowContainer = new LinearLayout(this);
        twoRowContainer.setOrientation(LinearLayout.VERTICAL);
        twoRowContainer.setBackgroundColor(0xFF0A0D12);
        twoRowContainer.setPadding(dp(4), dp(3), dp(4), dp(4));

        extraKeysRow = new LinearLayout(this);
        extraKeysRow.setOrientation(LinearLayout.HORIZONTAL);
        extraKeysRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout bottomKeysRow = new LinearLayout(this);
        bottomKeysRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomKeysRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams row2Params = new LinearLayout.LayoutParams(-1, -2);
        row2Params.topMargin = dp(2);

        String[] topRowKeys = {"Esc", "Alt", "PgUp", "Home", "^", "End", "..."};
        for (final String k : topRowKeys) {
            Button btn = createExtraKeyButton(k);
            btn.setOnClickListener(v -> {
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(65)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();
                if ("Alt".equals(k)) {
                    altActive = !altActive;
                    updateModifierButtonsUi();
                } else if ("...".equals(k)) {
                    openFullScreenToolsDrawer();
                } else {
                    handleExtraKeyPress(k.toUpperCase());
                }
            });
            extraKeysRow.addView(btn);
        }

        ctrlKeyBtn = createExtraKeyButton("Ctrl");
        ctrlKeyBtn.setOnClickListener(v -> {
            v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(65)
                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();
            ctrlActive = !ctrlActive;
            updateModifierButtonsUi();
        });
        bottomKeysRow.addView(ctrlKeyBtn);

        String[] bottomRowKeys = {"Tab", "PgDn", "<", "v", ">", "UNLOCK"};
        for (final String k : bottomRowKeys) {
            Button btn = createExtraKeyButton(k);
            btn.setOnClickListener(v -> {
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(65)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();
                handleExtraKeyPress(k.toUpperCase());
            });
            bottomKeysRow.addView(btn);
        }

        twoRowContainer.addView(extraKeysRow, new LinearLayout.LayoutParams(-1, -2));
        twoRowContainer.addView(bottomKeysRow, row2Params);

        extraKeysScroll.addView(twoRowContainer);
        page.addView(extraKeysScroll, new LinearLayout.LayoutParams(-1, -2));
    }

    private Button createExtraKeyButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setMinWidth(dp(40));
        b.setMinimumWidth(dp(40));
        b.setMinHeight(dp(34));
        b.setMinimumHeight(dp(34));
        b.setPadding(dp(8), 0, dp(8), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        b.setLayoutParams(lp);
        return b;
    }

    private void updateModifierButtonsUi() {
        int[] c = palettes[Math.max(0, Math.min(palette, palettes.length - 1))];
        if (ctrlKeyBtn != null) {
            ctrlKeyBtn.setBackgroundColor(ctrlActive ? 0xFF38BDF8 : c[0]);
            ctrlKeyBtn.setTextColor(ctrlActive ? 0xFF000000 : c[2]);
        }
        if (altKeyBtn != null) {
            altKeyBtn.setBackgroundColor(altActive ? 0xFFFACC15 : c[0]);
            altKeyBtn.setTextColor(altActive ? 0xFF000000 : c[2]);
        }
    }

    private void handleExtraKeyPress(String key) {
        TerminalWindow w = currentWindow();
        if (w == null) return;

        if ("UNLOCK".equals(key)) {
            appendToWindow(w, "\n[Unlocked running lock & reset prompt state]\n");
            forceUnlockWindow(w, false);
            return;
        }

        if (ctrlActive) {
            ctrlActive = false;
            updateModifierButtonsUi();
            String typed = input != null ? input.getText().toString().trim().toLowerCase() : "";
            if ("c".equals(typed)) {
                if (input != null) input.setText("");
                cancelAndUnlockCurrentCommand();
                return;
            }
            if ("l".equals(typed)) {
                if (input != null) input.setText("");
                clearCurrentWindow();
                return;
            }
            if ("z".equals(typed)) {
                if (input != null) input.setText("");
                appendToWindow(w, "^Z (Suspended / Unlocked)\n");
                forceUnlockWindow(w, false);
                return;
            }
            appendToWindow(w, "^" + (typed.isEmpty() ? key : typed.toUpperCase()) + "\n");
            focusTerminalInput();
            return;
        }

        if ("ESC".equals(key)) {
            if (w.awaitingConfirm) {
                sendConfirmationResponse(false);
            } else if (w.commandRunning) {
                cancelAndUnlockCurrentCommand();
            } else {
                appendToWindow(w, "^[\n");
                focusTerminalInput();
            }
            return;
        }

        if ("TAB".equals(key)) {
            insertAtCursor("    ");
            return;
        }

        if ("^".equals(key)) {
            if (!commandHistory.isEmpty()) {
                if (historyCursor < 0) historyCursor = commandHistory.size() - 1;
                else if (historyCursor > 0) historyCursor--;
                String histCmd = commandHistory.get(historyCursor);
                input.setText(histCmd);
                input.setSelection(histCmd.length());
            }
            focusTerminalInput();
            return;
        }

        if ("v".equals(key)) {
            if (!commandHistory.isEmpty() && historyCursor >= 0) {
                if (historyCursor < commandHistory.size() - 1) {
                    historyCursor++;
                    String histCmd = commandHistory.get(historyCursor);
                    input.setText(histCmd);
                    input.setSelection(histCmd.length());
                } else {
                    historyCursor = -1;
                    input.setText("");
                }
            }
            focusTerminalInput();
            return;
        }

        if ("<".equals(key) && input != null) {
            int pos = Math.max(0, input.getSelectionStart() - 1);
            input.setSelection(pos);
            focusTerminalInput();
            return;
        }

        if (">".equals(key) && input != null) {
            int pos = Math.min(input.getText().length(), input.getSelectionEnd() + 1);
            input.setSelection(pos);
            focusTerminalInput();
            return;
        }

        insertAtCursor(key);
    }

    private void insertAtCursor(String text) {
        if (input == null || text == null) return;
        int start = Math.max(0, input.getSelectionStart());
        int end = Math.max(0, input.getSelectionEnd());
        if (start > end) {
            int tmp = start;
            start = end;
            end = tmp;
        }
        Editable ed = input.getText();
        ed.replace(start, end, text);
        input.setSelection(Math.min(ed.length(), start + text.length()));
        focusTerminalInput();
    }

    private TextView createActionIcon(String glyph, String desc) {
        TextView tv = new TextView(this);
        tv.setText(glyph);
        tv.setTextSize(20);
        tv.setGravity(Gravity.CENTER);
        tv.setContentDescription(desc);
        tv.setMinWidth(dp(40));
        tv.setMinimumWidth(dp(40));
        tv.setMinHeight(dp(40));
        tv.setMinimumHeight(dp(40));
        return tv;
    }

    private Button chipButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setMinHeight(dp(30));
        b.setMinimumHeight(dp(30));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private void focusTerminalInput() {
        if (input == null) return;
        try {
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null && input.hasWindowFocus()) {
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            }
        } catch (Exception ignored) { }
    }

    private void handleTerminalEnter() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        String text = input.getText().toString().trim();
        if (w.awaitingConfirm) {
            if (text.isEmpty() || text.equalsIgnoreCase("y") || text.equalsIgnoreCase("yes")) {
                input.setText("");
                sendConfirmationResponse(true);
            } else if (text.equalsIgnoreCase("n") || text.equalsIgnoreCase("no")) {
                input.setText("");
                sendConfirmationResponse(false);
            } else {
                Toast.makeText(this, "Type y or n", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        runCommand();
    }

    private void showConfirmBanner(String promptText) {
        if (confirmBar == null) return;
        confirmMessage.setText(promptText.isEmpty() ? "Do you want to continue? [Y/n]" : promptText);
        confirmBar.setVisibility(View.VISIBLE);
    }

    private void hideConfirmBanner() {
        if (confirmBar != null) {
            confirmBar.setVisibility(View.GONE);
        }
    }

    private void sendConfirmationResponse(boolean yes) {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        w.awaitingConfirm = false;
        hideConfirmBanner();

        if (!yes) {
            appendToWindow(w, "n\nAbort.\n");
            w.pendingInstallPackage = null;
            w.commandRunning = false;
            w.commandStartedAt = 0L;
            w.activeSessionToken = null;
            w.activeExecId = -1;
            updateInputState();
            return;
        }

        appendToWindow(w, "y\n");
        if (w.pendingInstallPackage != null && !w.pendingInstallPackage.isEmpty()) {
            String pkg = w.pendingInstallPackage;
            w.pendingInstallPackage = null;
            w.commandRunning = false;
            w.commandStartedAt = 0L;
            w.activeSessionToken = null;
            w.activeExecId = -1;
            if (isTermuxAvailable()) {
                executeTermuxShellCommand(w, "pkg install -y -- " + pkg);
            } else {
                installStandaloneRepoPackage(w, pkg);
            }
        } else {
            w.commandRunning = false;
            w.commandStartedAt = 0L;
            w.activeSessionToken = null;
            w.activeExecId = -1;
            updateInputState();
        }
    }

    private String sanitizeUsername(String raw) {
        if (raw == null) return "user";
        String cleaned = raw.trim().toLowerCase().replaceAll("[^a-z0-9_-]", "");
        return cleaned.isEmpty() ? "user" : cleaned;
    }

    private String formatShellPrompt(TerminalWindow w) {
        String uname = (shellUsername == null || shellUsername.trim().isEmpty()) ? "root" : shellUsername.trim();
        String path = (w != null && w.currentDir != null) ? w.currentDir.getAbsolutePath() : "/";
        String homePath = getFilesDir().getAbsolutePath();
        if (path.equals(homePath)) path = "~";
        String base = "┌──(" + uname + "㉿kali)-[" + path + "]\n└─$";
        if (promptLabel != null) {
            promptLabel.setTag(base);
        }
        return base + (cursorBlinkVisible ? "▌" : " ");
    }

    private void promptForUsernameIfFirstRun() {
        if (preferences.getBoolean("username_prompt_shown", false)) {
            return;
        }
        preferences.edit().putBoolean("username_prompt_shown", true).apply();
        final EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setHint("Enter your name (e.g. mark)");
        nameInput.setText(shellUsername);
        nameInput.setSelection(nameInput.getText().length());

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(12), dp(24), dp(4));
        box.addView(nameInput, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(this)
            .setTitle("Terminal Name")
            .setMessage("What name should appear in your prompt? (Example: mark -> mark@terminal $)")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("Save", (dialog, which) -> {
                shellUsername = sanitizeUsername(nameInput.getText().toString());
                preferences.edit().putString("shell_username", shellUsername).apply();
                syncWindowUi();
                focusTerminalInput();
            })
            .setNegativeButton("Skip", (dialog, which) -> {
                preferences.edit().putString("shell_username", shellUsername).apply();
                syncWindowUi();
                focusTerminalInput();
            })
            .show();
    }

    private void syncWindowUi() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        windowSelectorText.setText(w.title + "   v");
        output.setText(w.logBuffer.toString());
        promptLabel.setText(formatShellPrompt(w));
        if (w.awaitingConfirm) {
            showConfirmBanner(w.confirmPromptText != null ? w.confirmPromptText : "Do you want to continue? [Y/n]");
        } else {
            hideConfirmBanner();
        }
        updateInputState();
        scrollToBottom();
    }

    private void updateInputState() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        promptLabel.setText(formatShellPrompt(w));
        input.setEnabled(true);
        if (w.commandRunning && !w.awaitingConfirm) {
            promptLabel.setVisibility(View.GONE);
            input.setHint("Running... (tap ^C / UNLOCK if stuck)");
            if (stopBtn != null) stopBtn.setVisibility(View.VISIBLE);
        } else {
            promptLabel.setVisibility(View.VISIBLE);
            input.setHint(w.awaitingConfirm ? "[Y/n]" : "");
            if (stopBtn != null) stopBtn.setVisibility(View.GONE);
        }
    }

    private void cancelAndUnlockCurrentCommand() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        appendToWindow(w, "^C [Process lock cleared]\n");
        forceUnlockWindow(w, true);
    }

    private void appendToWindow(TerminalWindow w, String text) {
        if (w == null || text == null) return;
        w.logBuffer.append(text);
        if (w.logBuffer.length() > 24000) {
            w.logBuffer.delete(0, w.logBuffer.length() - 18000);
        }
        if (w == currentWindow() && output != null) {
            output.setText(w.logBuffer.toString());
            scrollToBottom();
        }
    }

    private void scrollToBottom() {
        if (scroll != null && !isPinching) {
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void addNewWindow() {
        int nextNum = windows.size() + 1;
        File dir = currentWindow() != null ? currentWindow().workingDir : (isTermuxAvailable() ? new File(DEFAULT_HOME) : standaloneHome);
        TerminalWindow w = new TerminalWindow(UUID.randomUUID().toString(), "Window " + nextNum, dir);
        windows.add(w);
        activeWindowIndex = windows.size() - 1;
        syncWindowUi();
        focusTerminalInput();
    }

    private void closeCurrentWindow() {
        if (windows.size() <= 1) {
            clearCurrentWindow();
            Toast.makeText(this, "Window cleared & unlocked", Toast.LENGTH_SHORT).show();
            return;
        }
        TerminalWindow closing = currentWindow();
        if (closing != null) {
            forceUnlockWindow(closing, false);
        }
        windows.remove(activeWindowIndex);
        if (activeWindowIndex >= windows.size()) {
            activeWindowIndex = windows.size() - 1;
        }
        syncWindowUi();
    }

    private void clearCurrentWindow() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        w.logBuffer.setLength(0);
        forceUnlockWindow(w, false);
        syncWindowUi();
    }

    private void showWindowSwitcherDialog() {
        String[] titles = new String[windows.size() + 1];
        for (int i = 0; i < windows.size(); i++) {
            TerminalWindow w = windows.get(i);
            String lockTag = w.commandRunning ? " [RUNNING]" : "";
            titles[i] = w.title + lockTag + " (" + w.workingDir.getName() + ")" + (i == activeWindowIndex ? "  *" : "");
        }
        titles[windows.size()] = "+ New Window";

        new AlertDialog.Builder(this)
            .setTitle("Terminal Windows")
            .setItems(titles, (d, which) -> {
                if (which == windows.size()) {
                    addNewWindow();
                } else {
                    activeWindowIndex = which;
                    syncWindowUi();
                }
            })
            .show();
    }

    private void showOverflowMenu() {
        String[] items = {
            "Help Page",
            "How To Use Page",
            "For Professional Use Only (Notice)",
            "Browse Storage Files (/sdcard)",
            "Built-in Music & Video Player",
            (extraKeysVisible ? "Hide" : "Show") + " Extra Keys Bar",
            (quickBarVisible ? "Hide" : "Show") + " Quick Toolbar",
            "Unlock / Kill Stuck Process",
            "Install Package (repo / pkg)",
            "Wallpaper",
            "Preferences / Zoom",
            "Command History",
            "Termux / Standalone Status",
            "Reset Terminal"
        };
        new AlertDialog.Builder(this)
            .setItems(items, (d, which) -> {
                switch (which) {
                    case 0:
                        showHelpPageDialog();
                        break;
                    case 1:
                        showHowToUsePageDialog();
                        break;
                    case 2:
                        showProfessionalOnlyPageDialog();
                        break;
                    case 3:
                        openStorageFileBrowser(Environment.getExternalStorageDirectory());
                        break;
                    case 4:
                        showMediaPickerDialog();
                        break;
                    case 5:
                        extraKeysVisible = !extraKeysVisible;
                        preferences.edit().putBoolean("extra_keys_visible", extraKeysVisible).apply();
                        if (extraKeysScroll != null) {
                            extraKeysScroll.setVisibility(extraKeysVisible ? View.VISIBLE : View.GONE);
                        }
                        break;
                    case 6:
                        quickBarVisible = !quickBarVisible;
                        preferences.edit().putBoolean("quick_bar_visible", quickBarVisible).apply();
                        if (quickBarScroll != null) {
                            quickBarScroll.setVisibility(quickBarVisible ? View.VISIBLE : View.GONE);
                        }
                        break;
                    case 7:
                        appendToWindow(currentWindow(), "\n[Force unlocked & sent TERM to hung child processes]\n");
                        forceUnlockWindow(currentWindow(), true);
                        break;
                    case 8:
                        showPackageInstallerDialog();
                        break;
                    case 9:
                        chooseWallpaper();
                        break;
                    case 10:
                        showStyleMenu();
                        break;
                    case 11:
                        showHistory();
                        break;
                    case 12:
                        connectTermux();
                        break;
                    case 13:
                        clearCurrentWindow();
                        break;
                }
            })
            .show();
    }

    private Typeface selectedTypeface() {
        switch (fontFamily) {
            case 1: return Typeface.create("sans-serif", Typeface.NORMAL);
            case 2: return Typeface.create("serif", Typeface.NORMAL);
            case 3: return Typeface.create("casual", Typeface.NORMAL);
            default: return Typeface.MONOSPACE;
        }
    }

    private void applyStyle() {
        if (topBar == null || output == null || input == null) return;
        int[] c = palettes[Math.max(0, Math.min(palette, palettes.length - 1))];
        topBar.setBackgroundColor(c[0]);
        menuIconBtn.setTextColor(0xFFFFFFFF);
        windowSelectorText.setTextColor(0xFFFFFFFF);
        addWinBtn.setTextColor(0xFFFFFFFF);
        closeWinBtn.setTextColor(0xFFFFFFFF);
        overflowBtn.setTextColor(0xFFFFFFFF);

        int alpha = palette == 0 ? 0xFF : Math.max(0x40, Math.min(0xFF, overlayPercent * 255 / 100));
        shade.setBackgroundColor((alpha << 24) | (c[1] & 0x00FFFFFF));

        output.setTextColor(c[2]);
        promptLabel.setTextColor(c[2]);
        input.setTextColor(c[2]);
        input.setHintTextColor(c[3]);

        applyFontSizeOnly();

        Typeface tf = selectedTypeface();
        output.setTypeface(tf);
        promptLabel.setTypeface(tf);
        input.setTypeface(tf);

        if (quickBarScroll != null) {
            quickBarScroll.setBackgroundColor(c[4]);
            tintButtons(quickBarScroll, c[2], c[0]);
        }

        if (extraKeysScroll != null) {
            extraKeysScroll.setBackgroundColor(0xFF111827);
            for (int i = 0; i < extraKeysRow.getChildCount(); i++) {
                View child = extraKeysRow.getChildAt(i);
                if (child instanceof Button) {
                    Button b = (Button) child;
                    if ("UNLOCK".equals(b.getText().toString())) {
                        b.setBackgroundColor(0xFF991B1B);
                        b.setTextColor(0xFFFFFFFF);
                    } else {
                        b.setBackgroundColor(c[4]);
                        b.setTextColor(c[2]);
                    }
                }
            }
            updateModifierButtonsUi();
        }

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(c[0]);
            getWindow().setNavigationBarColor(0xFF000000);
        }

        if (drawerPanel != null) {
            drawerPanel.setBackgroundColor(c[1]);
            appSearch.setTextColor(c[2]);
            appSearch.setHintTextColor(c[3]);
            tintButtons(drawerPanel, c[2], c[4]);
        }
    }

    private void tintButtons(View view, int textColor, int bgColor) {
        if (view instanceof Button) {
            Button b = (Button) view;
            b.setTextColor(textColor);
            b.setBackgroundColor(bgColor);
        }
        if (view instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) view;
            for (int i = 0; i < g.getChildCount(); i++) {
                tintButtons(g.getChildAt(i), textColor, bgColor);
            }
        }
    }

    private void saveStyle() {
        preferences.edit()
            .putInt("palette", palette)
            .putInt("font_family", fontFamily)
            .putFloat("font_size_sp", fontSizeSp)
            .putInt("overlay", overlayPercent)
            .apply();
        applyStyle();
    }

    private void showStyleMenu() {
        String[] items = {
            "Font style: " + FONT_NAMES[fontFamily],
            String.format("Font size (Zoom): %.0f sp (Pinch 2 fingers)", fontSizeSp),
            "Color theme: " + PALETTE_NAMES[palette],
            "Background opacity: " + overlayPercent + "%"
        };
        new AlertDialog.Builder(this)
            .setTitle("Terminal Preferences")
            .setItems(items, (d, which) -> {
                if (which == 0) chooseFont();
                else if (which == 1) chooseFontSize();
                else if (which == 2) choosePalette();
                else chooseOverlay();
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private void chooseFont() {
        new AlertDialog.Builder(this)
            .setTitle("Font style")
            .setSingleChoiceItems(FONT_NAMES, fontFamily, (d, which) -> {
                fontFamily = which;
                saveStyle();
                d.dismiss();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void choosePalette() {
        new AlertDialog.Builder(this)
            .setTitle("Color theme")
            .setSingleChoiceItems(PALETTE_NAMES, palette, (d, which) -> {
                palette = which;
                saveStyle();
                d.dismiss();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void chooseFontSize() {
        int currentSp = Math.round(fontSizeSp);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(4));
        TextView label = new TextView(this);
        label.setText("Font size: " + currentSp + " sp");
        label.setTextSize(16);
        box.addView(label);
        SeekBar seek = new SeekBar(this);
        seek.setMax(27);
        seek.setProgress(Math.max(0, Math.min(27, currentSp - 7)));
        box.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                label.setText("Font size: " + (p + 7) + " sp");
            }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        new AlertDialog.Builder(this)
            .setTitle("Font size (Zoom)")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply", (d, which) -> {
                fontSizeSp = seek.getProgress() + 7;
                saveStyle();
            })
            .show();
    }

    private void chooseOverlay() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(4));
        TextView label = new TextView(this);
        label.setText("Background opacity: " + overlayPercent + "%");
        label.setTextSize(16);
        box.addView(label);
        SeekBar seek = new SeekBar(this);
        seek.setMax(75);
        seek.setProgress(overlayPercent - 25);
        box.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                label.setText("Background opacity: " + (p + 25) + "%");
            }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        new AlertDialog.Builder(this)
            .setTitle("Background opacity")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply", (d, which) -> {
                overlayPercent = seek.getProgress() + 25;
                saveStyle();
            })
            .show();
    }

    private void chooseWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_WALLPAPER);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_TOOLS_DRAWER && result == RESULT_OK && data != null) {
            String action = data.getStringExtra(ToolsDrawerActivity.EXTRA_ACTION);
            TerminalWindow w = currentWindow();
            if (ToolsDrawerActivity.ACTION_STORAGE.equals(action)) {
                openStorageFileBrowser(Environment.getExternalStorageDirectory());
            } else if (ToolsDrawerActivity.ACTION_MEDIA.equals(action)) {
                showMediaPickerDialog();
            } else if (ToolsDrawerActivity.ACTION_TERMUX.equals(action)) {
                connectTermux();
            } else if (ToolsDrawerActivity.ACTION_NEW_WINDOW.equals(action)) {
                addNewWindow();
            } else if (ToolsDrawerActivity.ACTION_UNLOCK.equals(action) && w != null) {
                appendToWindow(w, "\n[Force unlocked & sent TERM to hung child processes]\n");
                forceUnlockWindow(w, true);
            }
            return;
        }

        if (request == PICK_WALLPAPER && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                int takeFlags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                if (takeFlags != 0) {
                    try {
                        getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    } catch (SecurityException ignored) { }
                }
                wallpaper.setImageURI(uri);
                preferences.edit().putString("wallpaper", uri.toString()).apply();
                if (overlayPercent == 100) {
                    overlayPercent = 80;
                    saveStyle();
                }
            } catch (Exception e) {
                appendToWindow(currentWindow(), "Wallpaper error: " + e.getMessage() + "\n");
            }
        }
    }

    private void showHistory() {
        if (commandHistory.isEmpty()) {
            Toast.makeText(this, "No commands in history yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] items = commandHistory.toArray(new String[0]);
        new AlertDialog.Builder(this)
            .setTitle("Recent commands")
            .setItems(items, (d, which) -> {
                input.setText(items[which]);
                input.setSelection(input.getText().length());
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private void loadCommandHistory() {
        try {
            JSONArray saved = new JSONArray(preferences.getString("command_history", "[]"));
            int first = Math.max(0, saved.length() - 100);
            for (int i = first; i < saved.length(); i++) {
                String command = saved.optString(i, "");
                if (!command.isEmpty()) commandHistory.add(command);
            }
        } catch (Exception ignored) {
            commandHistory.clear();
        }
    }

    private void saveCommandHistory() {
        JSONArray saved = new JSONArray();
        int first = Math.max(0, commandHistory.size() - 100);
        for (int i = first; i < commandHistory.size(); i++) saved.put(commandHistory.get(i));
        preferences.edit().putString("command_history", saved.toString()).apply();
    }

    private void rememberCommand(String command) {
        commandHistory.add(command);
        while (commandHistory.size() > 100) commandHistory.remove(0);
        historyCursor = -1;
        saveCommandHistory();
    }

    private static final String[][] PRESET_REPOS = {
        {"Standalone Default Index", DEFAULT_REPO_INDEX},
        {"Termux Main (aarch64 Packages)", "https://packages.termux.dev/apt/termux-main/dists/stable/main/binary-aarch64/Packages"},
        {"Termux Root (aarch64 Packages)", "https://packages.termux.dev/apt/termux-root/dists/root/binary-aarch64/Packages"},
        {"Termux X11 (aarch64 Packages)", "https://packages.termux.dev/apt/termux-x11/dists/x11/binary-aarch64/Packages"},
        {"Debian Bookworm Main (arm64)", "https://deb.debian.org/debian/dists/bookworm/main/binary-arm64/Packages"}
    };

    private void loadRepoSources() {
        repoSources.clear();
        try {
            JSONArray arr = new JSONArray(preferences.getString("repo_sources", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                String u = arr.optString(i, "").trim();
                if (!u.isEmpty() && !repoSources.contains(u)) repoSources.add(u);
            }
        } catch (Exception ignored) { }
        if (repoSources.isEmpty()) {
            repoSources.add(DEFAULT_REPO_INDEX);
            for (String[] preset : PRESET_REPOS) {
                if (!repoSources.contains(preset[1])) {
                    repoSources.add(preset[1]);
                }
            }
        }
        activeRepoIndex = preferences.getInt("active_repo_index", 0);
        if (activeRepoIndex < 0 || activeRepoIndex >= repoSources.size()) {
            activeRepoIndex = 0;
        }
    }

    private void saveRepoSources() {
        JSONArray arr = new JSONArray();
        for (String u : repoSources) arr.put(u);
        if (activeRepoIndex < 0 || activeRepoIndex >= repoSources.size()) {
            activeRepoIndex = 0;
        }
        preferences.edit()
            .putString("repo_sources", arr.toString())
            .putInt("active_repo_index", activeRepoIndex)
            .apply();
    }

    private String getSelectedRepoUrl() {
        if (repoSources.isEmpty()) return DEFAULT_REPO_INDEX;
        if (activeRepoIndex < 0 || activeRepoIndex >= repoSources.size()) activeRepoIndex = 0;
        return repoSources.get(activeRepoIndex);
    }

    private void showRepoSelectorDialog(final TerminalWindow w) {
        String[] labels = new String[repoSources.size()];
        for (int i = 0; i < repoSources.size(); i++) {
            String marker = (i == activeRepoIndex) ? "[ACTIVE] " : "";
            labels[i] = marker + "[" + i + "] " + repoSources.get(i);
        }
        new AlertDialog.Builder(this)
            .setTitle("Select Active Repository")
            .setSingleChoiceItems(labels, activeRepoIndex, (dialog, which) -> {
                activeRepoIndex = which;
                saveRepoSources();
                dialog.dismiss();
                if (w != null) {
                    appendToWindow(w, "Selected active repo [" + activeRepoIndex + "]: " + getSelectedRepoUrl() + "\n");
                }
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private void buildDrawer() {
        drawerWidth = dp(290);
        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(0x99000000);
        drawerScrim.setAlpha(0f);
        drawerScrim.setVisibility(View.GONE);
        drawerScrim.setOnClickListener(v -> closeDrawer());
        root.addView(drawerScrim, new FrameLayout.LayoutParams(-1, -1));

        drawerPanel = new LinearLayout(this);
        drawerPanel.setOrientation(LinearLayout.VERTICAL);
        drawerPanel.setPadding(dp(14), dp(14), dp(12), dp(12));
        drawerPanel.setElevation(dp(12));
        drawerPanel.setTranslationX(-drawerWidth);
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(drawerWidth, -1, Gravity.LEFT);
        root.addView(drawerPanel, drawerParams);

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView headingText = new TextView(this);
        headingText.setText("WINDOWS & APPS");
        headingText.setTextColor(0xFFFFFFFF);
        headingText.setTextSize(15);
        headingText.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        heading.addView(headingText, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = chipButton("x");
        close.setOnClickListener(v -> closeDrawer());
        heading.addView(close);
        drawerPanel.addView(heading);

        Button newWinDrawerBtn = chipButton("+ New Window");
        newWinDrawerBtn.setOnClickListener(v -> {
            closeDrawer();
            addNewWindow();
        });
        LinearLayout.LayoutParams nwParams = new LinearLayout.LayoutParams(-1, -2);
        nwParams.topMargin = dp(8);
        drawerPanel.addView(newWinDrawerBtn, nwParams);

        Button unlockDrawerBtn = chipButton("Unlock / Reset Running State");
        unlockDrawerBtn.setOnClickListener(v -> {
            closeDrawer();
            appendToWindow(currentWindow(), "\n[Unlocked running state]\n");
            forceUnlockWindow(currentWindow(), false);
        });
        LinearLayout.LayoutParams ulParams = new LinearLayout.LayoutParams(-1, -2);
        ulParams.topMargin = dp(6);
        drawerPanel.addView(unlockDrawerBtn, ulParams);

        appSearch = new EditText(this);
        appSearch.setSingleLine(true);
        appSearch.setTextSize(14);
        appSearch.setHint("Search installed apps...");
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, -2);
        searchParams.topMargin = dp(10);
        drawerPanel.addView(appSearch, searchParams);

        ScrollView appScroll = new ScrollView(this);
        launchableApps = getLaunchableApps();
        appRows = new LinearLayout(this);
        appRows.setOrientation(LinearLayout.VERTICAL);
        appScroll.addView(appRows, new ScrollView.LayoutParams(-1, -2));
        drawerPanel.addView(appScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        appSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderAppRows(s.toString());
            }
            public void afterTextChanged(Editable e) { }
        });

        renderAppRows("");
    }

    private void showPackageInstallerDialog() {
        EditText packageInput = new EditText(this);
        packageInput.setSingleLine(true);
        packageInput.setHint("Package name or direct .zip/.tar.gz/.sh URL");
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        box.addView(packageInput, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
            .setTitle("Install Package (No Termux Required)")
            .setMessage("Uses standalone repo client by default, or Termux pkg if installed & permitted.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Install", (dialog, which) -> {
                String target = packageInput.getText().toString().trim();
                if (target.isEmpty()) {
                    Toast.makeText(this, "Enter a package name or URL.", Toast.LENGTH_SHORT).show();
                    return;
                }
                input.setText("repo install " + target);
                runCommand();
            })
            .show();
    }

    private List<AppEntry> getLaunchableApps() {
        List<AppEntry> apps = new ArrayList<>();
        try {
            Intent query = new Intent(Intent.ACTION_MAIN);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> found = getPackageManager().queryIntentActivities(query, 0);
            if (found == null) return apps;
            LinkedHashMap<String, AppEntry> unique = new LinkedHashMap<>();
            for (ResolveInfo info : found) {
                String pkg = info.activityInfo.packageName;
                if (!unique.containsKey(pkg)) {
                    String label = info.loadLabel(getPackageManager()).toString();
                    unique.put(pkg, new AppEntry(label, pkg, info.loadIcon(getPackageManager())));
                }
            }
            apps.addAll(unique.values());
            Collections.sort(apps, (a, b) -> a.label.compareToIgnoreCase(b.label));
        } catch (Exception ignored) { }
        return apps;
    }

    private void renderAppRows(String filter) {
        if (appRows == null || launchableApps == null) return;
        appRows.removeAllViews();
        String needle = filter.trim().toLowerCase();
        for (AppEntry app : launchableApps) {
            if (!app.label.toLowerCase().contains(needle)) continue;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6), dp(6), dp(6), dp(6));

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(app.icon);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(34), dp(34));
            iconParams.rightMargin = dp(10);
            row.addView(icon, iconParams);

            TextView label = new TextView(this);
            label.setText(app.label);
            label.setTextColor(0xFFFFFFFF);
            label.setTextSize(14);
            label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));

            row.setOnClickListener(v -> {
                closeDrawer();
                Intent launch = getPackageManager().getLaunchIntentForPackage(app.packageName);
                if (launch != null) startActivity(launch);
                else Toast.makeText(this, "App cannot be opened.", Toast.LENGTH_SHORT).show();
            });
            appRows.addView(row);
        }
    }

    private void openDrawer() {
        drawerOpen = true;
        drawerScrim.setVisibility(View.VISIBLE);
        drawerScrim.animate().alpha(1f).setDuration(180).start();
        drawerPanel.animate().translationX(0).setDuration(220).start();
        appSearch.setText("");
    }

    private void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        drawerPanel.animate().translationX(-drawerWidth).setDuration(200).start();
        drawerScrim.animate().alpha(0f).setDuration(180).withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
    }

    @Override
    public void onBackPressed() {
        if (drawerOpen) closeDrawer();
        else super.onBackPressed();
    }

    private void loadCustomCommands() {
        try {
            JSONArray data = new JSONArray(preferences.getString("custom_commands", "[]"));
            for (int i = 0; i < data.length(); i++) {
                JSONObject item = data.getJSONObject(i);
                customCommands.add(new CustomCommand(item.getString("name"), item.getString("command")));
            }
        } catch (Exception ignored) {
            customCommands.clear();
        }
    }

    private void saveCustomCommands() {
        JSONArray data = new JSONArray();
        for (CustomCommand item : customCommands) {
            JSONObject row = new JSONObject();
            try {
                row.put("name", item.name);
                row.put("command", item.command);
                data.put(row);
            } catch (Exception ignored) { }
        }
        preferences.edit().putString("custom_commands", data.toString()).apply();
        renderCustomCommands();
    }

    private void renderCustomCommands() {
        if (customChips == null) return;
        customChips.removeAllViews();
        for (CustomCommand item : customCommands) {
            LinearLayout pair = new LinearLayout(this);
            pair.setGravity(Gravity.CENTER_VERTICAL);
            Button run = chipButton(item.name);
            run.setOnClickListener(v -> {
                input.setText(item.command);
                runCommand();
            });
            pair.addView(run);
            Button delete = chipButton("x");
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Delete shortcut?")
                .setMessage(item.name)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    customCommands.remove(item);
                    saveCustomCommands();
                })
                .show());
            pair.addView(delete);
            customChips.addView(pair);
        }
        applyStyle();
    }

    private void showAddCustomDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), dp(2));
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Shortcut name");
        box.addView(name);
        EditText command = new EditText(this);
        command.setSingleLine(true);
        command.setHint("Command or repo command");
        box.addView(command);
        new AlertDialog.Builder(this)
            .setTitle("Add custom command")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add", (dialog, which) -> {
                String label = name.getText().toString().trim();
                String value = command.getText().toString().trim();
                if (label.isEmpty() || value.isEmpty()) {
                    Toast.makeText(this, "Enter both a name and command.", Toast.LENGTH_SHORT).show();
                    return;
                }
                customCommands.add(new CustomCommand(label, value));
                saveCustomCommands();
            })
            .show();
    }

    private void connectTermux() {
        TerminalWindow w = currentWindow();
        boolean hasTermuxPkg = false;
        try {
            getPackageManager().getPackageInfo(TERMUX_PACKAGE, 0);
            hasTermuxPkg = true;
        } catch (PackageManager.NameNotFoundException ignored) { }

        boolean hasPerm = checkSelfPermission(RUN_PERMISSION) == PackageManager.PERMISSION_GRANTED;
        appendToWindow(w,
            "Runtime status:\n" +
            "  Standalone Repo Prefix : READY (" + standaloneRoot.getAbsolutePath() + ")\n" +
            "  Termux Installed       : " + (hasTermuxPkg ? "YES" : "NO (Standalone mode active)") + "\n" +
            "  RUN_COMMAND Permission : " + (hasPerm ? "GRANTED" : "NOT GRANTED (use 'repo ...' commands)") + "\n");
    }

    @Override
    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        TerminalWindow w = currentWindow();
        if (request == 22 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            appendToWindow(w, "Termux command permission granted.\n");
        } else if (request == 22) {
            appendToWindow(w, "Running in Standalone Repo mode (no Termux needed).\n");
        }
    }

    private String extractInteractiveInstallTarget(String command) {
        String trimmed = command.trim();
        if (trimmed.contains(" -y") || trimmed.contains(" --yes") || trimmed.startsWith("yes ")) {
            return null;
        }
        Pattern p = Pattern.compile("^(?:pkg|apt|apt-get)\\s+install\\s+(.+)$");
        Matcher m = p.matcher(trimmed);
        if (m.matches()) {
            return m.group(1).replace("-y", "").trim();
        }
        return null;
    }

    private void runCommand() {
        TerminalWindow w = currentWindow();
        if (w == null) return;

        String command = input.getText().toString().trim();
        if (command.isEmpty()) {
            appendToWindow(w, formatShellPrompt(w) + "\n");
            return;
        }

        if (command.equals("unlock") || command.equals("reset") || command.equals("stop") || command.equals("fixlock")) {
            input.setText("");
            boolean deepClean = command.equals("fixlock") || command.equals("stop");
            appendToWindow(w, formatShellPrompt(w) + command + (deepClean ? "\n[Unlocking & cleaning locks...]\n" : "\n[Unlocked]\n"));
            forceUnlockWindow(w, deepClean);
            return;
        }

        if (w.commandRunning) {
            appendToWindow(w, "[Busy - tap UNLOCK or ^C / UNLOCK button, or type 'unlock' to clear lock]\n");
            Toast.makeText(this, "Tap UNLOCK or type 'unlock' if stuck", Toast.LENGTH_SHORT).show();
            return;
        }

        input.setText("");
        appendToWindow(w, formatShellPrompt(w) + command + "\n");
        rememberCommand(command);

        if (command.equals("setname") || command.startsWith("setname ")) {
            String rawNewName = command.length() <= 7 ? "" : command.substring(8).trim();
            if (rawNewName.isEmpty()) {
                appendToWindow(w, "Usage: setname <your_name>   (Example: setname mark)\n");
            } else {
                shellUsername = sanitizeUsername(rawNewName);
                preferences.edit()
                    .putString("shell_username", shellUsername)
                    .putBoolean("username_prompt_shown", true)
                    .apply();
                syncWindowUi();
                appendToWindow(w, "Prompt updated to: " + shellUsername + "@terminal $\n");
            }
            return;
        }

        if (command.equals("helppage") || command.equals("help --page")) {
            showHelpPageDialog();
            return;
        }

        if (command.equals("howto") || command.equals("how-to") || command.equals("guide")) {
            showHowToUsePageDialog();
            return;
        }

        if (command.equals("pro") || command.equals("professional") || command.equals("disclaimer")) {
            showProfessionalOnlyPageDialog();
            return;
        }

        if (command.equals("storage") || command.equals("sdcard") || command.equals("files")) {
            ensureStorageAccessAndBrowse(w, true);
            return;
        }

        if (command.equals("storage-grant") || command.equals("setup-storage")) {
            requestStoragePermissionsNow(w);
            return;
        }

        if (command.equals("stopmedia") || command.equals("stop-media")) {
            stopInlineMediaPlayer();
            appendToWindow(w, "[Media player stopped]\n");
            return;
        }

        if (command.equals("media") || command.equals("player")) {
            showMediaPickerDialog();
            return;
        }

        if (command.equals("play") || command.startsWith("play ") ||
            command.equals("music") || command.startsWith("music ") ||
            command.equals("video") || command.startsWith("video ")) {
            int spIdx = command.indexOf(' ');
            String target = spIdx < 0 ? "" : command.substring(spIdx + 1).trim();
            if ((target.startsWith("\"") && target.endsWith("\"")) || (target.startsWith("'") && target.endsWith("'"))) {
                if (target.length() >= 2) target = target.substring(1, target.length() - 1);
            }
            if (target.isEmpty()) {
                showMediaPickerDialog();
            } else {
                File mediaFile = resolvePath(w, target);
                boolean forceVideo = command.startsWith("video");
                playMediaInTerminal(w, mediaFile, forceVideo);
            }
            return;
        }

        if (command.equals("su") || command.startsWith("su ")) {
            String suArgs = command.equals("su") ? "id" : command.substring(3).trim();
            if (suArgs.startsWith("-c ")) {
                suArgs = suArgs.substring(3).trim();
                if ((suArgs.startsWith("\"") && suArgs.endsWith("\"")) || (suArgs.startsWith("'") && suArgs.endsWith("'"))) {
                    if (suArgs.length() >= 2) suArgs = suArgs.substring(1, suArgs.length() - 1);
                }
            }
            executeRootSuCommand(w, suArgs);
            return;
        }

        if (command.equals("tutorial")) {
            appendToWindow(w,
                "=== TERMINAL COMMAND TUTORIAL ===\n" +
                "1. Basic Navigation & Files:\n" +
                "   pwd                  Show current folder path\n" +
                "   ls [folder]          List files and folders\n" +
                "   cd <folder>          Move into a folder (use 'cd ~' for home)\n" +
                "   cat <filename>       Read text file contents\n" +
                "   nano <filename>      Open built-in text editor (Save / Cancel)\n\n" +
                "2. Package & Repository Commands (Standalone):\n" +
                "   repo sources         Show configured package sources\n" +
                "   repo add <url>       Add a repo .json index or package URL\n" +
                "   repo list            List available packages from repos\n" +
                "   repo install <pkg>   Download & install package locally\n" +
                "   repo installed       Show installed packages\n\n" +
                "3. Prompt Name & Screen Controls:\n" +
                "   setname <name>       Change your prompt name (e.g. setname mark)\n" +
                "   history              Show recent commands\n" +
                "   clear                Clear terminal screen\n" +
                "   unlock               Unlock if a command gets stuck\n" +
                "   Pinch 2 fingers      Zoom font size up or down\n" +
                "===================================\n");
            return;
        }

        if (command.equals("help")) {
            appendToWindow(w,
                "Standalone & Repo commands (No Termux required):\n" +
                "  tutorial             Step-by-step guide on how to use commands\n" +
                "  setname <name>       Set prompt name (e.g. setname mark)\n" +
                "  repo help            Show repository commands\n" +
                "  repo sources         List configured repository URLs\n" +
                "  repo add <url>       Add repository index (.json) or package base URL\n" +
                "  repo list            Fetch & list packages from configured repos\n" +
                "  repo install <pkg|url> Download & install package into standalone prefix\n" +
                "  repo installed       List locally installed packages\n" +
                "  ls [path]            List files in current directory\n" +
                "  pwd                  Print current directory\n" +
                "  cd <dir>             Change directory (~ goes to home)\n" +
                "  cat <file>           Display text file content\n" +
                "  clear / unlock       Clear screen or unlock running lock\n" +
                "Note: If Termux is installed & permitted, shell commands also run in Termux.\n");
            return;
        }

        if (command.equals("clear")) {
            clearCurrentWindow();
            return;
        }

        if (command.equals("history")) {
            showHistory();
            return;
        }

        if (command.equals("pwd")) {
            appendToWindow(w, w.workingDir.getAbsolutePath() + "\n");
            return;
        }

        if (command.equals("ls") || command.startsWith("ls ")) {
            String target = command.length() == 2 ? "" : command.substring(3).trim();
            File dir = target.isEmpty() ? w.workingDir : resolvePath(w, target);
            if (!dir.exists()) {
                appendToWindow(w, "ls: cannot access '" + target + "': No such file or directory\n");
            } else if (dir.isFile()) {
                appendToWindow(w, dir.getName() + " (" + dir.length() + " bytes)\n");
            } else {
                File[] files = dir.listFiles();
                if (files == null || files.length == 0) {
                    appendToWindow(w, "(empty directory)\n");
                } else {
                    ArrayList<String> names = new ArrayList<>();
                    for (File f : files) {
                        names.add(f.isDirectory() ? f.getName() + "/" : f.getName());
                    }
                    Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
                    appendToWindow(w, TextUtils.join("  ", names) + "\n");
                }
            }
            return;
        }

        if (command.equals("nano") || command.startsWith("nano ")) {
            String rel = command.length() == 4 ? "untitled.txt" : command.substring(5).trim();
            if (rel.isEmpty()) rel = "untitled.txt";
            openStandaloneNanoEditor(w, resolvePath(w, rel));
            return;
        }

        if (command.startsWith("cat ")) {
            String rel = command.substring(4).trim();
            File f = resolvePath(w, rel);
            if (!f.exists() || !f.isFile()) {
                appendToWindow(w, "cat: " + rel + ": No such file\n");
                return;
            }
            if (f.length() > 65536) {
                appendToWindow(w, "cat: file too large to display inline (" + f.length() + " bytes)\n");
                return;
            }
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(f), "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    appendToWindow(w, line + "\n");
                }
            } catch (Exception e) {
                appendToWindow(w, "cat error: " + e.getMessage() + "\n");
            }
            return;
        }

        if (command.equals("cd") || command.startsWith("cd ")) {
            String path = command.length() == 2 ? (isTermuxAvailable() ? DEFAULT_HOME : standaloneHome.getAbsolutePath()) : command.substring(3).trim();
            if ((path.startsWith("\"") && path.endsWith("\"")) || (path.startsWith("'") && path.endsWith("'"))) {
                if (path.length() >= 2) path = path.substring(1, path.length() - 1);
            }
            try {
                File next = resolvePath(w, path);
                w.workingDir = next.getCanonicalFile();
                preferences.edit().putString("working_directory", w.workingDir.getAbsolutePath()).apply();
                updateInputState();
            } catch (Exception e) {
                appendToWindow(w, "cd: " + e.getMessage() + "\n");
            }
            return;
        }

        if (command.equals("repo") || command.startsWith("repo ")) {
            handleRepoCommand(w, command.length() == 4 ? "help" : command.substring(5).trim());
            return;
        }

        String installTarget = extractInteractiveInstallTarget(command);
        if (installTarget != null && !installTarget.isEmpty()) {
            w.pendingInstallPackage = installTarget;
            w.pendingStandalonePkg = installTarget;
            w.awaitingConfirm = true;
            String promptMsg = "Reading package lists... Done\nBuilding dependency tree... Done\nThe following NEW packages will be installed:\n  " + installTarget + "\nDo you want to continue? [Y/n] ";
            w.confirmPromptText = "Do you want to continue? [Y/n]";
            appendToWindow(w, promptMsg);
            if (w == currentWindow()) {
                showConfirmBanner(w.confirmPromptText);
                updateInputState();
                focusTerminalInput();
            }
            return;
        }

        if (!isTermuxAvailable() && !command.contains(">")) {
            if (command.startsWith("echo ")) {
                String msg = command.substring(5);
                if ((msg.startsWith("\"") && msg.endsWith("\"") && msg.length() >= 2) ||
                    (msg.startsWith("'") && msg.endsWith("'") && msg.length() >= 2)) {
                    msg = msg.substring(1, msg.length() - 1);
                }
                appendToWindow(w, msg + "\n");
                return;
            }
            if (command.equals("echo")) {
                appendToWindow(w, "\n");
                return;
            }
        }
        if (command.equals("uname") || command.startsWith("uname ")) {
            appendToWindow(w, "Linux android " + Build.VERSION.RELEASE + " " + Build.SUPPORTED_ABIS[0] + " Android\n");
            return;
        }
        if (command.equals("whoami")) {
            appendToWindow(w, "app_standalone\n");
            return;
        }
        if (command.startsWith("mkdir ")) {
            String target = command.substring(6).replace("-p", "").trim();
            File d = resolvePath(w, target);
            if (d.mkdirs() || d.exists()) {
                appendToWindow(w, "Created directory: " + d.getAbsolutePath() + "\n");
            } else {
                appendToWindow(w, "mkdir: failed to create '" + target + "'\n");
            }
            return;
        }
        if (command.startsWith("touch ")) {
            String target = command.substring(6).trim();
            File f = resolvePath(w, target);
            try {
                if (f.getParentFile() != null) f.getParentFile().mkdirs();
                if (f.createNewFile() || f.exists()) {
                    appendToWindow(w, "Touched: " + f.getAbsolutePath() + "\n");
                }
            } catch (Exception e) {
                appendToWindow(w, "touch error: " + e.getMessage() + "\n");
            }
            return;
        }
        if (command.startsWith("rm ")) {
            String raw = command.substring(3).trim();
            boolean recursive = false;
            if (raw.startsWith("-rf ")) { recursive = true; raw = raw.substring(4).trim(); }
            else if (raw.startsWith("-r ")) { recursive = true; raw = raw.substring(3).trim(); }
            File f = resolvePath(w, raw);
            if (!f.exists()) {
                appendToWindow(w, "rm: cannot remove '" + raw + "': No such file or directory\n");
            } else if (deleteRecursive(f, recursive)) {
                appendToWindow(w, "Removed: " + f.getAbsolutePath() + "\n");
            } else {
                appendToWindow(w, "rm: failed to remove '" + raw + "' (use -r for directories)\n");
            }
            return;
        }

        if (isTermuxAvailable()) {
            executeTermuxShellCommand(w, command);
        } else if (command.startsWith("pkg install ") || command.startsWith("apt install ")) {
            String target = command.replaceFirst("^(?:pkg|apt)\\s+install\\s+", "").replace("-y", "").trim();
            if (!target.isEmpty()) {
                installStandaloneRepoPackage(w, target);
            } else {
                appendToWindow(w, "Usage: pkg install <package_name>\n");
            }
        } else {
            appendToWindow(w,
                "Standalone mode (No Termux installed).\n" +
                "Available commands: repo list, repo install <pkg>, pkg install <pkg>, ls, cd, pwd, cat, mkdir, touch, rm, echo, uname, whoami, clear, unlock.\n");
        }
    }

    private boolean deleteRecursive(File target, boolean recursive) {
        if (target == null || !target.exists()) return false;
        if (target.isDirectory()) {
            File[] children = target.listFiles();
            if (children != null && children.length > 0 && !recursive) return false;
            if (children != null) {
                for (File c : children) {
                    if (!deleteRecursive(c, true)) return false;
                }
            }
        }
        return target.delete();
    }

    private File resolvePath(TerminalWindow w, String rawPath) {
        String homePath = isTermuxAvailable() ? DEFAULT_HOME : standaloneHome.getAbsolutePath();
        String p = rawPath == null ? "" : rawPath.trim();
        if (p.isEmpty() || "~".equals(p)) {
            return new File(homePath);
        }
        if (p.startsWith("~/")) {
            p = homePath + "/" + p.substring(2);
        } else if ("sdcard".equals(p) || "/sdcard".equals(p)) {
            p = Environment.getExternalStorageDirectory().getAbsolutePath();
        } else if (p.startsWith("sdcard/")) {
            p = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + p.substring(7);
        }
        File next = new File(p);
        if (!next.isAbsolute()) {
            next = new File(w.workingDir, p);
        }
        return next;
    }

    private void handleRepoCommand(TerminalWindow w, String args) {
        if (args.isEmpty() || args.equals("help")) {
            appendToWindow(w,
                "Repository Client Commands (Standalone / No Termux needed):\n" +
                "  repo select               Pick active repo from a list dialog\n" +
                "  repo use <index|url>      Set active repo by index or URL\n" +
                "  repo presets              Show built-in Termux/Standalone repo presets\n" +
                "  repo sources              Show active repository URLs (marks [ACTIVE])\n" +
                "  repo add <url>            Add a repository URL (.json index or base URL)\n" +
                "  repo remove <index|url>   Remove a repository source\n" +
                "  repo list                 Connect to repos & list available packages\n" +
                "  repo install <pkg|url>    Download & install package (.zip / script / text)\n" +
                "  repo installed            Show installed packages in standalone prefix\n");
            return;
        }

        if (args.equals("select") || args.equals("choose") || args.equals("pick")) {
            showRepoSelectorDialog(w);
            return;
        }

        if (args.equals("presets")) {
            appendToWindow(w, "Built-in Repository Presets (use 'repo use <url>' or 'repo add <url>'):\n");
            for (int i = 0; i < PRESET_REPOS.length; i++) {
                appendToWindow(w, "  " + PRESET_REPOS[i][0] + "\n      " + PRESET_REPOS[i][1] + "\n");
            }
            return;
        }

        if (args.startsWith("use ")) {
            String target = args.substring(4).trim();
            if (target.isEmpty()) {
                appendToWindow(w, "Usage: repo use <index|url>\n");
                return;
            }
            int matchedIndex = -1;
            try {
                int idx = Integer.parseInt(target);
                if (idx >= 0 && idx < repoSources.size()) {
                    matchedIndex = idx;
                }
            } catch (NumberFormatException ignored) { }
            if (matchedIndex < 0) {
                for (int i = 0; i < repoSources.size(); i++) {
                    if (repoSources.get(i).equals(target)) {
                        matchedIndex = i;
                        break;
                    }
                }
            }
            if (matchedIndex < 0 && (target.startsWith("http://") || target.startsWith("https://"))) {
                repoSources.add(target);
                matchedIndex = repoSources.size() - 1;
            }
            if (matchedIndex >= 0) {
                activeRepoIndex = matchedIndex;
                saveRepoSources();
                appendToWindow(w, "Active repo [" + activeRepoIndex + "]: " + getSelectedRepoUrl() + "\n");
            } else {
                appendToWindow(w, "Repo not found: " + target + ". Type 'repo sources' or 'repo select'.\n");
            }
            return;
        }

        if (args.equals("sources")) {
            appendToWindow(w, "Configured repositories (" + repoSources.size() + "):\n");
            for (int i = 0; i < repoSources.size(); i++) {
                String activeTag = (i == activeRepoIndex) ? " [ACTIVE]" : "";
                appendToWindow(w, "  [" + i + "]" + activeTag + " " + repoSources.get(i) + "\n");
            }
            return;
        }

        if (args.startsWith("add ")) {
            String url = args.substring(4).trim();
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                appendToWindow(w, "repo add: URL must start with http:// or https://\n");
                return;
            }
            if (!repoSources.contains(url)) {
                repoSources.add(url);
                saveRepoSources();
            }
            appendToWindow(w, "Added repository: " + url + "\n");
            return;
        }

        if (args.startsWith("remove ")) {
            String target = args.substring(7).trim();
            boolean removed = false;
            try {
                int idx = Integer.parseInt(target);
                if (idx >= 0 && idx < repoSources.size()) {
                    repoSources.remove(idx);
                    removed = true;
                }
            } catch (NumberFormatException ignored) { }
            if (!removed) {
                removed = repoSources.remove(target);
            }
            if (removed) {
                saveRepoSources();
                appendToWindow(w, "Removed repository source.\n");
            } else {
                appendToWindow(w, "Repository source not found: " + target + "\n");
            }
            return;
        }

        if (args.equals("installed")) {
            File[] pkgs = standalonePackagesDir.listFiles();
            if (pkgs == null || pkgs.length == 0) {
                appendToWindow(w, "No packages installed yet in " + standalonePackagesDir.getAbsolutePath() + "\n");
            } else {
                appendToWindow(w, "Installed packages:\n");
                for (File f : pkgs) {
                    appendToWindow(w, "  - " + f.getName() + "\n");
                }
            }
            return;
        }

        if (args.equals("list") || args.equals("update")) {
            fetchRepoCatalog(w, false);
            return;
        }
        if (args.equals("list all") || args.equals("update all")) {
            fetchRepoCatalog(w, true);
            return;
        }

        if (args.startsWith("install ")) {
            String pkgOrUrl = args.substring(8).trim();
            if (pkgOrUrl.isEmpty()) {
                appendToWindow(w, "Usage: repo install <package_name_or_url>\n");
                return;
            }
            installStandaloneRepoPackage(w, pkgOrUrl);
            return;
        }

        appendToWindow(w, "Unknown repo subcommand '" + args + "'. Type 'repo help'.\n");
    }

    private void fetchRepoCatalog(final TerminalWindow w, final boolean fetchAll) {
        w.commandRunning = true;
        w.commandStartedAt = System.currentTimeMillis();
        if (w == currentWindow()) updateInputState();
        commandHandler.removeCallbacks(commandTimeout);
        commandHandler.postDelayed(commandTimeout, 60000L);

        final List<String> targets = new ArrayList<>();
        if (fetchAll) {
            targets.addAll(repoSources);
        } else {
            targets.add(getSelectedRepoUrl());
        }

        appendToWindow(w, "Connecting to " + (fetchAll ? "all repositories" : "selected repo [" + activeRepoIndex + "]") + "...\n");

        bgExecutor.execute(() -> {
            final StringBuilder sb = new StringBuilder();
            for (String repoUrl : targets) {
                sb.append("Repo: ").append(repoUrl).append("\n");
                try {
                    String body = httpGetString(repoUrl, 15000);
                    String trimmed = body.trim();
                    if (trimmed.startsWith("{")) {
                        JSONObject json = new JSONObject(trimmed);
                        JSONArray pkgs = json.optJSONArray("packages");
                        if (pkgs != null && pkgs.length() > 0) {
                            int limit = Math.min(pkgs.length(), 40);
                            for (int i = 0; i < limit; i++) {
                                Object item = pkgs.get(i);
                                if (item instanceof JSONObject) {
                                    JSONObject pObj = (JSONObject) item;
                                    String name = pObj.optString("name", "unknown");
                                    String ver = pObj.optString("version", "");
                                    String desc = pObj.optString("description", "");
                                    sb.append("  - ").append(name);
                                    if (!ver.isEmpty()) sb.append(" (").append(ver).append(")");
                                    if (!desc.isEmpty()) sb.append(": ").append(desc);
                                    sb.append("\n");
                                } else {
                                    sb.append("  - ").append(String.valueOf(item)).append("\n");
                                }
                            }
                            if (pkgs.length() > limit) {
                                sb.append("  ... and ").append(pkgs.length() - limit).append(" more packages.\n");
                            }
                        } else {
                            sb.append("  (Connected - index loaded, no 'packages' array in JSON)\n");
                        }
                    } else {
                        // Parse Debian/Termux APT `Packages` stanza format
                        List<String> parsed = parseDebPackagesSummary(body, 35);
                        if (!parsed.isEmpty()) {
                            for (String entry : parsed) {
                                sb.append("  - ").append(entry).append("\n");
                            }
                        } else {
                            sb.append("  (Connected - APT index fetched, ").append(body.length()).append(" bytes)\n");
                        }
                    }
                } catch (Exception e) {
                    sb.append("  [Connection info: ").append(e.getMessage()).append("]\n");
                }
            }
            sb.append("Tip: Use 'repo install <pkg>' (downloads .deb/package) or 'pkg install <pkg>' when Termux is linked.\n");

            runOnUiThread(() -> {
                commandHandler.removeCallbacks(commandTimeout);
                w.commandRunning = false;
                w.commandStartedAt = 0L;
                appendToWindow(w, sb.toString());
                if (w == currentWindow()) updateInputState();
            });
        });
    }

    private List<String> parseDebPackagesSummary(String rawIndex, int maxItems) {
        List<String> out = new ArrayList<>();
        String[] blocks = rawIndex.split("\n\\s*\n");
        for (String block : blocks) {
            if (out.size() >= maxItems) break;
            String pkg = null;
            String ver = null;
            for (String line : block.split("\n")) {
                if (line.startsWith("Package: ")) {
                    pkg = line.substring(9).trim();
                } else if (line.startsWith("Version: ")) {
                    ver = line.substring(9).trim();
                }
            }
            if (pkg != null && !pkg.isEmpty()) {
                out.add(ver != null && !ver.isEmpty() ? (pkg + " (" + ver + ")") : pkg);
            }
        }
        return out;
    }

    private String findDebFilenameInAptIndex(String rawIndex, String targetPkg) {
        String[] blocks = rawIndex.split("\n\\s*\n");
        for (String block : blocks) {
            String pkg = null;
            String filename = null;
            for (String line : block.split("\n")) {
                if (line.startsWith("Package: ")) {
                    pkg = line.substring(9).trim();
                } else if (line.startsWith("Filename: ")) {
                    filename = line.substring(10).trim();
                }
            }
            if (pkg != null && pkg.equalsIgnoreCase(targetPkg) && filename != null && !filename.isEmpty()) {
                return filename;
            }
        }
        return null;
    }

    private void installStandaloneRepoPackage(final TerminalWindow w, final String pkgOrUrl) {
        w.commandRunning = true;
        w.commandStartedAt = System.currentTimeMillis();
        if (w == currentWindow()) updateInputState();
        commandHandler.removeCallbacks(commandTimeout);
        commandHandler.postDelayed(commandTimeout, 90000L);

        appendToWindow(w, "Resolving & downloading '" + pkgOrUrl + "'...\n");

        bgExecutor.execute(() -> {
            final StringBuilder log = new StringBuilder();
            try {
                String resolvedUrl = null;
                String pkgName = pkgOrUrl;

                if (pkgOrUrl.startsWith("http://") || pkgOrUrl.startsWith("https://")) {
                    resolvedUrl = pkgOrUrl;
                    String pathPart = Uri.parse(pkgOrUrl).getLastPathSegment();
                    pkgName = (pathPart != null && !pathPart.isEmpty()) ? pathPart : "custom-pkg";
                } else {
                    for (String repoUrl : repoSources) {
                        try {
                            String body = httpGetString(repoUrl, 12000);
                            String trimmed = body.trim();
                            if (trimmed.startsWith("{")) {
                                JSONObject json = new JSONObject(trimmed);
                                JSONArray pkgs = json.optJSONArray("packages");
                                if (pkgs != null) {
                                    for (int i = 0; i < pkgs.length(); i++) {
                                        JSONObject pObj = pkgs.optJSONObject(i);
                                        if (pObj != null && pkgOrUrl.equalsIgnoreCase(pObj.optString("name", ""))) {
                                            resolvedUrl = pObj.optString("url", null);
                                            break;
                                        }
                                    }
                                }
                            } else {
                                String debRelPath = findDebFilenameInAptIndex(body, pkgOrUrl);
                                if (debRelPath != null) {
                                    String basePrefix = repoUrl.contains("/dists/")
                                        ? repoUrl.substring(0, repoUrl.indexOf("/dists/"))
                                        : TERMUX_MIRROR_BASE;
                                    resolvedUrl = basePrefix + "/" + debRelPath;
                                    String lastSeg = Uri.parse(debRelPath).getLastPathSegment();
                                    if (lastSeg != null && !lastSeg.isEmpty()) pkgName = lastSeg;
                                }
                            }
                        } catch (Exception ignored) { }
                        if (resolvedUrl != null) break;
                    }
                }

                if (resolvedUrl == null) {
                    log.append("Package '" + pkgOrUrl + "' not found in configured repo indexes.\n");
                    log.append("Add a repo index via 'repo add <url>' or pass a direct URL: 'repo install https://.../file.zip'\n");
                } else {
                    File destFile = new File(standalonePackagesDir, sanitizeFileName(pkgName));
                    long bytes = downloadToFile(resolvedUrl, destFile, 25000);
                    log.append("Downloaded " + bytes + " bytes -> " + destFile.getAbsolutePath() + "\n");

                    if (destFile.getName().toLowerCase().endsWith(".zip")) {
                        File extractDir = new File(standaloneUsr, "opt/" + stripExtension(destFile.getName()));
                        extractDir.mkdirs();
                        int extracted = unzipFile(destFile, extractDir);
                        log.append("Extracted " + extracted + " entries into " + extractDir.getAbsolutePath() + "\n");
                    }
                    File dbFile = new File(standalonePackagesDir, "installed_packages.txt");
                    try (FileOutputStream dbOut = new FileOutputStream(dbFile, true)) {
                        String entryLine = pkgOrUrl + " -> " + destFile.getName() + "\n";
                        dbOut.write(entryLine.getBytes("UTF-8"));
                    } catch (Exception ignored) { }
                    log.append("Setting up " + pkgOrUrl + " ...\n");
                    log.append("Installed '" + pkgOrUrl + "' (" + destFile.getName() + ") in standalone prefix.\n");
                }
            } catch (Exception e) {
                log.append("Install error: " + e.getMessage() + "\n");
            }

            runOnUiThread(() -> {
                commandHandler.removeCallbacks(commandTimeout);
                w.commandRunning = false;
                w.commandStartedAt = 0L;
                appendToWindow(w, log.toString());
                if (w == currentWindow()) updateInputState();
            });
        });
    }

    private String httpGetString(String urlStr, int timeoutMs) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "TermuxVision-StandaloneRepo/1.0");
            int code = conn.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            if (is == null) throw new Exception("HTTP " + code);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line).append("\n");
            }
            reader.close();
            if (code < 200 || code >= 300) {
                throw new Exception("HTTP " + code);
            }
            return out.toString();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private long downloadToFile(String urlStr, File outFile, int timeoutMs) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setRequestProperty("User-Agent", "TermuxVision-StandaloneRepo/1.0");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            long total = 0L;
            try (InputStream in = new BufferedInputStream(conn.getInputStream());
                 FileOutputStream fos = new FileOutputStream(outFile)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    fos.write(buf, 0, n);
                    total += n;
                }
                fos.flush();
            }
            return total;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private int unzipFile(File zipFile, File targetDir) throws Exception {
        int count = 0;
        String canonicalTarget = targetDir.getCanonicalPath() + File.separator;
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new java.io.FileInputStream(zipFile)))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                File out = new File(targetDir, entry.getName());
                String canonicalOut = out.getCanonicalPath();
                if (!canonicalOut.startsWith(canonicalTarget)) {
                    throw new SecurityException("Blocked zip slip path: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    out.mkdirs();
                } else {
                    if (out.getParentFile() != null) out.getParentFile().mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = zis.read(buf)) != -1) {
                            fos.write(buf, 0, n);
                        }
                    }
                    count++;
                }
                zis.closeEntry();
            }
        }
        return count;
    }

    private String sanitizeFileName(String name) {
        String clean = name.replaceAll("[^A-Za-z0-9._-]", "_");
        return clean.isEmpty() ? "package.bin" : clean;
    }

    private String stripExtension(String name) {
        int idx = name.lastIndexOf('.');
        return idx > 0 ? name.substring(0, idx) : name;
    }

    private void executeTermuxShellCommand(TerminalWindow w, String command) {
        int id = executionIds.incrementAndGet();
        w.activeSessionToken = UUID.randomUUID().toString().replace("-", "");
        w.activeExecId = id;
        w.activeSessionReceivedLines = false;
        w.commandRunning = true;
        w.commandStartedAt = System.currentTimeMillis();
        if (w == currentWindow()) {
            updateInputState();
        }
        commandHandler.removeCallbacks(commandTimeout);
        commandHandler.postDelayed(commandTimeout, 180000L);

        try {
            Intent callback = new Intent(this, TermuxResultService.class);
            callback.setData(Uri.parse("termuxvision://result/" + id + "/" + w.activeSessionToken));
            callback.putExtra("session_token", w.activeSessionToken);
            callback.putExtra("exec_id", id);

            int piFlags = PendingIntent.FLAG_ONE_SHOT;
            if (Build.VERSION.SDK_INT >= 31) piFlags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent resultIntent = PendingIntent.getService(this, id, callback, piFlags);

            String quote = Character.toString((char) 34);
            String script = "{\n" + command + "\n} </dev/null 2>&1 | while IFS= read -r line || [ -n " + quote + "$line" + quote + " ]; do\n"
                + "safe_line=$(printf '%s' " + quote + "$line" + quote + " | sed \"s/'/'\\\\''/g\")\n"
                + "/data/data/com.termux/files/usr/bin/am broadcast -n com.example.customterminal/.TermuxLogReceiver -a com.example.customterminal.TERMUX_LOG --es session_token '" + w.activeSessionToken + "' --es line \"'$safe_line'\" >/dev/null 2>&1\n"
                + "printf '%s\\n' " + quote + "$line" + quote + "\n"
                + "done\ncommand_status=${PIPESTATUS[0]}\nexit " + quote + "$command_status" + quote;

            Intent intent = new Intent("com.termux.RUN_COMMAND");
            intent.setClassName(TERMUX_PACKAGE, "com.termux.app.RunCommandService");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", script});
            String termuxCwd = w.workingDir.getAbsolutePath().startsWith("/data/data/com.termux/")
                ? w.workingDir.getAbsolutePath()
                : DEFAULT_HOME;
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", termuxCwd);
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            intent.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", "termux-vision command");
            intent.putExtra("com.termux.RUN_COMMAND_COMMAND_DESCRIPTION", "Command submitted from termux-vision");
            intent.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", resultIntent);

            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    startService(intent);
                } catch (IllegalStateException fgEx) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { startForegroundService(intent); } else { startService(intent); }
                }
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            appendToWindow(w, "Could not start Termux command: " + e.getMessage() + "\nCheck permission and allow-external-apps.\n");
            forceUnlockWindow(w, false);
        }
    }

    private void openStandaloneNanoEditor(final TerminalWindow w, final File file) {
        String existingText = "";
        if (file.exists() && file.isFile()) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(file), "UTF-8"))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    if (sb.length() > 0) sb.append("\n");
                    sb.append(line);
                }
                existingText = sb.toString();
            } catch (Exception ignored) { }
        }

        final EditText editor = new EditText(this);
        editor.setText(existingText);
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setTextSize(13);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setMinLines(10);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(4));
        box.addView(editor, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(this)
            .setTitle("GNU nano - " + file.getName())
            .setView(box)
            .setNegativeButton("Cancel (^X)", null)
            .setPositiveButton("Save (^O)", (dialog, which) -> {
                try {
                    if (file.getParentFile() != null) file.getParentFile().mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(file)) {
                        fos.write(editor.getText().toString().getBytes("UTF-8"));
                    }
                    appendToWindow(w, "Wrote " + file.getName() + " (" + file.length() + " bytes)\n");
                } catch (Exception e) {
                    appendToWindow(w, "nano save error: " + e.getMessage() + "\n");
                }
            })
            .show();
    }

    private void showPageDialog(String title, String body) {
        ScrollView sv = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(body);
        tv.setTextSize(13.5f);
        tv.setLineSpacing(0, 1.2f);
        tv.setPadding(dp(20), dp(14), dp(20), dp(14));
        tv.setTextIsSelectable(true);
        sv.addView(tv);

        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(sv)
            .setPositiveButton("Close", null)
            .show();
    }

    private void showHelpPageDialog() {
        String text =
            "HELP & COMMAND REFERENCE\n" +
            "----------------------------------------\n\n" +
            "1. Terminal & Navigation:\n" +
            "   pwd                  Show current directory\n" +
            "   ls [path]            List files in current or target folder\n" +
            "   cd <dir>             Change directory (~ = home, /sdcard = storage)\n" +
            "   cat <file>           Read text file contents\n" +
            "   nano <file>          Edit or create text files\n" +
            "   mkdir <dir>          Create a new folder\n" +
            "   touch <file>         Create an empty file\n" +
            "   rm [-rf] <target>    Remove file or directory\n\n" +
            "2. Storage Explorer Commands:\n" +
            "   storage / sdcard     Open interactive storage file browser\n" +
            "   storage-grant        Request Android storage access permission\n" +
            "   ls /sdcard           List internal shared storage files\n\n" +
            "3. Built-in Terminal Media Player:\n" +
            "   media / player       Pick audio or video file from storage\n" +
            "   play <file>          Play music or video right inside terminal\n" +
            "   music <file.mp3>     Play audio file in embedded player\n" +
            "   video <file.mp4>     Play video inside terminal screen\n" +
            "   stopmedia            Stop and close embedded media player\n\n" +
            "4. Root (`su`) Commands (Rooted Devices Only):\n" +
            "   su                   Verify root UID/GID (`id`)\n" +
            "   su <command>         Run privileged shell command via `su -c`\n" +
            "   su -c \"<cmd>\"       Execute root command string\n\n" +
            "5. Repository & Termux Commands:\n" +
            "   repo select          Pick active package repository\n" +
            "   repo list            List packages in active repo\n" +
            "   repo install <pkg>   Download/install package\n" +
            "   setname <name>       Change prompt name (e.g. mark@terminal $)\n" +
            "   clear / unlock       Clear screen or unlock stuck command\n\n" +
            "6. Information Pages:\n" +
            "   helppage             Open this Help Page\n" +
            "   howto                Open How To Use Page\n" +
            "   pro                  Open For Professional Use Only Notice";
        showPageDialog("Help Page", text);
    }

    private void showHowToUsePageDialog() {
        String text =
            "HOW TO USE THIS TERMINAL APP\n" +
            "----------------------------------------\n\n" +
            "Step 1: Set Your Prompt Name\n" +
            "  - Enter your name on first launch or type: setname mark\n" +
            "  - Your prompt will display as: mark@terminal $\n\n" +
            "Step 2: Browse & Manage Storage Files\n" +
            "  - Type 'storage-grant' (or tap Storage in menu/drawer) to allow file access.\n" +
            "  - Use 'cd /sdcard' and 'ls' to inspect Downloads, Music, Movies, and folders.\n" +
            "  - Type 'storage' to tap through folders, view files, or play media directly.\n\n" +
            "Step 3: Play Music & Videos Inside the Terminal\n" +
            "  - Type 'play /sdcard/Music/song.mp3' or 'play /sdcard/Movies/clip.mp4'.\n" +
            "  - Or type 'media' to browse and pick any audio/video file.\n" +
            "  - Playback controls (Play/Pause, Seekbar, Stop) appear right at the top of the terminal screen.\n\n" +
            "Step 4: Run Root Commands (`su`) on Rooted Devices\n" +
            "  - If your device is rooted (Magisk / KernelSU / SuperSU), type:\n" +
            "      su id\n" +
            "      su ls -la /data\n" +
            "  - Approve the superuser prompt on your device when requested.\n\n" +
            "Step 5: Install Packages via Repo or Termux\n" +
            "  - Type 'repo select' to choose a repository, 'repo list' to view packages, and 'repo install <pkg>' to download.\n" +
            "  - If Termux is installed with RUN_COMMAND granted and allow-external-apps=true, shell commands forward to Termux.";
        showPageDialog("How To Use Page", text);
    }

    private void showProfessionalOnlyPageDialog() {
        String text =
            "FOR PROFESSIONAL USE ONLY\n" +
            "----------------------------------------\n\n" +
            "INTENDED AUDIENCE & AUTHORIZED ADMINISTRATION:\n" +
            "This terminal environment—including root (`su`) command execution, system file inspection, package repository management, and shell scripting—is designed strictly for qualified developers, system administrators, security researchers, and authorized device owners.\n\n" +
            "RESPONSIBLE USE GUIDELINES:\n" +
            "1. Device Ownership & Authorization: Only execute privileged (`su`) or file-modifying commands on devices and storage volumes you own or have explicit authorization to administer.\n" +
            "2. System Integrity Risk: Root (`su`) commands bypass standard Android sandbox protections. Modifying `/system`, `/vendor`, `/data`, or kernel parameters improperly can cause bootloops or permanent data loss.\n" +
            "3. Data Privacy & Backups: Always back up critical files in `/sdcard` before running recursive delete (`rm -rf`) or root shell operations.\n" +
            "4. Compliance: Use network, repository, and shell utilities strictly in compliance with local laws and platform policies.";
        showPageDialog("For Professional Use Only", text);
    }

    private boolean hasStorageReadAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) return true;
        }
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission("android.permission.READ_MEDIA_AUDIO") == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission("android.permission.READ_MEDIA_VIDEO") == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestStoragePermissionsNow(TerminalWindow w) {
        if (Build.VERSION.SDK_INT >= 23) {
            ArrayList<String> perms = new ArrayList<>();
            perms.add("android.permission.READ_EXTERNAL_STORAGE");
            perms.add("android.permission.WRITE_EXTERNAL_STORAGE");
            if (Build.VERSION.SDK_INT >= 33) {
                perms.add("android.permission.READ_MEDIA_AUDIO");
                perms.add("android.permission.READ_MEDIA_VIDEO");
            }
            requestPermissions(perms.toArray(new String[0]), 44);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                if (w != null) {
                    appendToWindow(w, "Opened Android 'All files access' settings. Enable access so all /sdcard folders are visible.\n");
                }
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception ignored) { }
            }
        } else if (w != null) {
            appendToWindow(w, "Storage access is active for " + Environment.getExternalStorageDirectory().getAbsolutePath() + "\n");
        }
    }

    private void ensureStorageAccessAndBrowse(TerminalWindow w, boolean openDialog) {
        if (!hasStorageReadAccess()) {
            appendToWindow(w, "Storage permission needed. Requesting access...\n");
            requestStoragePermissionsNow(w);
        }
        File sdcard = Environment.getExternalStorageDirectory();
        File[] list = sdcard.listFiles();
        if (list == null) {
            appendToWindow(w, "Cannot list " + sdcard.getAbsolutePath() + " yet. Grant storage permission and run 'storage' again.\n");
            return;
        }
        appendToWindow(w, "Storage (" + sdcard.getAbsolutePath() + "): " + list.length + " items\n");
        for (File f : list) {
            appendToWindow(w, "  " + (f.isDirectory() ? "[DIR]  " : "[FILE] ") + f.getName() + "\n");
        }
        if (openDialog) {
            openStorageFileBrowser(sdcard);
        }
    }

    private void openStorageFileBrowser(final File dir) {
        if (!hasStorageReadAccess()) {
            requestStoragePermissionsNow(currentWindow());
        }
        final File currentDir = (dir != null && dir.exists() && dir.isDirectory())
            ? dir
            : Environment.getExternalStorageDirectory();
        File[] rawFiles = currentDir.listFiles();
        if (rawFiles == null) {
            Toast.makeText(this, "Grant All Files Access first to browse " + currentDir.getAbsolutePath(), Toast.LENGTH_LONG).show();
            requestStoragePermissionsNow(currentWindow());
            return;
        }
        final ArrayList<File> entries = new ArrayList<>();
        File parent = currentDir.getParentFile();
        if (parent != null && parent.canRead()) {
            entries.add(parent);
        }
        Arrays.sort(rawFiles, (a, b) -> {
            if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
            return a.getName().compareToIgnoreCase(b.getName());
        });
        entries.addAll(Arrays.asList(rawFiles));

        String[] labels = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) {
            File f = entries.get(i);
            if (parent != null && i == 0 && f.equals(parent)) {
                labels[i] = ".. (Parent Folder)";
            } else if (f.isDirectory()) {
                labels[i] = "[DIR] " + f.getName();
            } else {
                labels[i] = f.getName() + " (" + formatReadableSize(f.length()) + ")";
            }
        }

        new AlertDialog.Builder(this)
            .setTitle("Storage: " + currentDir.getAbsolutePath())
            .setItems(labels, (dialog, which) -> {
                File picked = entries.get(which);
                if (picked.isDirectory()) {
                    openStorageFileBrowser(picked);
                } else {
                    handlePickedStorageFile(picked);
                }
            })
            .setNeutralButton("cd Here", (dialog, which) -> {
                TerminalWindow w = currentWindow();
                if (w != null) {
                    w.workingDir = currentDir;
                    preferences.edit().putString("working_directory", w.workingDir.getAbsolutePath()).apply();
                    syncWindowUi();
                    appendToWindow(w, "Changed directory to: " + currentDir.getAbsolutePath() + "\n");
                }
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private String formatReadableSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private boolean isAudioFileName(String name) {
        String n = name.toLowerCase();
        return n.endsWith(".mp3") || n.endsWith(".wav") || n.endsWith(".m4a") || n.endsWith(".ogg") || n.endsWith(".flac") || n.endsWith(".aac");
    }

    private boolean isVideoFileName(String name) {
        String n = name.toLowerCase();
        return n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".webm") || n.endsWith(".3gp") || n.endsWith(".avi") || n.endsWith(".mov");
    }

    private void handlePickedStorageFile(final File file) {
        TerminalWindow w = currentWindow();
        if (isAudioFileName(file.getName())) {
            playMediaInTerminal(w, file, false);
        } else if (isVideoFileName(file.getName())) {
            playMediaInTerminal(w, file, true);
        } else {
            String[] actions = {"Open in Text Editor (nano)", "Print Content (cat)", "Play as Audio", "Play as Video"};
            new AlertDialog.Builder(this)
                .setTitle(file.getName())
                .setItems(actions, (d, which) -> {
                    if (which == 0) openStandaloneNanoEditor(w, file);
                    else if (which == 1) {
                        input.setText("cat \"" + file.getAbsolutePath() + "\"");
                        runCommand();
                    } else if (which == 2) {
                        playMediaInTerminal(w, file, false);
                    } else if (which == 3) {
                        playMediaInTerminal(w, file, true);
                    }
                })
                .show();
        }
    }

    private void showMediaPickerDialog() {
        openStorageFileBrowser(Environment.getExternalStorageDirectory());
    }

    private void buildInlineMediaPlayerCard() {
        mediaPlayerCard = new LinearLayout(this);
        mediaPlayerCard.setOrientation(LinearLayout.VERTICAL);
        mediaPlayerCard.setBackgroundColor(0xE6111827);
        mediaPlayerCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        mediaPlayerCard.setVisibility(View.GONE);

        mediaTitleText = new TextView(this);
        mediaTitleText.setTextColor(0xFF38BDF8);
        mediaTitleText.setTextSize(12);
        mediaTitleText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        mediaTitleText.setSingleLine(true);
        mediaTitleText.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        mediaPlayerCard.addView(mediaTitleText, new LinearLayout.LayoutParams(-1, -2));

        mediaStatusText = new TextView(this);
        mediaStatusText.setTextColor(0xFFE5E7EB);
        mediaStatusText.setTextSize(11);
        mediaStatusText.setTypeface(Typeface.MONOSPACE);
        mediaPlayerCard.addView(mediaStatusText, new LinearLayout.LayoutParams(-1, -2));

        inlineVideoView = new VideoView(this);
        inlineVideoView.setVisibility(View.GONE);
        LinearLayout.LayoutParams videoParams = new LinearLayout.LayoutParams(-1, dp(210));
        videoParams.topMargin = dp(6);
        videoParams.bottomMargin = dp(6);
        mediaPlayerCard.addView(inlineVideoView, videoParams);

        mediaSeekBar = new SeekBar(this);
        mediaSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                if (mediaIsVideo && inlineVideoView != null) {
                    inlineVideoView.seekTo(progress);
                } else if (activeAudioPlayer != null) {
                    activeAudioPlayer.seekTo(progress);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        mediaPlayerCard.addView(mediaSeekBar, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controlsRow = new LinearLayout(this);
        controlsRow.setOrientation(LinearLayout.HORIZONTAL);

        mediaPlayPauseBtn = new Button(this);
        mediaPlayPauseBtn.setText("PAUSE");
        mediaPlayPauseBtn.setTextSize(11);
        mediaPlayPauseBtn.setOnClickListener(v -> toggleInlineMediaPlayPause());
        controlsRow.addView(mediaPlayPauseBtn, new LinearLayout.LayoutParams(0, -2, 1f));

        mediaStopBtn = new Button(this);
        mediaStopBtn.setText("STOP / CLOSE");
        mediaStopBtn.setTextSize(11);
        mediaStopBtn.setOnClickListener(v -> stopInlineMediaPlayer());
        controlsRow.addView(mediaStopBtn, new LinearLayout.LayoutParams(0, -2, 1f));

        mediaPlayerCard.addView(controlsRow, new LinearLayout.LayoutParams(-1, -2));
    }

    private void playMediaInTerminal(final TerminalWindow w, final File file, boolean forceVideo) {
        if (file == null || !file.exists() || !file.isFile()) {
            if (w != null) {
                appendToWindow(w, "Media file not found: " + (file == null ? "" : file.getAbsolutePath()) + "\n");
            }
            return;
        }
        stopInlineMediaPlayer();
        boolean isVideo = forceVideo || isVideoFileName(file.getName());
        mediaIsVideo = isVideo;
        mediaPlayerCard.setVisibility(View.VISIBLE);
        mediaTitleText.setText((isVideo ? "[VIDEO PLAYER] " : "[MUSIC PLAYER] ") + file.getName());
        mediaStatusText.setText("Loading: " + file.getAbsolutePath());
        mediaPlayPauseBtn.setText("PAUSE");

        if (isVideo) {
            inlineVideoView.setVisibility(View.VISIBLE);
            inlineVideoView.setVideoURI(Uri.fromFile(file));
            inlineVideoView.setOnPreparedListener(mp -> {
                mediaSeekBar.setMax(Math.max(1, inlineVideoView.getDuration()));
                inlineVideoView.start();
                mediaStatusText.setText("Playing video inside terminal...");
                commandHandler.removeCallbacks(mediaProgressUpdater);
                commandHandler.post(mediaProgressUpdater);
            });
            inlineVideoView.setOnCompletionListener(mp -> {
                mediaStatusText.setText("Playback finished.");
                mediaPlayPauseBtn.setText("PLAY");
            });
            inlineVideoView.setOnErrorListener((mp, what, extra) -> {
                mediaStatusText.setText("Video playback error (" + what + ")");
                return true;
            });
            if (w != null) {
                appendToWindow(w, "[Playing video in terminal]: " + file.getName() + "\n");
            }
        } else {
            inlineVideoView.setVisibility(View.GONE);
            try {
                activeAudioPlayer = new MediaPlayer();
                activeAudioPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                );
                activeAudioPlayer.setDataSource(file.getAbsolutePath());
                activeAudioPlayer.setOnPreparedListener(mp -> {
                    mediaSeekBar.setMax(Math.max(1, mp.getDuration()));
                    mp.start();
                    mediaStatusText.setText("Playing audio inside terminal...");
                    commandHandler.removeCallbacks(mediaProgressUpdater);
                    commandHandler.post(mediaProgressUpdater);
                });
                activeAudioPlayer.setOnCompletionListener(mp -> {
                    mediaStatusText.setText("Track finished.");
                    mediaPlayPauseBtn.setText("PLAY");
                });
                activeAudioPlayer.prepareAsync();
                if (w != null) {
                    appendToWindow(w, "[Playing music in terminal]: " + file.getName() + "\n");
                }
            } catch (Exception e) {
                mediaStatusText.setText("Audio error: " + e.getMessage());
                if (w != null) {
                    appendToWindow(w, "Audio playback error: " + e.getMessage() + "\n");
                }
            }
        }
    }

    private void toggleInlineMediaPlayPause() {
        if (mediaIsVideo && inlineVideoView != null) {
            if (inlineVideoView.isPlaying()) {
                inlineVideoView.pause();
                mediaPlayPauseBtn.setText("PLAY");
                mediaStatusText.setText("Paused");
            } else {
                inlineVideoView.start();
                mediaPlayPauseBtn.setText("PAUSE");
                mediaStatusText.setText("Playing video...");
            }
        } else if (activeAudioPlayer != null) {
            if (activeAudioPlayer.isPlaying()) {
                activeAudioPlayer.pause();
                mediaPlayPauseBtn.setText("PLAY");
                mediaStatusText.setText("Paused");
            } else {
                activeAudioPlayer.start();
                mediaPlayPauseBtn.setText("PAUSE");
                mediaStatusText.setText("Playing audio...");
            }
        }
    }

    private void updateInlineMediaProgress() {
        try {
            int pos = 0;
            int dur = 0;
            if (mediaIsVideo && inlineVideoView != null) {
                pos = inlineVideoView.getCurrentPosition();
                dur = inlineVideoView.getDuration();
            } else if (activeAudioPlayer != null) {
                pos = activeAudioPlayer.getCurrentPosition();
                dur = activeAudioPlayer.getDuration();
            }
            if (dur > 0) {
                mediaSeekBar.setMax(dur);
                mediaSeekBar.setProgress(pos);
                mediaStatusText.setText(formatMs(pos) + " / " + formatMs(dur));
            }
        } catch (Exception ignored) { }
    }

    private String formatMs(int ms) {
        int totalSec = Math.max(0, ms / 1000);
        int min = totalSec / 60;
        int sec = totalSec % 60;
        return String.format(java.util.Locale.US, "%02d:%02d", min, sec);
    }

    private void stopInlineMediaPlayer() {
        commandHandler.removeCallbacks(mediaProgressUpdater);
        if (inlineVideoView != null) {
            try { inlineVideoView.stopPlayback(); } catch (Exception ignored) { }
            inlineVideoView.setVisibility(View.GONE);
        }
        if (activeAudioPlayer != null) {
            try {
                if (activeAudioPlayer.isPlaying()) activeAudioPlayer.stop();
                activeAudioPlayer.release();
            } catch (Exception ignored) { }
            activeAudioPlayer = null;
        }
        if (mediaPlayerCard != null) {
            mediaPlayerCard.setVisibility(View.GONE);
        }
    }

    private void executeRootSuCommand(final TerminalWindow w, final String rootCmd) {
        w.commandRunning = true;
        w.commandStartedAt = System.currentTimeMillis();
        if (w == currentWindow()) updateInputState();
        commandHandler.removeCallbacks(commandTimeout);
        commandHandler.postDelayed(commandTimeout, 60000L);

        appendToWindow(w, "[su] Executing root shell command: " + rootCmd + "\n");

        bgExecutor.execute(() -> {
            final StringBuilder out = new StringBuilder();
            int exitCode = -1;
            try {
                ProcessBuilder pb = new ProcessBuilder("su", "-c", rootCmd);
                pb.redirectErrorStream(true);
                Process proc = pb.start();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream(), "UTF-8"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        out.append(line).append("\n");
                    }
                }
                exitCode = proc.waitFor();
            } catch (Exception e) {
                out.append("[su error]: ").append(e.getMessage()).append("\n");
                out.append("Note: 'su' requires a rooted Android device (Magisk / KernelSU / SuperSU) with root access granted to this app.\n");
            }
            final int finalCode = exitCode;
            runOnUiThread(() -> {
                commandHandler.removeCallbacks(commandTimeout);
                w.commandRunning = false;
                w.commandStartedAt = 0L;
                if (out.length() > 0) {
                    appendToWindow(w, out.toString());
                }
                appendToWindow(w, "[su exit code: " + finalCode + "]\n");
                if (w == currentWindow()) updateInputState();
            });
        });
    }

    private void openFullScreenToolsDrawer() {
        closeDrawer();
        Intent intent = new Intent(this, ToolsDrawerActivity.class);
        startActivityForResult(intent, REQ_TOOLS_DRAWER);
    }

    private void animateTerminalEntry(View target) {
        if (target == null) return;
        target.setAlpha(0f);
        target.setTranslationY(dp(14));
        target.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(320)
            .start();
    }

    private void startNetHunterBootAnimation() {
        final TerminalWindow w = currentWindow();
        if (w == null) return;
        String uname = (shellUsername == null || shellUsername.trim().isEmpty()) ? "root" : shellUsername.trim();
        final String[] bootLines = {
            "┌──(" + uname + "㉿kali)-[/]\n",
            "└─# neofetch --animate\n",
            "        _,met$$$$$gg.          " + uname + "@kali\n",
            "     ,g$$$$$$$$$$$$$$$P.       ----------------\n",
            "   ,g$$P\"     \"\"\"Y$$.\"      OS: Kali / Android Shell arm64\n",
            "  ,$$P'              `$$$.     Host: Android Terminal Engine\n",
            "  ',$$P       ,ggs.     `$$b:   Shell: custom-sh + termux-bridge\n",
            "  `d$$'     ,$P\"'   .    $$$    UI: Full-Screen NetHunter Mode\n",
            "   $$P      d$'     ,    $$P    Status: Ready (su / storage / media)\n",
            "   $$:      $$.   -    ,d$$'\n",
            "   $$;      Y$b._   _,d$P'\n",
            "   Y$$.    `.`\"\"\"\"\"\"P'\n"
        };
        for (int i = 0; i < bootLines.length; i++) {
            final String chunk = bootLines[i];
            uiAnimHandler.postDelayed(() -> appendToWindow(w, chunk), i * 38L);
        }
    }

    @Override
    protected void onDestroy() {
        uiAnimHandler.removeCallbacks(cursorBlinkTask);
        uiAnimHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        stopInlineMediaPlayer();
        commandHandler.removeCallbacksAndMessages(null);
        bgExecutor.shutdownNow();
        super.onDestroy();
    }
}
