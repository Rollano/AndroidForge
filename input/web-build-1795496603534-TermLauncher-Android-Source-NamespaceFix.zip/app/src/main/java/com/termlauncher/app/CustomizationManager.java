package com.termlauncher.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class CustomizationManager {

    private static final String PREFS_NAME = "termlauncher_prefs";
    private static final String KEY_UI_STYLE = "ui_style_preset";
    private static final String KEY_PROMPT_STYLE = "prompt_style";
    private static final String KEY_SHOW_QUICK_CHIPS = "show_quick_chips";
    private static final String KEY_SHOW_APP_DOCK = "show_app_dock";
    private static final String KEY_SHOW_SESSION_TABS = "show_session_tabs";
    private static final String KEY_SHOW_HUD_BORDER = "show_hud_border";
    private static final String KEY_SHOW_CRT_SCANLINES = "show_crt_scanlines";

    private static final String KEY_FONT_STYLE = "font_style";
    private static final String KEY_FONT_SIZE_SP = "font_size_sp";
    private static final String KEY_TEXT_COLOR = "text_color";
    private static final String KEY_PROMPT_COLOR = "prompt_color";
    private static final String KEY_BG_TINT_COLOR = "bg_tint_color";
    private static final String KEY_BG_DIM_PERCENT = "bg_dim_percent";
    private static final String KEY_HAS_WALLPAPER = "has_wallpaper";

    public static final int UI_STYLE_CLASSIC = 0;
    public static final int UI_STYLE_CYBERPUNK = 1;
    public static final int UI_STYLE_GLASS = 2;
    public static final int UI_STYLE_RETRO_CRT = 3;
    public static final int UI_STYLE_DESKTOP_DOCK = 4;

    public static final String[] UI_STYLE_NAMES = {
        "Classic Slate Terminal (Default)",
        "Cyberpunk / Neon HUD",
        "Minimalist Translucent Glass",
        "Retro CRT Phosphor",
        "Desktop Tiling + App Dock"
    };

    public static final String[] PROMPT_STYLE_NAMES = {
        "Classic Path (:~/path $ )",
        "Powerline Two-Line (┌─[user@android]─[path])",
        "Retro Host (guest@android:~/path$ )",
        "Minimalist (❯ )"
    };

    public static final String[] FONT_LABELS = {
        "Monospace (Default)",
        "Monospace Bold",
        "Sans-Serif Monospace",
        "Serif Classic",
        "Sans-Serif Clean"
    };

    public static final String[] COLOR_PRESET_NAMES = {
        "Classic Light Grey (#E0E0E0)",
        "Matrix Hacker Green (#00FF66)",
        "Cyber Neon Cyan (#00F0FF)",
        "Retro IBM Amber (#FFB000)",
        "CRT Phosphor Green (#33FF33)",
        "Neon Magenta (#FF2A85)",
        "Pure White (#FFFFFF)"
    };

    public static final int[] COLOR_PRESET_VALUES = {
        0xFFE0E0E0,
        0xFF00FF66,
        0xFF00F0FF,
        0xFFFFB000,
        0xFF33FF33,
        0xFFFF2A85,
        0xFFFFFFFF
    };

    public static final String[] BG_THEME_NAMES = {
        "Pure Obsidian Black (#000000)",
        "Deep Slate Navy (#0A141D)",
        "Retro CRT Charcoal (#0A0D0A)",
        "Cyber Dark Indigo (#0D081A)",
        "Charcoal Graphite (#181B1E)"
    };

    public static final int[] BG_THEME_COLORS = {
        0xFF000000,
        0xFF0A141D,
        0xFF0A0D0A,
        0xFF0D081A,
        0xFF181B1E
    };

    private final Context context;
    private final SharedPreferences prefs;
    private final File wallpaperFile;

    public CustomizationManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.wallpaperFile = new File(this.context.getFilesDir(), "custom_wallpaper.jpg");
    }

    public int getUiStyle() {
        return prefs.getInt(KEY_UI_STYLE, UI_STYLE_CLASSIC);
    }

    public void setUiStyle(int style) {
        prefs.edit().putInt(KEY_UI_STYLE, style).apply();
    }

    /**
     * Applies sensible defaults for colors, prompt, borders, and panels when switching a UI Theme Preset.
     */
    public void applyUiStylePreset(int style) {
        SharedPreferences.Editor ed = prefs.edit();
        ed.putInt(KEY_UI_STYLE, style);
        switch (style) {
            case UI_STYLE_CYBERPUNK:
                ed.putInt(KEY_PROMPT_STYLE, 1);
                ed.putInt(KEY_TEXT_COLOR, 0xFFE0F7FA);
                ed.putInt(KEY_PROMPT_COLOR, 0xFF00F0FF);
                ed.putInt(KEY_BG_TINT_COLOR, 0xFF0D081A);
                ed.putInt(KEY_BG_DIM_PERCENT, hasWallpaper() ? 65 : 92);
                ed.putBoolean(KEY_SHOW_HUD_BORDER, true);
                ed.putBoolean(KEY_SHOW_CRT_SCANLINES, false);
                ed.putBoolean(KEY_SHOW_QUICK_CHIPS, true);
                ed.putBoolean(KEY_SHOW_SESSION_TABS, true);
                ed.putBoolean(KEY_SHOW_APP_DOCK, false);
                break;

            case UI_STYLE_GLASS:
                ed.putInt(KEY_PROMPT_STYLE, 2);
                ed.putInt(KEY_TEXT_COLOR, 0xFFFFFFFF);
                ed.putInt(KEY_PROMPT_COLOR, 0xFF64FFDA);
                ed.putInt(KEY_BG_TINT_COLOR, 0xFF0A141D);
                ed.putInt(KEY_BG_DIM_PERCENT, hasWallpaper() ? 45 : 85);
                ed.putBoolean(KEY_SHOW_HUD_BORDER, false);
                ed.putBoolean(KEY_SHOW_CRT_SCANLINES, false);
                ed.putBoolean(KEY_SHOW_QUICK_CHIPS, true);
                ed.putBoolean(KEY_SHOW_SESSION_TABS, false);
                ed.putBoolean(KEY_SHOW_APP_DOCK, false);
                break;

            case UI_STYLE_RETRO_CRT:
                ed.putInt(KEY_PROMPT_STYLE, 2);
                ed.putInt(KEY_TEXT_COLOR, 0xFF33FF33);
                ed.putInt(KEY_PROMPT_COLOR, 0xFFFFB000);
                ed.putInt(KEY_BG_TINT_COLOR, 0xFF0A0D0A);
                ed.putInt(KEY_BG_DIM_PERCENT, hasWallpaper() ? 75 : 96);
                ed.putBoolean(KEY_SHOW_HUD_BORDER, true);
                ed.putBoolean(KEY_SHOW_CRT_SCANLINES, true);
                ed.putBoolean(KEY_SHOW_QUICK_CHIPS, false);
                ed.putBoolean(KEY_SHOW_SESSION_TABS, false);
                ed.putBoolean(KEY_SHOW_APP_DOCK, false);
                break;

            case UI_STYLE_DESKTOP_DOCK:
                ed.putInt(KEY_PROMPT_STYLE, 2);
                ed.putInt(KEY_TEXT_COLOR, 0xFFE0E0E0);
                ed.putInt(KEY_PROMPT_COLOR, 0xFF00FF66);
                ed.putInt(KEY_BG_TINT_COLOR, 0xFF000000);
                ed.putInt(KEY_BG_DIM_PERCENT, hasWallpaper() ? 60 : 95);
                ed.putBoolean(KEY_SHOW_HUD_BORDER, true);
                ed.putBoolean(KEY_SHOW_CRT_SCANLINES, false);
                ed.putBoolean(KEY_SHOW_QUICK_CHIPS, false);
                ed.putBoolean(KEY_SHOW_SESSION_TABS, true);
                ed.putBoolean(KEY_SHOW_APP_DOCK, true);
                break;

            case UI_STYLE_CLASSIC:
            default:
                ed.putInt(KEY_PROMPT_STYLE, 0);
                ed.putInt(KEY_TEXT_COLOR, 0xFFE0E0E0);
                ed.putInt(KEY_PROMPT_COLOR, 0xFF00FF66);
                ed.putInt(KEY_BG_TINT_COLOR, 0xFF000000);
                ed.putInt(KEY_BG_DIM_PERCENT, hasWallpaper() ? 65 : 100);
                ed.putBoolean(KEY_SHOW_HUD_BORDER, false);
                ed.putBoolean(KEY_SHOW_CRT_SCANLINES, false);
                ed.putBoolean(KEY_SHOW_QUICK_CHIPS, false);
                ed.putBoolean(KEY_SHOW_SESSION_TABS, false);
                ed.putBoolean(KEY_SHOW_APP_DOCK, false);
                break;
        }
        ed.apply();
    }

    public int getPromptStyle() {
        return prefs.getInt(KEY_PROMPT_STYLE, 0);
    }

    public void setPromptStyle(int style) {
        prefs.edit().putInt(KEY_PROMPT_STYLE, style).apply();
    }

    public boolean isShowQuickChips() {
        return prefs.getBoolean(KEY_SHOW_QUICK_CHIPS, false);
    }

    public void setShowQuickChips(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_QUICK_CHIPS, show).apply();
    }

    public boolean isShowAppDock() {
        return prefs.getBoolean(KEY_SHOW_APP_DOCK, false);
    }

    public void setShowAppDock(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_APP_DOCK, show).apply();
    }

    public boolean isShowSessionTabs() {
        return prefs.getBoolean(KEY_SHOW_SESSION_TABS, false);
    }

    public void setShowSessionTabs(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_SESSION_TABS, show).apply();
    }

    public boolean isShowHudBorder() {
        return prefs.getBoolean(KEY_SHOW_HUD_BORDER, false);
    }

    public void setShowHudBorder(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_HUD_BORDER, show).apply();
    }

    public boolean isShowCrtScanlines() {
        return prefs.getBoolean(KEY_SHOW_CRT_SCANLINES, false);
    }

    public void setShowCrtScanlines(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_CRT_SCANLINES, show).apply();
    }

    public int getFontStyleIndex() {
        return prefs.getInt(KEY_FONT_STYLE, 0);
    }

    public void setFontStyleIndex(int index) {
        prefs.edit().putInt(KEY_FONT_STYLE, index).apply();
    }

    public Typeface getTypeface() {
        int idx = getFontStyleIndex();
        switch (idx) {
            case 1:
                return Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
            case 2:
                return Typeface.create("monospace", Typeface.NORMAL);
            case 3:
                return Typeface.create(Typeface.SERIF, Typeface.NORMAL);
            case 4:
                return Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
            case 0:
            default:
                return Typeface.MONOSPACE;
        }
    }

    public float getFontSizeSp() {
        return prefs.getFloat(KEY_FONT_SIZE_SP, 13f);
    }

    public void setFontSizeSp(float sizeSp) {
        float clamped = Math.max(8f, Math.min(30f, sizeSp));
        prefs.edit().putFloat(KEY_FONT_SIZE_SP, clamped).apply();
    }

    public int getZoomPercent() {
        return Math.round((getFontSizeSp() / 13f) * 100f);
    }

    public int getTextColor() {
        return prefs.getInt(KEY_TEXT_COLOR, 0xFFE0E0E0);
    }

    public void setTextColor(int color) {
        prefs.edit().putInt(KEY_TEXT_COLOR, color).apply();
    }

    public int getPromptColor() {
        return prefs.getInt(KEY_PROMPT_COLOR, 0xFF00FF66);
    }

    public void setPromptColor(int color) {
        prefs.edit().putInt(KEY_PROMPT_COLOR, color).apply();
    }

    public int getBgTintColor() {
        return prefs.getInt(KEY_BG_TINT_COLOR, 0xFF000000);
    }

    public void setBgTintColor(int color) {
        prefs.edit().putInt(KEY_BG_TINT_COLOR, color).apply();
    }

    public int getBgDimPercent() {
        return prefs.getInt(KEY_BG_DIM_PERCENT, hasWallpaper() ? 65 : 100);
    }

    public void setBgDimPercent(int percent) {
        int clamped = Math.max(0, Math.min(100, percent));
        prefs.edit().putInt(KEY_BG_DIM_PERCENT, clamped).apply();
    }

    public int getEffectiveOverlayColor() {
        int base = getBgTintColor();
        int alpha = Math.round((getBgDimPercent() / 100f) * 255f);
        return Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base));
    }

    public boolean hasWallpaper() {
        return prefs.getBoolean(KEY_HAS_WALLPAPER, false) && wallpaperFile.exists();
    }

    public Bitmap loadWallpaperBitmap() {
        if (!hasWallpaper()) return null;
        return BitmapFactory.decodeFile(wallpaperFile.getAbsolutePath());
    }

    public boolean saveWallpaperFromUri(Uri uri) {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) return false;
            Bitmap decoded = BitmapFactory.decodeStream(in);
            if (decoded == null) return false;

            int maxDim = 1920;
            int w = decoded.getWidth();
            int h = decoded.getHeight();
            if (w > maxDim || h > maxDim) {
                float scale = Math.min((float) maxDim / w, (float) maxDim / h);
                decoded = Bitmap.createScaledBitmap(decoded, Math.round(w * scale), Math.round(h * scale), true);
            }

            try (FileOutputStream out = new FileOutputStream(wallpaperFile)) {
                decoded.compress(Bitmap.CompressFormat.JPEG, 88, out);
            }
            prefs.edit()
                .putBoolean(KEY_HAS_WALLPAPER, true)
                .putInt(KEY_BG_DIM_PERCENT, Math.min(getBgDimPercent(), 60))
                .apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void clearWallpaper() {
        if (wallpaperFile.exists()) {
            wallpaperFile.delete();
        }
        prefs.edit()
            .putBoolean(KEY_HAS_WALLPAPER, false)
            .putInt(KEY_BG_DIM_PERCENT, 100)
            .apply();
    }
}
