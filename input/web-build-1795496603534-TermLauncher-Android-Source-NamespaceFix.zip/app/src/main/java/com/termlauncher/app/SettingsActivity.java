package com.termlauncher.app;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class SettingsActivity extends AppCompatActivity {

    private CustomizationManager customManager;
    private ActivityResultLauncher<String[]> pickWallpaperLauncher;

    private Spinner spUiStyle;
    private Spinner spPromptStyle;
    private CheckBox cbSessionTabs;
    private CheckBox cbQuickChips;
    private CheckBox cbAppDock;
    private CheckBox cbHudBorder;
    private CheckBox cbCrtScanlines;
    private Spinner spFont;
    private SeekBar sbFontSize;
    private TextView tvZoomLabel;
    private Spinner spTextColor;
    private Spinner spPromptColor;
    private Spinner spBgTheme;
    private SeekBar sbDim;
    private TextView tvDimLabel;

    private CheckBox cbTermuxAutoSession;
    private EditText etTermuxStartupCmd;
    private TextView tvTermuxBridgeStatus;

    private boolean isSyncingUi = false;
    private boolean spinnersReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        customManager = new CustomizationManager(this);

        pickWallpaperLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri != null) {
                    try {
                        getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                    } catch (Exception ignored) {
                    }
                    if (customManager.saveWallpaperFromUri(uri)) {
                        syncControlsFromState();
                        Toast.makeText(this, "Wallpaper updated!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to load image.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );

        ImageButton btnBack = findViewById(R.id.btn_settings_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        ScrollView scrollView = findViewById(R.id.settings_scroll_view);
        TextView tvAboutHeader = findViewById(R.id.tv_about_section_header);
        Button btnTabAbout = findViewById(R.id.btn_tab_about);
        if (btnTabAbout != null) {
            btnTabAbout.setOnClickListener(v -> scrollToAboutSection(scrollView, tvAboutHeader));
        }

        spUiStyle = findViewById(R.id.sp_ui_style);
        spPromptStyle = findViewById(R.id.sp_prompt_style);
        cbSessionTabs = findViewById(R.id.cb_session_tabs);
        cbQuickChips = findViewById(R.id.cb_quick_chips);
        cbAppDock = findViewById(R.id.cb_app_dock);
        cbHudBorder = findViewById(R.id.cb_hud_border);
        cbCrtScanlines = findViewById(R.id.cb_crt_scanlines);

        spFont = findViewById(R.id.sp_font_style);
        sbFontSize = findViewById(R.id.sb_font_size);
        tvZoomLabel = findViewById(R.id.tv_zoom_label);
        spTextColor = findViewById(R.id.sp_text_color);
        spPromptColor = findViewById(R.id.sp_prompt_color);
        spBgTheme = findViewById(R.id.sp_bg_theme);
        sbDim = findViewById(R.id.sb_bg_dim);
        tvDimLabel = findViewById(R.id.tv_dim_label);
        Button btnPickWp = findViewById(R.id.btn_pick_wallpaper);
        Button btnClearWp = findViewById(R.id.btn_clear_wallpaper);

        cbTermuxAutoSession = findViewById(R.id.cb_termux_auto_session);
        etTermuxStartupCmd = findViewById(R.id.et_termux_startup_cmd);
        tvTermuxBridgeStatus = findViewById(R.id.tv_termux_bridge_status);

        setupAdapters();
        syncControlsFromState();
        attachListeners();

        if (spUiStyle != null) {
            spUiStyle.post(() -> spinnersReady = true);
        } else {
            spinnersReady = true;
        }

        populateAboutSection(scrollView, tvAboutHeader, getIntent().getBooleanExtra("scroll_to_about", false));
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncControlsFromState();
    }

    private void setupAdapters() {
        if (spUiStyle != null) {
            ArrayAdapter<String> uiStyleAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.UI_STYLE_NAMES
            );
            spUiStyle.setAdapter(uiStyleAdapter);
        }

        if (spPromptStyle != null) {
            ArrayAdapter<String> promptStyleAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.PROMPT_STYLE_NAMES
            );
            spPromptStyle.setAdapter(promptStyleAdapter);
        }

        if (spFont != null) {
            ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.FONT_LABELS
            );
            spFont.setAdapter(fontAdapter);
        }

        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.COLOR_PRESET_NAMES
        );
        if (spTextColor != null) {
            spTextColor.setAdapter(colorAdapter);
        }
        if (spPromptColor != null) {
            spPromptColor.setAdapter(colorAdapter);
        }

        if (spBgTheme != null) {
            ArrayAdapter<String> bgAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.BG_THEME_NAMES
            );
            spBgTheme.setAdapter(bgAdapter);
        }
    }

    private void syncControlsFromState() {
        isSyncingUi = true;
        try {
            if (spUiStyle != null && CustomizationManager.UI_STYLE_NAMES.length > 0) {
                spUiStyle.setSelection(clampIndex(customManager.getUiStyle(), CustomizationManager.UI_STYLE_NAMES.length, 0), false);
            }
            if (spPromptStyle != null && CustomizationManager.PROMPT_STYLE_NAMES.length > 0) {
                spPromptStyle.setSelection(clampIndex(customManager.getPromptStyle(), CustomizationManager.PROMPT_STYLE_NAMES.length, 0), false);
            }
            if (cbSessionTabs != null) cbSessionTabs.setChecked(customManager.isShowSessionTabs());
            if (cbQuickChips != null) cbQuickChips.setChecked(customManager.isShowQuickChips());
            if (cbAppDock != null) cbAppDock.setChecked(customManager.isShowAppDock());
            if (cbHudBorder != null) cbHudBorder.setChecked(customManager.isShowHudBorder());
            if (cbCrtScanlines != null) cbCrtScanlines.setChecked(customManager.isShowCrtScanlines());

            if (spFont != null && CustomizationManager.FONT_LABELS.length > 0) {
                spFont.setSelection(clampIndex(customManager.getFontStyleIndex(), CustomizationManager.FONT_LABELS.length, 0), false);
            }

            int initialSize = Math.round(customManager.getFontSizeSp());
            int progressVal = Math.max(0, Math.min(22, initialSize - 8));
            int actualSp = progressVal + 8;
            if (sbFontSize != null) {
                sbFontSize.setProgress(progressVal);
            }
            updateZoomLabel(actualSp);

            if (spTextColor != null && CustomizationManager.COLOR_PRESET_VALUES.length > 0) {
                spTextColor.setSelection(findColorIndex(customManager.getTextColor(), 0), false);
            }
            if (spPromptColor != null && CustomizationManager.COLOR_PRESET_VALUES.length > 0) {
                spPromptColor.setSelection(findColorIndex(customManager.getPromptColor(), 1), false);
            }
            if (spBgTheme != null && CustomizationManager.BG_THEME_COLORS.length > 0) {
                spBgTheme.setSelection(findBgIndex(customManager.getBgTintColor()), false);
            }

            int dimVal = Math.max(0, Math.min(100, customManager.getBgDimPercent()));
            if (sbDim != null) {
                sbDim.setProgress(dimVal);
            }
            updateDimLabel(dimVal);

            if (cbTermuxAutoSession != null) {
                cbTermuxAutoSession.setChecked(TermuxBridgeHelper.isAutoSessionGranted(this));
            }
            if (etTermuxStartupCmd != null) {
                String savedCmd = TermuxBridgeHelper.getAutoSessionCommand(this);
                if (!savedCmd.equals(etTermuxStartupCmd.getText().toString())) {
                    etTermuxStartupCmd.setText(savedCmd);
                }
            }
            refreshTermuxBridgeStatus();
        } finally {
            isSyncingUi = false;
        }
    }

    private void refreshTermuxBridgeStatus() {
        if (tvTermuxBridgeStatus != null) {
            tvTermuxBridgeStatus.setText(TermuxBridgeHelper.buildEnvironmentSummary(this));
        }
    }

    private void attachListeners() {
        if (spUiStyle != null) {
            spUiStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if (isSyncingUi || !spinnersReady) return;
                    if (pos < 0 || pos >= CustomizationManager.UI_STYLE_NAMES.length) return;
                    customManager.applyUiStylePreset(pos);
                    syncControlsFromState();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        }

        if (spPromptStyle != null) {
            spPromptStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if (isSyncingUi || !spinnersReady) return;
                    if (pos < 0 || pos >= CustomizationManager.PROMPT_STYLE_NAMES.length) return;
                    customManager.setPromptStyle(pos);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        }

        if (cbSessionTabs != null) {
            cbSessionTabs.setOnCheckedChangeListener((b, isChecked) -> {
                if (!isSyncingUi) customManager.setShowSessionTabs(isChecked);
            });
        }
        if (cbQuickChips != null) {
            cbQuickChips.setOnCheckedChangeListener((b, isChecked) -> {
                if (!isSyncingUi) customManager.setShowQuickChips(isChecked);
            });
        }
        if (cbAppDock != null) {
            cbAppDock.setOnCheckedChangeListener((b, isChecked) -> {
                if (!isSyncingUi) customManager.setShowAppDock(isChecked);
            });
        }
        if (cbHudBorder != null) {
            cbHudBorder.setOnCheckedChangeListener((b, isChecked) -> {
                if (!isSyncingUi) customManager.setShowHudBorder(isChecked);
            });
        }
        if (cbCrtScanlines != null) {
            cbCrtScanlines.setOnCheckedChangeListener((b, isChecked) -> {
                if (!isSyncingUi) customManager.setShowCrtScanlines(isChecked);
            });
        }

        if (spFont != null) {
            spFont.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if (isSyncingUi || !spinnersReady) return;
                    if (pos < 0 || pos >= CustomizationManager.FONT_LABELS.length) return;
                    customManager.setFontStyleIndex(pos);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        }

        if (sbFontSize != null) {
            sbFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    int sp = progress + 8;
                    updateZoomLabel(sp);
                    if (!isSyncingUi && fromUser) {
                        customManager.setFontSizeSp(sp);
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
        }

        if (spTextColor != null) {
            spTextColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if (isSyncingUi || !spinnersReady) return;
                    if (pos < 0 || pos >= CustomizationManager.COLOR_PRESET_VALUES.length) return;
                    customManager.setTextColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        }

        if (spPromptColor != null) {
            spPromptColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if (isSyncingUi || !spinnersReady) return;
                    if (pos < 0 || pos >= CustomizationManager.COLOR_PRESET_VALUES.length) return;
                    customManager.setPromptColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        }

        if (spBgTheme != null) {
            spBgTheme.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    if (isSyncingUi || !spinnersReady) return;
                    if (pos < 0 || pos >= CustomizationManager.BG_THEME_COLORS.length) return;
                    customManager.setBgTintColor(CustomizationManager.BG_THEME_COLORS[pos]);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        }

        if (sbDim != null) {
            sbDim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    updateDimLabel(progress);
                    if (!isSyncingUi && fromUser) {
                        customManager.setBgDimPercent(progress);
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
        }

        Button btnPickWp = findViewById(R.id.btn_pick_wallpaper);
        if (btnPickWp != null) {
            btnPickWp.setOnClickListener(v -> {
                try {
                    pickWallpaperLauncher.launch(new String[]{"image/*"});
                } catch (Exception e) {
                    Toast.makeText(this, "No image picker available.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        Button btnClearWp = findViewById(R.id.btn_clear_wallpaper);
        if (btnClearWp != null) {
            btnClearWp.setOnClickListener(v -> {
                customManager.clearWallpaper();
                syncControlsFromState();
                Toast.makeText(this, "Wallpaper cleared.", Toast.LENGTH_SHORT).show();
            });
        }

        if (cbTermuxAutoSession != null) {
            cbTermuxAutoSession.setOnCheckedChangeListener((b, isChecked) -> {
                if (isSyncingUi) return;
                TermuxBridgeHelper.setAutoSessionGranted(this, isChecked);
                refreshTermuxBridgeStatus();
                Toast.makeText(
                    this,
                    isChecked ? "Termux auto-session enabled." : "Termux auto-session disabled.",
                    Toast.LENGTH_SHORT
                ).show();
            });
        }

        Button btnSaveBridge = findViewById(R.id.btn_save_termux_bridge);
        if (btnSaveBridge != null) {
            btnSaveBridge.setOnClickListener(v -> {
                boolean enabled = cbTermuxAutoSession != null && cbTermuxAutoSession.isChecked();
                String cmd = etTermuxStartupCmd != null ? etTermuxStartupCmd.getText().toString().trim() : "";
                TermuxBridgeHelper.setAutoSessionGranted(this, enabled);
                TermuxBridgeHelper.setAutoSessionCommand(this, cmd);
                refreshTermuxBridgeStatus();
                Toast.makeText(this, "Termux bridge settings saved.", Toast.LENGTH_SHORT).show();
            });
        }

        Button btnRunSession = findViewById(R.id.btn_run_termux_session);
        if (btnRunSession != null) {
            btnRunSession.setOnClickListener(v -> {
                String cmd = etTermuxStartupCmd != null ? etTermuxStartupCmd.getText().toString().trim() : "";
                if (!TermuxBridgeHelper.isAutoSessionGranted(this)) {
                    TermuxBridgeHelper.setAutoSessionGranted(this, true);
                    if (cbTermuxAutoSession != null) {
                        isSyncingUi = true;
                        cbTermuxAutoSession.setChecked(true);
                        isSyncingUi = false;
                    }
                }
                if (!cmd.isEmpty()) {
                    TermuxBridgeHelper.setAutoSessionCommand(this, cmd);
                }
                boolean started = TermuxBridgeHelper.startSessionIfGranted(this, cmd.isEmpty() ? null : cmd, false);
                refreshTermuxBridgeStatus();
                Toast.makeText(
                    this,
                    started ? "Termux session triggered." : "Opening Termux or check allow-external-apps.",
                    Toast.LENGTH_SHORT
                ).show();
            });
        }

        Button btnOpenTermux = findViewById(R.id.btn_open_termux_app);
        if (btnOpenTermux != null) {
            btnOpenTermux.setOnClickListener(v -> {
                boolean opened = TermuxBridgeHelper.openTermuxApp(this);
                refreshTermuxBridgeStatus();
                if (!opened) {
                    Toast.makeText(this, "Termux app not installed.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void updateZoomLabel(int sp) {
        if (tvZoomLabel != null) {
            int zoomPct = Math.round((sp / 13f) * 100f);
            tvZoomLabel.setText("Terminal Font Size / Zoom: " + sp + "sp (" + zoomPct + "%)");
        }
    }

    private void updateDimLabel(int dimPercent) {
        if (tvDimLabel != null) {
            tvDimLabel.setText("Background Dim / Overlay: " + dimPercent + "%");
        }
    }

    private void scrollToAboutSection(ScrollView scrollView, TextView tvAboutHeader) {
        if (scrollView == null || tvAboutHeader == null) return;
        scrollView.post(() -> {
            int y = tvAboutHeader.getTop();
            View parent = (View) tvAboutHeader.getParent();
            while (parent != null && parent != scrollView) {
                y += parent.getTop();
                if (parent.getParent() instanceof View) {
                    parent = (View) parent.getParent();
                } else {
                    break;
                }
            }
            scrollView.smoothScrollTo(0, Math.max(0, y));
        });
    }

    private void populateAboutSection(ScrollView scrollView, TextView tvAboutHeader, boolean scrollToAbout) {
        TextView tvVersion = findViewById(R.id.tv_about_version);
        TextView tvDetails = findViewById(R.id.tv_about_details);

        String versionName = "2.5";
        long versionCode = 10;
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (pi.versionName != null) versionName = pi.versionName;
            versionCode = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception ignored) {
        }

        if (tvVersion != null) {
            tvVersion.setText("Version " + versionName + " (Build " + versionCode + ")");
        }

        boolean termuxInstalled = false;
        try {
            getPackageManager().getPackageInfo("com.termux", 0);
            termuxInstalled = true;
        } catch (Exception ignored) {
            termuxInstalled = new File("/data/data/com.termux/files/usr").exists();
        }

        if (tvDetails != null) {
            String info =
                "Package: " + getPackageName() + "\n" +
                "Device / Android: " + Build.MANUFACTURER + " " + Build.MODEL + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "Termux Installed: " + (termuxInstalled ? "Yes (auto-connected when accessible)" : "Not detected") + "\n" +
                "Prefix Path: " + new File(getFilesDir(), "usr").getAbsolutePath() + "\n\n" +
                "TermLauncher is a terminal-first launcher with multi-window sessions, " +
                "package management, local audio playback, storage shortcuts, and customizable themes.";
            tvDetails.setText(info);
        }

        if (scrollToAbout) {
            scrollToAboutSection(scrollView, tvAboutHeader);
        }
    }

    private int clampIndex(int index, int length, int fallback) {
        if (length <= 0) return 0;
        if (index >= 0 && index < length) return index;
        return (fallback >= 0 && fallback < length) ? fallback : 0;
    }

    private int findColorIndex(int color, int fallback) {
        int[] values = CustomizationManager.COLOR_PRESET_VALUES;
        if (values == null || values.length == 0) return 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i] == color) return i;
        }
        return clampIndex(fallback, values.length, 0);
    }

    private int findBgIndex(int color) {
        int[] colors = CustomizationManager.BG_THEME_COLORS;
        if (colors == null || colors.length == 0) return 0;
        for (int i = 0; i < colors.length; i++) {
            if (colors[i] == color) return i;
        }
        return 0;
    }
}
