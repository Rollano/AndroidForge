package com.termlauncher.app;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class TerminalNotificationListener extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (getPackageName().equals(pkg)) return;

        Notification n = sbn.getNotification();
        if (n == null) return;

        Bundle extras = n.extras;
        String title = extras != null ? String.valueOf(extras.getCharSequence(Notification.EXTRA_TITLE, "")) : "";
        String text = extras != null ? String.valueOf(extras.getCharSequence(Notification.EXTRA_TEXT, "")) : "";

        if ((title == null || title.equals("null") || title.trim().isEmpty()) &&
            (text == null || text.equals("null") || text.trim().isEmpty())) {
            return;
        }

        Intent broadcast = new Intent(TerminalBackgroundService.ACTION_INCOMING_NOTIF);
        broadcast.setPackage(getPackageName());
        broadcast.putExtra(TerminalBackgroundService.EXTRA_NOTIF_PKG, pkg);
        broadcast.putExtra(TerminalBackgroundService.EXTRA_NOTIF_TITLE, title);
        broadcast.putExtra(TerminalBackgroundService.EXTRA_NOTIF_TEXT, text);
        sendBroadcast(broadcast);
    }
}
