package com.termlauncher.app;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class TerminalSession {
    public String title;
    public StringBuilder history;
    public File currentDir;
    public final List<String> historyCommands = new ArrayList<>();

    public TerminalSession(String title, File homeDir) {
        this.title = title;
        this.currentDir = homeDir;
        this.history = new StringBuilder();
        this.history.append(":/ $ cd ~\n");
    }
}
