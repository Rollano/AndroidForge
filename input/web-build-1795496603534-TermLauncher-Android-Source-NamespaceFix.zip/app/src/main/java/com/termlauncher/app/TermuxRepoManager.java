package com.termlauncher.app;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.apache.commons.compress.archivers.ar.ArArchiveEntry;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;

public class TermuxRepoManager {

    public interface OutputCallback {
        void onLog(String text);
        void onComplete(boolean success);
    }

    private static final String[] REPO_MIRRORS = {
        "https://packages-cf.termux.dev/apt/termux-main/",
        "https://packages.termux.dev/apt/termux-main/"
    };

    private final File rootDir;
    private final File prefixDir;
    private final File binDir;
    private final File cacheDir;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final Map<String, PackageMeta> packageIndex = new HashMap<>();
    private final Set<String> installedSet = new HashSet<>();

    public static class PackageMeta {
        public String name;
        public String version;
        public String filename;
        public String size;
        public String description;
        public List<String> depends = new ArrayList<>();
    }

    public TermuxRepoManager(File appFilesDir) {
        this.rootDir = appFilesDir;
        this.prefixDir = new File(rootDir, "usr");
        this.binDir = new File(prefixDir, "bin");
        this.cacheDir = new File(rootDir, "cache");
        if (!binDir.exists()) binDir.mkdirs();
        if (!cacheDir.exists()) cacheDir.mkdirs();
        setupBinHelpers();
    }

    public File getBinDir() {
        return binDir;
    }

    public File getPrefixDir() {
        return prefixDir;
    }

    public File getRootDir() {
        return rootDir;
    }

    public void setupBinHelpers() {
        try {
            if (!binDir.exists()) binDir.mkdirs();

            // Wrapper script for `su`
            File suWrapper = new File(binDir, "su");
            if (!suWrapper.exists()) {
                String suScript = "#!/system/bin/sh\n" +
                    "for p in /sbin/su /system/bin/su /system/xbin/su /vendor/bin/su /debug_ramdisk/su /data/adb/ksu/bin/su /data/adb/ap/bin/su; do\n" +
                    "  if [ -x \"$p\" ]; then\n" +
                    "    exec \"$p\" \"$@\"\n" +
                    "  fi\n" +
                    "done\n" +
                    "echo 'su: root binary (su) not found or device is not rooted.' >&2\n" +
                    "exit 127\n";
                try (FileOutputStream fos = new FileOutputStream(suWrapper)) {
                    fos.write(suScript.getBytes("UTF-8"));
                }
                suWrapper.setExecutable(true, false);
            }

            // Wrapper script for `adb`
            File adbWrapper = new File(binDir, "adb");
            if (!adbWrapper.exists()) {
                String adbScript = "#!/system/bin/sh\n" +
                    "for p in " + binDir.getAbsolutePath() + "/adb.bin /system/bin/adb /vendor/bin/adb; do\n" +
                    "  if [ -x \"$p\" ]; then\n" +
                    "    exec \"$p\" \"$@\"\n" +
                    "  fi\n" +
                    "done\n" +
                    "echo 'adb: standalone adb binary not installed yet.' >&2\n" +
                    "echo 'Tip: For local shell commands on Android, use shell commands directly or enable Wireless Debugging / Shizuku / ADB TCP.' >&2\n" +
                    "exit 127\n";
                try (FileOutputStream fos = new FileOutputStream(adbWrapper)) {
                    fos.write(adbScript.getBytes("UTF-8"));
                }
                adbWrapper.setExecutable(true, false);
            }
        } catch (Exception ignored) {
        }
    }

    private String getDeviceArch() {
        String[] abis = Build.SUPPORTED_ABIS;
        if (abis != null && abis.length > 0) {
            String primary = abis[0];
            if (primary.contains("arm64")) return "aarch64";
            if (primary.contains("armeabi")) return "arm";
            if (primary.contains("x86_64")) return "x86_64";
            if (primary.contains("x86")) return "i686";
        }
        return "aarch64";
    }

    private void postLog(OutputCallback cb, String msg) {
        mainHandler.post(() -> cb.onLog(msg + "\n"));
    }

    public void updateRepo(OutputCallback cb) {
        new Thread(() -> {
            String arch = getDeviceArch();
            String indexPath = "dists/stable/main/binary-" + arch + "/Packages.gz";
            postLog(cb, "Get:1 https://packages-cf.termux.dev/apt/termux-main stable InRelease");
            postLog(cb, "Get:2 https://packages-cf.termux.dev/apt/termux-main stable/main " + arch + " Packages");

            boolean fetched = false;
            for (String mirror : REPO_MIRRORS) {
                try {
                    URL url = new URL(mirror + indexPath);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestProperty("User-Agent", "Termux-APT/2.6 (Android)");

                    if (conn.getResponseCode() == 200) {
                        File outGz = new File(cacheDir, "Packages.gz");
                        try (InputStream in = conn.getInputStream();
                             FileOutputStream fos = new FileOutputStream(outGz)) {
                            byte[] buf = new byte[8192];
                            int len;
                            while ((len = in.read(buf)) != -1) {
                                fos.write(buf, 0, len);
                            }
                        }
                        parsePackagesGz(outGz);
                        fetched = true;
                        break;
                    }
                } catch (Exception e) {
                    postLog(cb, "Mirror warning (" + mirror + "): " + e.getMessage());
                }
            }

            if (fetched) {
                postLog(cb, "Fetched Termux " + arch + " index (" + packageIndex.size() + " packages available).");
                postLog(cb, "Reading package lists... Done");
                mainHandler.post(() -> cb.onComplete(true));
            } else {
                postLog(cb, "E: Failed to fetch Termux repository. Check internet connection.");
                mainHandler.post(() -> cb.onComplete(false));
            }
        }).start();
    }

    private void parsePackagesGz(File gzFile) throws Exception {
        packageIndex.clear();
        try (GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(gzFile));
             BufferedReader br = new BufferedReader(new InputStreamReader(gzis))) {
            String line;
            PackageMeta current = new PackageMeta();
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    if (current.name != null && current.filename != null) {
                        packageIndex.put(current.name, current);
                    }
                    current = new PackageMeta();
                } else if (line.startsWith("Package: ")) {
                    current.name = line.substring(9).trim();
                } else if (line.startsWith("Version: ")) {
                    current.version = line.substring(9).trim();
                } else if (line.startsWith("Filename: ")) {
                    current.filename = line.substring(10).trim();
                } else if (line.startsWith("Size: ")) {
                    current.size = line.substring(6).trim();
                } else if (line.startsWith("Description: ")) {
                    current.description = line.substring(13).trim();
                } else if (line.startsWith("Depends: ")) {
                    String depsRaw = line.substring(9).trim();
                    for (String token : depsRaw.split(",")) {
                        String alt = token.split("\\|")[0].trim();
                        int paren = alt.indexOf('(');
                        if (paren > 0) alt = alt.substring(0, paren).trim();
                        if (!alt.isEmpty()) {
                            current.depends.add(alt);
                        }
                    }
                }
            }
            if (current.name != null && current.filename != null) {
                packageIndex.put(current.name, current);
            }
        }
    }

    public void searchPackage(String query, OutputCallback cb) {
        if (packageIndex.isEmpty()) {
            postLog(cb, "Package index empty. Run 'pkg update' first.");
            cb.onComplete(false);
            return;
        }
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (PackageMeta meta : packageIndex.values()) {
            if (meta.name.contains(query) || (meta.description != null && meta.description.toLowerCase().contains(query.toLowerCase()))) {
                sb.append(meta.name).append("/stable ").append(meta.version).append("\n");
                if (meta.description != null) {
                    sb.append("  ").append(meta.description).append("\n");
                }
                count++;
                if (count >= 25) {
                    sb.append("... (showing first 25 matches)\n");
                    break;
                }
            }
        }
        if (count == 0) {
            postLog(cb, "No packages found matching '" + query + "'.");
        } else {
            postLog(cb, sb.toString());
        }
        cb.onComplete(true);
    }

    public void installPackage(String pkgName, OutputCallback cb) {
        new Thread(() -> {
            if (packageIndex.isEmpty()) {
                postLog(cb, "Updating Termux package index first...");
                try {
                    String arch = getDeviceArch();
                    URL url = new URL(REPO_MIRRORS[0] + "dists/stable/main/binary-" + arch + "/Packages.gz");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    File outGz = new File(cacheDir, "Packages.gz");
                    try (InputStream in = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(outGz)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                    }
                    parsePackagesGz(outGz);
                } catch (Exception e) {
                    postLog(cb, "E: Unable to reach Termux repo: " + e.getMessage());
                    mainHandler.post(() -> cb.onComplete(false));
                    return;
                }
            }

            Set<String> visited = new HashSet<>();
            boolean ok = installPackageRecursive(pkgName, cb, visited);
            setupBinHelpers();
            mainHandler.post(() -> cb.onComplete(ok));
        }).start();
    }

    private boolean installPackageRecursive(String pkgName, OutputCallback cb, Set<String> visited) {
        if (visited.contains(pkgName) || installedSet.contains(pkgName)) {
            return true;
        }
        visited.add(pkgName);

        PackageMeta meta = packageIndex.get(pkgName);
        if (meta == null) {
            postLog(cb, "E: Unable to locate package " + pkgName);
            return false;
        }

        // Install dependencies first (e.g. libandroid-wordexp, yyjson, etc.)
        for (String dep : meta.depends) {
            if (!installedSet.contains(dep) && packageIndex.containsKey(dep)) {
                postLog(cb, "Installing dependency: " + dep);
                installPackageRecursive(dep, cb, visited);
            }
        }

        postLog(cb, "The following NEW packages will be installed:\n  " + meta.name + " (" + meta.version + ")");
        postLog(cb, "Get:1 " + REPO_MIRRORS[0] + meta.filename + " [" + meta.size + " B]");

        try {
            URL debUrl = new URL(REPO_MIRRORS[0] + meta.filename);
            HttpURLConnection conn = (HttpURLConnection) debUrl.openConnection();
            conn.setRequestProperty("User-Agent", "Termux-APT/2.6");
            File debFile = new File(cacheDir, meta.name + ".deb");

            try (InputStream in = new BufferedInputStream(conn.getInputStream());
                 FileOutputStream fos = new FileOutputStream(debFile)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = in.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                }
            }

            postLog(cb, "Unpacking " + meta.name + " (" + meta.version + ") ...");
            int extractedFiles = extractDebPackagePureJava(debFile, cb);
            if (extractedFiles <= 0) {
                postLog(cb, "E: No files were extracted from " + meta.name + ".deb");
                return false;
            }
            installedSet.add(meta.name);
            postLog(cb, "Setting up " + meta.name + " (" + meta.version + ") (" + extractedFiles + " files) ... Done.");
            return true;
        } catch (Exception e) {
            postLog(cb, "E: Error installing " + pkgName + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * Pure-Java .deb (ar) -> data.tar.xz / data.tar.gz -> files extractor.
     * Eliminates reliance on Android's /system/bin/sh `tar` or `xz` binaries (which fail with exit code 127).
     * Also maps Termux's `data/data/com.termux/files/usr/...` layout cleanly into `<appFilesDir>/usr/...`.
     */
    private int extractDebPackagePureJava(File debFile, OutputCallback cb) throws Exception {
        int extractedCount = 0;
        Map<File, String> pendingSymlinks = new LinkedHashMap<>();

        try (FileInputStream fis = new FileInputStream(debFile);
             BufferedInputStream bis = new BufferedInputStream(fis);
             ArArchiveInputStream arIn = new ArArchiveInputStream(bis)) {

            ArArchiveEntry arEntry;
            while ((arEntry = arIn.getNextArEntry()) != null) {
                String entryName = arEntry.getName();
                if (entryName != null && entryName.startsWith("data.tar")) {
                    InputStream decompressedStream;
                    if (entryName.endsWith(".xz")) {
                        decompressedStream = new XZCompressorInputStream(arIn);
                    } else if (entryName.endsWith(".gz")) {
                        decompressedStream = new GzipCompressorInputStream(arIn);
                    } else if (entryName.endsWith(".tar")) {
                        decompressedStream = arIn;
                    } else {
                        throw new Exception("Unsupported archive compression in .deb: " + entryName);
                    }

                    try (TarArchiveInputStream tarIn = new TarArchiveInputStream(decompressedStream)) {
                        TarArchiveEntry tarEntry;
                        byte[] buf = new byte[8192];

                        while ((tarEntry = tarIn.getNextTarEntry()) != null) {
                            String rawPath = tarEntry.getName();
                            String mappedRelPath = mapTermuxTarPath(rawPath);
                            if (mappedRelPath == null || mappedRelPath.isEmpty()) {
                                continue;
                            }

                            File outFile = new File(rootDir, mappedRelPath);
                            // Guard against Zip/Tar Slip
                            if (!outFile.getCanonicalPath().startsWith(rootDir.getCanonicalPath())) {
                                continue;
                            }

                            if (tarEntry.isDirectory()) {
                                if (!outFile.exists()) {
                                    outFile.mkdirs();
                                }
                            } else if (tarEntry.isSymbolicLink()) {
                                File parent = outFile.getParentFile();
                                if (parent != null && !parent.exists()) parent.mkdirs();
                                pendingSymlinks.put(outFile, tarEntry.getLinkName());
                                extractedCount++;
                            } else if (tarEntry.isLink()) {
                                File parent = outFile.getParentFile();
                                if (parent != null && !parent.exists()) parent.mkdirs();
                                String mappedLink = mapTermuxTarPath(tarEntry.getLinkName());
                                if (mappedLink != null) {
                                    pendingSymlinks.put(outFile, new File(rootDir, mappedLink).getAbsolutePath());
                                    extractedCount++;
                                }
                            } else if (tarEntry.isFile()) {
                                File parent = outFile.getParentFile();
                                if (parent != null && !parent.exists()) parent.mkdirs();
                                if (outFile.exists()) outFile.delete();

                                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                                    int len;
                                    while ((len = tarIn.read(buf)) != -1) {
                                        fos.write(buf, 0, len);
                                    }
                                }

                                // Set executable permission if tar mode has any exec bit or file is inside bin/ or lib/
                                int mode = tarEntry.getMode();
                                boolean hasExecBit = (mode & 0111) != 0;
                                boolean isInBinOrLib = mappedRelPath.startsWith("usr/bin/") ||
                                                       mappedRelPath.startsWith("usr/lib/") ||
                                                       mappedRelPath.startsWith("usr/libexec/");
                                if (hasExecBit || isInBinOrLib) {
                                    outFile.setExecutable(true, false);
                                }
                                outFile.setReadable(true, false);
                                extractedCount++;
                            }
                        }
                    }
                    break;
                }
            }
        }

        // Resolve symlinks (e.g., shared libraries libfoo.so.1 -> libfoo.so.1.2.3)
        for (Map.Entry<File, String> linkEntry : pendingSymlinks.entrySet()) {
            File linkFile = linkEntry.getKey();
            String target = linkEntry.getValue();
            try {
                if (linkFile.exists()) linkFile.delete();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Files.createSymbolicLink(linkFile.toPath(), Paths.get(target));
                } else {
                    Runtime.getRuntime().exec(new String[]{"ln", "-sf", target, linkFile.getAbsolutePath()}).waitFor();
                }
            } catch (Exception e) {
                // Fallback: copy target file if symlink creation is restricted
                File resolvedTarget = target.startsWith("/") ? new File(target) : new File(linkFile.getParentFile(), target);
                if (resolvedTarget.exists() && resolvedTarget.isFile()) {
                    try (FileInputStream in = new FileInputStream(resolvedTarget);
                         FileOutputStream out = new FileOutputStream(linkFile)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    }
                    linkFile.setExecutable(true, false);
                }
            }
        }

        makeExecutableRecursive(binDir);
        File libDir = new File(prefixDir, "lib");
        if (libDir.exists()) {
            makeExecutableRecursive(libDir);
        }

        return extractedCount;
    }

    /**
     * Termux .deb archives contain paths like:
     *   ./data/data/com.termux/files/usr/bin/fastfetch
     *   ./data/data/com.termux/files/usr/lib/libyyjson.so
     * This strips the Termux prefix so files extract into `<appFilesDir>/usr/...`.
     */
    private String mapTermuxTarPath(String rawPath) {
        if (rawPath == null) return null;
        String p = rawPath.replace("\\", "/");
        while (p.startsWith("./")) {
            p = p.substring(2);
        }
        if (p.startsWith("/")) {
            p = p.substring(1);
        }

        final String termuxFilesPrefix = "data/data/com.termux/files/";
        if (p.equals("data") || p.equals("data/data") || p.equals("data/data/com.termux") || p.equals("data/data/com.termux/files")) {
            return null;
        }
        if (p.startsWith(termuxFilesPrefix)) {
            return p.substring(termuxFilesPrefix.length());
        }
        return p;
    }

    private void makeExecutableRecursive(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                makeExecutableRecursive(f);
            } else {
                f.setExecutable(true, false);
                f.setReadable(true, false);
            }
        }
    }
}
