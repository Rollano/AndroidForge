# TermLauncher (Android Terminal Emulator & Home Launcher)

Isang Android Home Launcher na may built-in Terminal Emulator na konektado sa online **Termux Repository** (`packages-cf.termux.dev`), may **Pinch-to-Zoom**, **App Icons sa Drawer**, at **Full Customization** (Font style, Zoom/Font size, Text & Prompt color, Background tint/dim overlay, at Custom Wallpaper).

## Mga Bagong Feature:
1. **Pinch-to-Zoom In / Out**: Mag-pinch gamit ang dalawang daliri sa terminal area para i-zoom in o i-zoom out ang text (may live zoom percentage badge sa top bar at `zoom in / zoom out / reset` commands).
2. **App Icons sa Drawer**: Makikita ang actual app icon, pangalan, at package name ng bawat naka-install na app sa drawer, kasama ang live search filter (`Filter apps...`).
3. **Customization (Font, Color, Background Wallpaper)**: Pindutin ang palette icon sa top bar o i-type ang `customize` / `wallpaper` sa terminal para pumili ng:
   - Font style (Monospace, Monospace Bold, Serif Classic, Sans-Serif Clean)
   - Zoom / Font size (`8sp` hanggang `30sp`)
   - Text color & Prompt color presets
   - Background theme tint & Dim/Overlay opacity (`0%` - `100%`)
   - Custom background wallpaper mula sa gallery/storage ng phone

## Paano i-build bilang APK (Gamit ang Android Studio o AndroidIDE):
1. I-extract ang `TermLauncher-Android-Source-v2.zip`.
2. Buksan ang folder sa **Android Studio** (o **AndroidIDE** sa Android phone).
3. Hintayin matapos ang Gradle sync, pagkatapos ay i-click ang **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. I-install ang nabuong `app-debug.apk` at piliin ang **TermLauncher** bilang default Home App ng iyong phone.

## Koneksyon sa `bin`, `su`, `adb`, at `cmatrix`:
- **Awtomatikong konektado sa `$PREFIX/bin`**: Kapag nag-install ka ng package gaya ng `pkg install cmatrix`, awtomatiko ring ida-download ang dependencies nito (gaya ng `ncurses`), ine-extract sa `$PREFIX` (`files/usr`), ginagawang executable ang binaries sa `$PREFIX/bin`, at isinasama sa `PATH`, `LD_LIBRARY_PATH`, at `TERMINFO` para ma-run mo agad ang `cmatrix`.
- **Command `bin`**: Ipinapakita ang lahat ng binaries na nasa `$PREFIX/bin` kasama ang `su` at `adb` wrappers.
- **`su` command**: Naghahanap ng root `su` binary sa device (`/system/bin/su`, `/system/xbin/su`, `/sbin/su`, KernelSU/APatch paths) at ine-execute ito. (Kailangan ng rooted device para gumana ang root privileges).
- **`adb` command**: Naghahanap ng `adb` binary (`$PREFIX/bin/adb.bin` o `/system/bin/adb`). Sa loob ng Android shell, puwede ring gumamit ng direct shell commands o mag-lagay ng `adb.bin` sa `$PREFIX/bin`.
