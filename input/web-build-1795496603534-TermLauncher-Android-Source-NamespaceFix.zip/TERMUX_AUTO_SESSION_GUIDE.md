# Auto-Run Termux Session When Granted in App

## Paano Gumagana ang Auto-Session sa `TermuxBridgeHelper`
1. **Grant / Enable sa App**:
   - Tawagin ang `TermuxBridgeHelper.setAutoSessionGranted(context, true)` kapag na-grant o na-enable ng user ang Termux session access sa app (at opsyonal na mag-set ng default command gamit ang `setAutoSessionCommand(context, "...")`).
2. **Awtomatikong Pag-Run ng Session**:
   - Tawagin ang `TermuxBridgeHelper.startSessionIfGranted(context, optionalCommand, background)` kapag nagbukas o nag-resume ang app/session.
   - Kung naka-`true` ang `isAutoSessionGranted(context)` at naka-install ang `com.termux`, ipapadala nito ang `com.termux.RUN_COMMAND` intent sa `com.termux.app.RunCommandService` (at may fallback sa pagbukas ng Termux launch intent kung naka-block ang background service start).
3. **Mga Kailangan sa Termux Side**:
   - Naka-install ang `com.termux`.
   - Naka-set ang `allow-external-apps = true` sa `~/.termux/termux.properties` sa loob ng Termux, at na-reload ang config (`termux-reload-settings` o restart ng Termux) para tanggapin ang `RUN_COMMAND` intents mula sa ibang app.

## Kasama sa `TermLauncher-Settings-Fix-v4.zip`
- `app/src/main/java/com/termlauncher/app/SettingsActivity.java`
- `app/src/main/java/com/termlauncher/app/TermuxBridgeHelper.java`
- `app/src/main/res/layout/activity_settings.xml`
- `TERMUX_AUTO_SESSION_GUIDE.md`
