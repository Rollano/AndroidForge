# Git Clone Without Root (Non-Root / AndroidForge Safe Guide)

`git clone` does **not** require root (`su`). Permission errors usually happen when cloning into a non-writable directory or using an unconfigured SSH remote instead of HTTPS.

## Recommended Non-Root Clone Steps
1. Move into a writable directory (for example, your home or projects directory):
   ```bash
   cd ~
   mkdir -p ~/projects
   cd ~/projects
   ```
2. Clone using HTTPS (no SSH key setup required):
   ```bash
   git clone https://github.com/Rollano/AndroidForge.git
   ```
3. Avoid cloning directly onto restricted paths (such as `/`, `/system`, or `/data/local/tmp`) or prepending `su` to `git clone`.
