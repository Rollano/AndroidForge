# TermLauncher CleanFix

## Fix applied
- Removed `app/src/main/res/values/themes.xml` because it declared `Theme.TermLauncher` a second time.
- Kept the complete `Theme.TermLauncher` definition in `app/src/main/res/values/styles.xml`.
- Kept the manifest reference `@style/Theme.TermLauncher` unchanged.
- Kept the existing AndroidX and Material dependencies.

## Validation performed
- Parsed all project XML files successfully.
- Checked `res/values` resource identifiers: no duplicate `(resource type, name)` declarations found.
- Checked `Theme.TermLauncher`: exactly one declaration remains, in `styles.xml`.

## Build status
The uploaded AndroidForge log identified the failure as `:app:mergeDebugResources` caused by duplicate `style/Theme.TermLauncher` in `themes.xml` and `styles.xml`. This archive removes that exact duplicate. An APK build has not been run in this environment, so AndroidForge must still confirm the final build.
