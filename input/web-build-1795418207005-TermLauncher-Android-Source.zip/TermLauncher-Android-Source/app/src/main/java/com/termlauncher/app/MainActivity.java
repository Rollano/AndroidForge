package com.termlauncher.app;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView terminalOutput;
    private EditText commandInput;
    private ScrollView terminalScroll;
    private LinearLayout terminalPane;
    private LinearLayout drawerPane;
    private LinearLayout mediaPane;
    private LinearLayout webPane;

    private ListView appsListView;
    private ListView mediaListView;
    private VideoView videoPlayer;
    private WebView webView;
    private EditText urlInput;
    private TextView mediaStatusText;

    private MediaPlayer audioPlayer;
    private final List<String> appLabels = new ArrayList<>();
    private final List<String> appPackages = new ArrayList<>();
    private final List<String> mediaTitles = new ArrayList<>();
    private final List<Uri> mediaUris = new ArrayList<>();
    private final List<Boolean> mediaIsVideo = new ArrayList<>();

    private float currentFontSize = 14f;
    private ScaleGestureDetector scaleDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        terminalPane = findViewById(R.id.terminalPane);
        drawerPane = findViewById(R.id.drawerPane);
        mediaPane = findViewById(R.id.mediaPane);
        webPane = findViewById(R.id.webPane);

        terminalOutput = findViewById(R.id.terminalOutput);
        commandInput = findViewById(R.id.commandInput);
        terminalScroll = findViewById(R.id.terminalScroll);
        Button runButton = findViewById(R.id.runButton);

        appsListView = findViewById(R.id.appsListView);
        mediaListView = findViewById(R.id.mediaListView);
        videoPlayer = findViewById(R.id.videoPlayer);
        mediaStatusText = findViewById(R.id.mediaStatusText);
        Button stopMediaButton = findViewById(R.id.stopMediaButton);

        webView = findViewById(R.id.webView);
        urlInput = findViewById(R.id.urlInput);
        Button goWebButton = findViewById(R.id.goWebButton);

        Button btnTabTerm = findViewById(R.id.btnTabTerm);
        Button btnTabDrawer = findViewById(R.id.btnTabDrawer);
        Button btnTabMedia = findViewById(R.id.btnTabMedia);
        Button btnTabWeb = findViewById(R.id.btnTabWeb);

        btnTabTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPane("term");
            }
        });
        btnTabDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadInstalledApps();
                showPane("drawer");
            }
        });
        btnTabMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadLocalMedia();
                showPane("media");
            }
        });
        btnTabWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPane("web");
            }
        });

        setupTerminal(runButton);
        setupAppDrawer();
        setupMediaPlayer(stopMediaButton);
        setupWebView(goWebButton);

        appendLog("TermLauncher v3.3 ready.\nTabs: Terminal, App Drawer, Media, WebView.\n");
        showPane("term");
    }

    private void showPane(String pane) {
        terminalPane.setVisibility("term".equals(pane) ? View.VISIBLE : View.GONE);
        drawerPane.setVisibility("drawer".equals(pane) ? View.VISIBLE : View.GONE);
        mediaPane.setVisibility("media".equals(pane) ? View.VISIBLE : View.GONE);
        webPane.setVisibility("web".equals(pane) ? View.VISIBLE : View.GONE);
    }

    private void setupTerminal(Button runButton) {
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                currentFontSize *= detector.getScaleFactor();
                currentFontSize = Math.max(10f, Math.min(28f, currentFontSize));
                terminalOutput.setTextSize(currentFontSize);
                return true;
            }
        });

        terminalScroll.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                scaleDetector.onTouchEvent(event);
                return false;
            }
        });

        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cmd = commandInput.getText().toString().trim();
                if (!cmd.isEmpty()) {
                    executeCommand(cmd);
                    commandInput.setText("");
                }
            }
        });
    }

    private void setupAppDrawer() {
        loadInstalledApps();
        appsListView.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < appPackages.size()) {
                    String pkg = appPackages.get(position);
                    Intent launchIntent = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (launchIntent != null) {
                        startActivity(launchIntent);
                    } else {
                        appendLog("Cannot launch package: " + pkg + "\n");
                    }
                }
            }
        });
    }

    private void loadInstalledApps() {
        appLabels.clear();
        appPackages.clear();
        PackageManager pm = getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolvedApps = pm.queryIntentActivities(mainIntent, 0);
        for (ResolveInfo info : resolvedApps) {
            CharSequence label = info.loadLabel(pm);
            String pkg = info.activityInfo.packageName;
            if (label != null && pkg != null && !pkg.equals(getPackageName())) {
                appLabels.add(label.toString() + " (" + pkg + ")");
                appPackages.add(pkg);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, appLabels);
        appsListView.setAdapter(adapter);
    }

    private void setupMediaPlayer(Button stopMediaButton) {
        loadLocalMedia();
        mediaListView.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < mediaUris.size()) {
                    stopAllMedia();
                    Uri uri = mediaUris.get(position);
                    boolean isVideo = mediaIsVideo.get(position);
                    String title = mediaTitles.get(position);
                    mediaStatusText.setText("Playing: " + title);
                    try {
                        if (isVideo) {
                            videoPlayer.setVisibility(View.VISIBLE);
                            videoPlayer.setVideoURI(uri);
                            videoPlayer.start();
                        } else {
                            videoPlayer.setVisibility(View.GONE);
                            audioPlayer = new MediaPlayer();
                            audioPlayer.setDataSource(MainActivity.this, uri);
                            audioPlayer.prepare();
                            audioPlayer.start();
                        }
                    } catch (Exception e) {
                        mediaStatusText.setText("Media error: " + e.getMessage());
                    }
                }
            }
        });

        stopMediaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAllMedia();
                mediaStatusText.setText("Playback stopped.");
            }
        });
    }

    private void loadLocalMedia() {
        mediaTitles.clear();
        mediaUris.clear();
        mediaIsVideo.clear();

        Cursor audioCursor = null;
        try {
            audioCursor = getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE},
                    null, null, null);
            if (audioCursor != null) {
                int idCol = audioCursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
                int titleCol = audioCursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
                while (audioCursor.moveToNext()) {
                    long id = audioCursor.getLong(idCol);
                    String title = audioCursor.getString(titleCol);
                    Uri contentUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
                    mediaTitles.add("[Audio] " + (title != null ? title : "Track " + id));
                    mediaUris.add(contentUri);
                    mediaIsVideo.add(false);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (audioCursor != null) {
                audioCursor.close();
            }
        }

        Cursor videoCursor = null;
        try {
            videoCursor = getContentResolver().query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE},
                    null, null, null);
            if (videoCursor != null) {
                int idCol = videoCursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                int titleCol = videoCursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE);
                while (videoCursor.moveToNext()) {
                    long id = videoCursor.getLong(idCol);
                    String title = videoCursor.getString(titleCol);
                    Uri contentUri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
                    mediaTitles.add("[Video] " + (title != null ? title : "Video " + id));
                    mediaUris.add(contentUri);
                    mediaIsVideo.add(true);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (videoCursor != null) {
                videoCursor.close();
            }
        }

        if (mediaTitles.isEmpty()) {
            mediaTitles.add("No local audio/video found");
            mediaUris.add(Uri.EMPTY);
            mediaIsVideo.add(false);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mediaTitles);
        mediaListView.setAdapter(adapter);
    }

    private void stopAllMedia() {
        if (audioPlayer != null) {
            try {
                if (audioPlayer.isPlaying()) {
                    audioPlayer.stop();
                }
                audioPlayer.release();
            } catch (Exception ignored) {
            }
            audioPlayer = null;
        }
        if (videoPlayer != null && videoPlayer.isPlaying()) {
            videoPlayer.stopPlayback();
        }
    }

    private void setupWebView(Button goWebButton) {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        goWebButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String raw = urlInput.getText().toString().trim();
                if (!raw.isEmpty()) {
                    String url = raw.startsWith("http://") || raw.startsWith("https://") ? raw : "https://" + raw;
                    webView.loadUrl(url);
                }
            }
        });

        webView.loadUrl("https://example.com");
    }

    private void executeCommand(final String cmd) {
        appendLog("$ " + cmd + "\n");
        if (cmd.equals("help")) {
            appendLog("Built-in commands: help, clear, apps, media, web\n");
            return;
        }
        if (cmd.equals("clear")) {
            terminalOutput.setText("");
            return;
        }
        if (cmd.equals("apps")) {
            loadInstalledApps();
            showPane("drawer");
            return;
        }
        if (cmd.equals("media")) {
            loadLocalMedia();
            showPane("media");
            return;
        }
        if (cmd.equals("web")) {
            showPane("web");
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process process = Runtime.getRuntime().exec(new String[]{"/system/bin/sh", "-c", cmd});
                    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                    BufferedReader errReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                    final StringBuilder output = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        output.append(line).append("\n");
                    }
                    while ((line = errReader.readLine()) != null) {
                        output.append("[err] ").append(line).append("\n");
                    }
                    process.waitFor();
                    final String result = output.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            appendLog(result);
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            appendLog("Error: " + e.getMessage() + "\n");
                        }
                    });
                }
            }
        }).start();
    }

    private void appendLog(String text) {
        terminalOutput.append(text);
        terminalScroll.post(new Runnable() {
            @Override
            public void run() {
                terminalScroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        stopAllMedia();
        super.onDestroy();
    }
}
