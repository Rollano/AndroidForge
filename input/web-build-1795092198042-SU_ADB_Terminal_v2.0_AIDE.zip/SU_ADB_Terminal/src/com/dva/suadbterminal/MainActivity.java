package com.dva.suadbterminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class MainActivity extends Activity {
    private int BG=Color.rgb(7,12,10), PANEL=Color.rgb(15,24,19), GREEN=Color.rgb(91,255,130),
        MUTED=Color.rgb(139,165,145), ORANGE=Color.rgb(255,180,70), WHITE=Color.rgb(225,240,228), CYAN=Color.rgb(90,220,210);
    private static final int MAX_OUTPUT=60000;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Object lock=new Object();
    private LinearLayout root, toolbar;
    private TextView output,status;
    private ScrollView scroll;
    private AutoCompleteTextView input;
    private Process process;
    private DataOutputStream shellIn;
    private volatile boolean rootMode=true, closing=false, rootOk=false;
    private final ArrayList<String> history=new ArrayList<String>();
    private int historyPos=0;
    private final String[] suggestions={"id","whoami","getprop","uname -a","df -h","free -h","top -n 1","pm list packages","dumpsys battery","logcat -v time -t 100","ip addr","ip route","ping -c 4 1.1.1.1","settings list global","ls -la /sdcard","adb shell getprop"};
    private boolean amberTheme=false;

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        buildUI(); bootIntro(); startShell(true);
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(9));d.setStroke(dp(1),Color.rgb(40,65,48));return d;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setTextColor(GREEN);b.setAllCaps(false);b.setPadding(dp(4),0,dp(4),0);b.setBackground(bg(PANEL));return b;}
    private void buildUI(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(10),dp(10),dp(10),dp(8));root.setBackgroundColor(BG);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(1);
        TextView title=text("KALI SU TERMINAL",19,WHITE);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        titles.addView(title);TextView sub=text("ROOT SHELL  •  ANDROID TOOLKIT",9,MUTED);titles.addView(sub);
        head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        status=text("ROOT: STARTING",10,ORANGE);status.setTypeface(Typeface.MONOSPACE,1);status.setPadding(dp(8),dp(7),dp(8),dp(7));status.setBackground(bg(PANEL));head.addView(status);
        root.addView(head);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);
        toolbar=new LinearLayout(this);toolbar.setOrientation(0);
        String[] tools={"TERM","ROOT","FILES","LOGCAT","NETWORK","SCRIPTS","MONITOR","THEME"};
        for(final String item:tools){Button b=button(item);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(38));p.rightMargin=dp(5);toolbar.addView(b,p);b.setOnClickListener(v->tool(item));}
        hsv.addView(toolbar);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(44));hp.topMargin=dp(9);root.addView(hsv,hp);
        scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackground(bg(Color.rgb(2,7,4)));scroll.setPadding(dp(9),dp(9),dp(9),dp(9));
        output=text("",12,GREEN);output.setTypeface(Typeface.MONOSPACE);output.setTextIsSelectable(true);output.setLineSpacing(dp(2),1f);
        scroll.addView(output);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        input=new AutoCompleteTextView(this);input.setSingleLine(true);input.setTextSize(13);input.setTextColor(WHITE);input.setHintTextColor(MUTED);input.setHint("command • ↑ history • suggestions");input.setTypeface(Typeface.MONOSPACE);
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);input.setImeOptions(EditorInfo.IME_ACTION_SEND);input.setPadding(dp(10),0,dp(5),0);input.setBackground(bg(PANEL));
        input.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,suggestions));input.setThreshold(1);
        input.setOnEditorActionListener((v,a,e)->{if(a==EditorInfo.IME_ACTION_SEND||(e!=null&&e.getKeyCode()==KeyEvent.KEYCODE_ENTER&&e.getAction()==KeyEvent.ACTION_DOWN)){runInput();return true;}return false;});
        input.setOnKeyListener((v,key,event)->{if(event.getAction()==KeyEvent.ACTION_DOWN&&(key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_DOWN)){browseHistory(key==KeyEvent.KEYCODE_DPAD_UP?-1:1);return true;}return false;});
        row.addView(input,new LinearLayout.LayoutParams(0,dp(48),1));Button run=button("RUN");LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(dp(66),dp(48));rp.leftMargin=dp(6);row.addView(run,rp);run.setOnClickListener(v->runInput());root.addView(row);
        TextView foot=text("ROOT COMMANDS CAN MODIFY OR DAMAGE YOUR DEVICE",8,MUTED);foot.setGravity(Gravity.CENTER);foot.setPadding(0,dp(7),0,0);root.addView(foot);
        setContentView(root);
    }
    private void bootIntro(){
        append("[ KALI SU TERMINAL ]\\n",CYAN);
        append("Initializing local Android shell interface...\\n",MUTED);
        append("[ OK ] Terminal UI ready\\n[ OK ] Command suggestions loaded\\n[ OK ] Root provider check starting\\n\\n",GREEN);
        append("NOTE: app startup animation only; this does not replace Android's device boot animation.\\n",MUTED);
    }
    private void append(String s,int color){if(output==null)return; android.text.SpannableString sp=new android.text.SpannableString(s);sp.setSpan(new android.text.style.ForegroundColorSpan(color),0,sp.length(),0);output.append(sp);if(output.length()>MAX_OUTPUT)output.setText(output.getText().subSequence(output.length()-MAX_OUTPUT,output.length()));scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}
    private void setStatus(String s,int c){handler.post(()->{if(status!=null){status.setText(s);status.setTextColor(c);}});}
    private void startShell(boolean root){
        rootMode=root;closing=false;setStatus(root?"ROOT: REQUESTING":"SHELL: STARTING",ORANGE);
        new Thread(()->{try{
            Process p=new ProcessBuilder(root?"su":"sh").redirectErrorStream(true).start();
            DataOutputStream in=new DataOutputStream(p.getOutputStream());
            synchronized(lock){process=p;shellIn=in;}
            in.write(("export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:$PATH; export HOME=/data/local/tmp; echo __READY__; id\\n").getBytes("UTF-8"));in.flush();
            BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;while((line=r.readLine())!=null){final String ln=line;if(ln.contains("uid=0")){rootOk=true;setStatus("ROOT: ACTIVE",GREEN);}if(ln.contains("__READY__")&&!root){setStatus("SHELL: READY",CYAN);continue;}if(ln.contains("__READY__"))continue;handler.post(()->append(ln+"\\n",GREEN));}
            if(!closing)setStatus("SHELL: CLOSED",ORANGE);
        }catch(Exception e){setStatus(root?"ROOT: UNAVAILABLE":"SHELL: FAILED",Color.RED);handler.post(()->append("[shell error] "+e+"\\n",ORANGE));}
        }).start();
    }
    private void write(String cmd){synchronized(lock){try{if(shellIn==null){append("[!] Shell is not ready.\\n",ORANGE);return;}shellIn.write((cmd+"\\n").getBytes("UTF-8"));shellIn.flush();}catch(Exception e){append("[write error] "+e+"\\n",ORANGE);}}}
    private void runInput(){String c=input.getText().toString().trim();if(c.length()==0)return;input.setText("");hideKeyboard();history.add(c);historyPos=history.size();append((rootMode?"root":"shell")+" $ "+c+"\\n",ORANGE);
        if(c.equals("clear")){output.setText("");return;}
        if(c.startsWith("adb shell "))c=c.substring(10);else if(c.equals("adb logcat"))c="logcat";else if(c.equals("adb reboot"))c="reboot";
        else if(c.startsWith("adb ")){append("This app is an on-device shell, not a full ADB host. adb devices/push/pull/install are not provided.\\n",ORANGE);return;}
        write(c);
    }
    private void browseHistory(int direction){if(history.isEmpty())return;historyPos=Math.max(0,Math.min(history.size(),historyPos+direction));input.setText(historyPos==history.size()?"":history.get(historyPos));input.setSelection(input.length());}
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);}catch(Exception e){}}
    private void tool(String name){
        if(name.equals("TERM")){append("\\n[ Terminal selected ]\\n",CYAN);input.requestFocus();return;}
        if(name.equals("ROOT")){new AlertDialog.Builder(this).setTitle("Root manager status").setMessage("Shell mode: "+(rootMode?"ROOT":"NORMAL")+"\\nRoot confirmed: "+rootOk+"\\nProvider: Magisk / KernelSU / APatch (if installed)\\n\\nSwitching shell restarts the current session.").setPositiveButton("SWITCH MODE",(d,w)->{stopShell();startShell(!rootMode);}).setNegativeButton("CLOSE",null).show();return;}
        if(name.equals("FILES")){fileBrowser();return;}
        if(name.equals("LOGCAT")){append("\\n[ Starting live logcat; run 'logcat -c' only if you intentionally want to clear logs ]\\n",CYAN);write("logcat -v time -t 200");return;}
        if(name.equals("NETWORK")){String[] a={"ip addr","ip route","getprop | grep -i dns","ping -c 4 1.1.1.1","ss -tuln","dumpsys connectivity"};new AlertDialog.Builder(this).setTitle("Network tools").setItems(a,(d,w)->{append("$ "+a[w]+"\\n",ORANGE);write(a[w]);}).show();return;}
        if(name.equals("MONITOR")){String[] a={"top -n 1 -b","cat /proc/meminfo","df -h","dumpsys battery","dumpsys cpuinfo"};new AlertDialog.Builder(this).setTitle("Device monitor").setItems(a,(d,w)->{append("$ "+a[w]+"\\n",ORANGE);write(a[w]);}).show();return;}
        if(name.equals("SCRIPTS")){scriptManager();return;}
        if(name.equals("THEME")){amberTheme=!amberTheme;GREEN=amberTheme?Color.rgb(255,190,80):Color.rgb(91,255,130);output.setTextColor(GREEN);append("\\n[ Theme changed: "+(amberTheme?"Amber":"Kali Green")+" ]\\n",GREEN);return;}
    }
    private void fileBrowser(){
        final EditText path=new EditText(this);path.setSingleLine(true);path.setText("/sdcard");path.setTextColor(WHITE);
        new AlertDialog.Builder(this).setTitle("Root file browser").setMessage("Enter a directory path. Listing uses shell permissions.").setView(path).setPositiveButton("LIST",(d,w)->{String p=path.getText().toString().trim();append("\\n$ ls -la "+p+"\\n",ORANGE);write("ls -la "+quote(p));}).setNegativeButton("CANCEL",null).show();
    }
    private String quote(String s){return "'"+s.replace("'","'\\\\''")+"'";}
    private void scriptManager(){
        File dir=new File(getFilesDir(),"scripts");if(!dir.exists())dir.mkdirs();final File[] files=dir.listFiles();
        ArrayList<String> names=new ArrayList<String>();if(files!=null)for(File f:files)if(f.isFile()&&f.getName().endsWith(".sh"))names.add(f.getName());
        String[] options=new String[names.size()+1];options[0]="+ Create new script";for(int i=0;i<names.size();i++)options[i+1]=names.get(i);
        new AlertDialog.Builder(this).setTitle("Local script manager").setItems(options,(d,which)->{if(which==0)editScript(null);else editScript(new File(dir,names.get(which-1)));}).setNegativeButton("CLOSE",null).show();
    }
    private void editScript(File file){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(8),0,dp(8),0);
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("script-name.sh");name.setTextColor(WHITE);box.addView(name);
        EditText body=new EditText(this);body.setGravity(Gravity.TOP);body.setMinLines(8);body.setTextColor(WHITE);body.setTypeface(Typeface.MONOSPACE);body.setHint("#!/system/bin/sh\\necho Hello");box.addView(body);
        if(file!=null){name.setText(file.getName());try{BufferedReader r=new BufferedReader(new FileReader(file));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l).append("\\n");body.setText(s.toString());r.close();}catch(Exception e){}}
        new AlertDialog.Builder(this).setTitle(file==null?"Create script":"Edit / run script").setView(box).setPositiveButton("SAVE",(d,w)->{String n=name.getText().toString().trim();if(!n.matches("[A-Za-z0-9_.-]+")){append("Invalid script filename.\\n",ORANGE);return;}if(!n.endsWith(".sh"))n+=".sh";File out=new File(new File(getFilesDir(),"scripts"),n);try{FileWriter fw=new FileWriter(out);fw.write(body.getText().toString());fw.close();append("Saved script: "+out.getName()+"\\n",GREEN);}catch(Exception e){append("Save failed: "+e+"\\n",ORANGE);}}).setNeutralButton("RUN",(d,w)->{if(file!=null){append("$ sh "+file.getName()+"\\n",ORANGE);write("sh "+quote(file.getAbsolutePath()));}else append("Save the new script first, then select it to run.\\n",ORANGE);}).setNegativeButton("CANCEL",null).show();
    }
    private void stopShell(){closing=true;synchronized(lock){try{if(shellIn!=null){shellIn.write("exit\\n".getBytes("UTF-8"));shellIn.flush();shellIn.close();}}catch(Exception e){}try{if(process!=null)process.destroy();}catch(Exception e){}shellIn=null;process=null;}}
    @Override public void onDestroy(){stopShell();super.onDestroy();}
}
