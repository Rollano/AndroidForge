KALI SU TERMINAL v2.0 — ANDROID AIDE SOURCE
==========================================
Import the SU_ADB_Terminal folder as an Android App Project in classic AIDE,
or open it as a Gradle project in AndroidIDE / another compatible IDE.

FEATURES
--------
- Persistent on-device `su` or `sh` shell; root prompt via Magisk, KernelSU,
  APatch, or another compatible su provider.
- Kali-inspired dark interface, green terminal output, amber alternate theme.
- In-app startup intro (not the phone's real Android boot animation).
- Live command output, keyboard Up/Down history, command autocomplete suggestions.
- Root status and root/normal shell switching.
- ADB-style local shortcuts: `adb shell <command>`, `adb logcat`, `adb reboot`.
- Root file listing: enter a path and run `ls -la` through the shell.
- Logcat shortcut.
- Network diagnostics: ip addr, ip route, DNS properties, ping, ss, connectivity.
- Script manager: create/save scripts in app-private storage and run saved scripts.
- Device monitor: top, meminfo, df, battery and CPU information.

LIMITATIONS
-----------
This is an on-device shell, NOT a full ADB host. It does not implement adb
devices, push, pull, or install. Network commands depend on binaries present in
the Android build and may be restricted.

The file browser lists paths through shell commands; it is not a graphical file
manager and does not provide unrestricted scoped-storage access. Scripts are
stored privately inside this app. Review scripts before running them as root.

The startup intro is an in-app terminal sequence. It cannot change the phone's
actual boot animation.

BUILD
-----
Classic AIDE: extract ZIP and open SU_ADB_Terminal as an Android App Project.
Gradle IDE: Android Gradle Plugin 8.6.1, Gradle 8.7, JDK 17, compile SDK 35.
If your AIDE does not support Gradle projects, use its classic project importer
and ensure the required Android SDK platform is installed.

PACKAGE
-------
Application ID: com.dva.suadbterminal
Version: 2.0 (versionCode 2)
Minimum Android: 6.0 / API 23
Target Android: API 28
Java, no AndroidX or third-party dependencies.

SAFETY
------
Root commands can erase data, alter permissions, disable services or make the
device unbootable. No partition flashing or boot image modification is done
automatically. Only run commands you understand. Use network diagnostics only
on networks you own or are authorized to test.
