# NH Terminal Launcher (v1.2 — Termux Pure Black UI)

- Full-screen `#000000` black background with inline colored prompt (`~ $ ` / `/ $ `) and block cursor (`█`) matching `424.png`.
- 2-row extra keys bar (`ESC / - HOME ↑ END PGUP` and `⇥ CTRL ALT ← ↓ → PGDN`).
- Includes `setup-storage`, `play music` (`next` / `stop` / `<name>`), `apps` / `open <app>`, `pwd` / `ls` / `cd`, `su` / `adb <cmd>`, and `clear`.
