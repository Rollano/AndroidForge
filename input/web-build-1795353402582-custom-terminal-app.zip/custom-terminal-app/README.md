# termux-vision (v20 — Help, How-To, Professional Notice, Root `su`, Storage Browser & Inline Media Player)

- Adds dedicated **Help Page** (`helppage`), **How To Use Page** (`howto`), and **For Professional Use Only** (`pro`) pages in both the overflow menu (`:`), navigation drawer, and terminal commands.
- Adds **Root (`su`) Command Execution** (`su`, `su <cmd>`, `su -c "<cmd>"`) for rooted devices.
- Adds **Storage Explorer** (`storage`, `sdcard`, `storage-grant`, `cd /sdcard`) with Android storage permissions (`READ_EXTERNAL_STORAGE`, `READ_MEDIA_AUDIO`, `READ_MEDIA_VIDEO`, `MANAGE_EXTERNAL_STORAGE`).
- Adds an **Embedded Terminal Music & Video Player** (`play <file>`, `music <file>`, `video <file>`, `media`, `stopmedia`) that plays audio and video directly inside the terminal screen.
