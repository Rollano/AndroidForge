# TermLauncher resource merge fix

- Kept exactly one `Theme.TermLauncher` style declaration in `app/src/main/res/values/styles.xml`.
- Removed the duplicate declaration from `themes.xml` while preserving unrelated resources.
- Confirmed the app module declares `namespace 'com.termlauncher.app'`.
- Preserved the project wrapper directory expected by the previous AndroidForge workspace path.

This ZIP was statically checked for duplicate `Theme.TermLauncher` declarations and XML parsing, but an AndroidForge/Gradle APK build has not been run here.
