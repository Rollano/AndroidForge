package com.termlauncher.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView terminalOutput;
    private EditText commandInput;
    private WebView mediaWebView;
    private float textScale = 1.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        terminalOutput = findViewById(R.id.terminalOutput);
        commandInput = findViewById(R.id.commandInput);
        mediaWebView = findViewById(R.id.mediaWebView);

        WebSettings webSettings = mediaWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);

        appendLine("TermLauncher v18.0 initialized (com.termlauncher.app)");
        appendLine("Type 'help', 'termux', 'zoom+', 'zoom-', 'settings', 'about', or 'clear'.");

        Button runBtn = findViewById(R.id.runCommandButton);
        runBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executeCommand(commandInput.getText().toString().trim());
                commandInput.setText("");
            }
        });

        Button settingsBtn = findViewById(R.id.openSettingsButton);
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        Button aboutBtn = findViewById(R.id.openAboutButton);
        aboutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
            }
        });
    }

    private void executeCommand(String cmd) {
        if (cmd.isEmpty()) return;
        appendLine("$ " + cmd);

        switch (cmd.toLowerCase()) {
            case "help":
                appendLine("Commands: help | termux | storage | mirror | zoom+ | zoom- | settings | about | clear");
                break;
            case "termux":
                launchTermux();
                break;
            case "storage":
                appendLine("Tip: In Termux, run `termux-setup-storage` and ensure `allow-external-apps = true` in ~/.termux/termux.properties.");
                break;
            case "mirror":
                appendLine("Termux mirror configured: https://packages-cf.termux.dev/apt/termux-main");
                break;
            case "zoom+":
                textScale = Math.min(1.8f, textScale + 0.1f);
                terminalOutput.setTextScaleX(textScale);
                appendLine("Terminal text scale: " + String.format("%.1f", textScale) + "x");
                break;
            case "zoom-":
                textScale = Math.max(0.7f, textScale - 0.1f);
                terminalOutput.setTextScaleX(textScale);
                appendLine("Terminal text scale: " + String.format("%.1f", textScale) + "x");
                break;
            case "settings":
                startActivity(new Intent(this, SettingsActivity.class));
                break;
            case "about":
                startActivity(new Intent(this, AboutActivity.class));
                break;
            case "clear":
                terminalOutput.setText("");
                break;
            default:
                appendLine("Unknown command: " + cmd + " (type 'help')");
                break;
        }
    }

    private void launchTermux() {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.termux");
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launchIntent);
            appendLine("Launching com.termux...");
        } else {
            appendLine("com.termux not found on device.");
        }
    }

    private void appendLine(String line) {
        String current = terminalOutput.getText().toString();
        if (current.isEmpty()) {
            terminalOutput.setText(line);
        } else {
            terminalOutput.setText(current + "\n" + line);
        }
    }
}
