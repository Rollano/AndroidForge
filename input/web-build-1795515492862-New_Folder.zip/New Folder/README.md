# TermLauncher (`com.termlauncher.app`)

Custom Android home launcher and terminal emulator project prepared for **AndroidForge** / GitHub Actions builds.

## Key Features Included in v18
- **Home Launcher & App Drawer**: Clean home launcher setup with full-screen Settings and About views.
- **Terminal Emulator & Termux Bridge**: Configured for `com.termux` integration (`allow-external-apps = true`), Termux package mirrors (`packages-cf.termux.dev`), and `termux-setup-storage` workflows.
- **Built-in Media Players**: WebView-backed music and video player views.
- **GitHub Pages Download Site**: Ready-to-host landing page in `docs/index.html`.

## Build Notes (GitHub Actions / AndroidForge)
- Uses modern `actions/checkout@v5`, `actions/setup-java@v4`, and `actions/upload-artifact@v4` to avoid Node.js 20 deprecation warnings.
- Verified clean XML resources and no duplicate resource entries.
