# DVA Desktop — AndroidForge project

A native Android control panel for the DVA Termux Desktop installer.

## What it does
- Polished dark / neon-green DVA interface.
- Select XFCE or LXDE.
- Install, start, stop, and status actions.
- Downloads the current installer from the `Rollano/Kali-Pocket` GitHub repository and invokes it through Termux RUN_COMMAND.

## Important
This app is a controller, not a standalone Linux distribution. The Linux desktop runs inside Termux + Debian PRoot and is displayed using the separate Termux:X11 Android app. It does not root the phone or flash partitions.

## Requirements
1. Install Termux from a trusted source (prefer the official Termux GitHub releases or F-Droid).
2. Install the Termux:X11 Android app: https://github.com/termux/termux-x11/releases
3. Open Termux and run:
   ```sh
   mkdir -p ~/.termux
   echo 'allow-external-apps=true' >> ~/.termux/termux.properties
   ```
   Then fully close and reopen Termux.
4. Install this DVA Desktop APK.
5. Open DVA Desktop and tap Install Desktop. Termux must be installed with the same signing source as its companion plugins where applicable.

## Android permission
The app declares `com.termux.permission.RUN_COMMAND`. If Termux asks whether DVA Desktop may execute commands, allow it. If it does not prompt or the command does not launch, check Termux's external-app command setting and reopen Termux.

## Build with AndroidForge
Upload this ZIP as an Android source project. AndroidForge should detect the Gradle Android project and build the `app` module. App ID: `com.dva.desktop`.

## Notes
- Installation needs internet and several GB of free storage.
- First Debian + desktop install can take a while.
- The installer creates a separate Debian container named `dva-debian`; it does not reset Kali/NetHunter containers.
- The progress display is stage-based, not a byte-accurate download meter.
- This source project has not been built or tested on a physical device in this session.
