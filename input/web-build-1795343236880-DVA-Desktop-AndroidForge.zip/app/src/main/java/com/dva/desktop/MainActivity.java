package com.dva.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 13, 9);
    private final int PANEL = Color.rgb(16, 27, 20);
    private final int GREEN = Color.rgb(57, 255, 136);
    private final int MUTED = Color.rgb(151, 174, 159);
    private String theme = "xfce";
    private LinearLayout xfce, lxde;
    private LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUI();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(18));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private LinearLayout column() { LinearLayout x = new LinearLayout(this); x.setOrientation(1); return x; }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = column(); root.setBackgroundColor(BG); pad(root,20,20,20,28);
        scroll.addView(root); setContentView(scroll);

        LinearLayout brand = new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("DVA", 25, GREEN, true); mark.setLetterSpacing(.16f);
        TextView version = text("  DESKTOP  /  ANDROID", 10, MUTED, true);
        brand.addView(mark); brand.addView(version); root.addView(brand);
        TextView headline = text("Your Linux workspace.", 28, Color.WHITE, true);
        pad(headline,0,22,0,4); root.addView(headline);
        TextView sub = text("Install a Debian desktop environment on Termux with one guided setup.", 14, MUTED, false);
        root.addView(sub);

        LinearLayout status = column(); status.setBackground(shape(PANEL,0)); pad(status,16,15,16,15);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(22); root.addView(status,sp);
        TextView st = text("●  READY TO CONFIGURE", 11, GREEN, true); status.addView(st);
        TextView st2 = text("Termux + PRoot + Termux:X11", 13, Color.WHITE, false); pad(st2,0,7,0,0); status.addView(st2);

        TextView choose = text("01  /  CHOOSE YOUR DESKTOP", 12, GREEN, true); pad(choose,0,24,0,12); root.addView(choose);
        LinearLayout cards = new LinearLayout(this); cards.setOrientation(0);
        xfce = choiceCard("XFCE", "Full-featured\nCustomizable\nRecommended", theme.equals("xfce"));
        lxde = choiceCard("LXDE", "Lightweight\nLower resource use\nSimple & fast", theme.equals("lxde"));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,-2,1); cp.rightMargin=dp(7);
        cards.addView(xfce,cp); LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(0,-2,1); cp2.leftMargin=dp(7); cards.addView(lxde,cp2);
        root.addView(cards);

        TextView actions = text("02  /  QUICK ACTIONS", 12, GREEN, true); pad(actions,0,24,0,12); root.addView(actions);
        addButton("INSTALL DESKTOP", "Download setup script and install selected desktop", GREEN, BG, () -> run("install"));
        addButton("START DESKTOP", "Launch your saved XFCE / LXDE session", PANEL, Color.WHITE, () -> run("start"));
        addButton("STOP DESKTOP", "Close the desktop session safely", PANEL, Color.WHITE, () -> run("stop"));
        addButton("CHECK STATUS", "Open Termux and inspect installation status", PANEL, Color.WHITE, () -> run("status"));

        TextView note = text("REQUIREMENTS", 12, GREEN, true); pad(note,0,24,0,8); root.addView(note);
        TextView req = text("• Termux (F-Droid or official GitHub build)\\n• Termux:X11 Android app\\n• Internet connection and several GB of free storage\\n• Allow RUN_COMMAND access in Termux settings", 13, MUTED, false);
        req.setLineSpacing(dp(5),1f); root.addView(req);

        TextView footer = text("DVA DESKTOP  •  BUILT FOR ANDROID", 10, MUTED, true);
        footer.setGravity(Gravity.CENTER); pad(footer,0,28,0,0); root.addView(footer);
    }

    private LinearLayout choiceCard(String title, String desc, boolean active) {
        LinearLayout card = column(); card.setBackground(shape(active ? Color.rgb(15,42,26) : PANEL, active ? GREEN : 0));
        pad(card,14,16,10,16);
        TextView t = text(title,19,active?GREEN:Color.WHITE,true); card.addView(t);
        TextView d = text(desc,12,MUTED,false); d.setLineSpacing(dp(4),1f); pad(d,0,8,0,0); card.addView(d);
        card.setOnClickListener(v -> select(title.toLowerCase()));
        return card;
    }
    private View wrapAsText(LinearLayout card) { // keeps the card's native layout and click target
        return card;
    }
    private void select(String t) {
        theme=t;
        // Rebuild selection cards for consistent selected state.
        buildUI();
    }
    private void addButton(String title, String desc, int bg, int fg, Runnable action) {
        LinearLayout box = column(); box.setBackground(shape(bg, bg==GREEN ? GREEN : Color.rgb(38,57,44)));
        pad(box,16,14,16,14);
        TextView a = text(title,14,fg,true); box.addView(a);
        TextView b = text(desc,11,bg==GREEN?Color.rgb(15,48,28):MUTED,false); pad(b,0,4,0,0); box.addView(b);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(9); root.addView(box,p);
        box.setOnClickListener(v -> action.run());
    }
    private void run(String action) {
        String cmd = "mkdir -p \"$HOME\"; " +
            "curl -fsSL https://raw.githubusercontent.com/Rollano/Kali-Pocket/main/DVA-XFCE-Termux/dva-xfce-auto.sh -o \"$HOME/dva-xfce-auto.sh\" && " +
            "chmod +x \"$HOME/dva-xfce-auto.sh\" && " +
            (action.equals("install") ? "bash \"$HOME/dva-xfce-auto.sh\" install " + theme :
             "bash \"$HOME/dva-xfce-auto.sh\" " + action);
        try {
            Intent i = new Intent("com.termux.RUN_COMMAND");
            i.setClassName("com.termux", "com.termux.app.RunCommandService");
            i.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", cmd});
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false);
            startService(i);
            Toast.makeText(this, "Sent to Termux. Check the Termux session/notification.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not start Termux. Check setup guide.", Toast.LENGTH_LONG).show();
        }
    }
}
