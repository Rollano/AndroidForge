package com.termlauncher.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageView ivWallpaper;
    private View vBgOverlay;
    private TextView tvWindowTitle;
    private TextView tvZoomBadge;
    private TextView tvTerminalOutput;
    private TextView tvPrompt;
    private EditText etCommandInput;
    private EditText etAppFilter;
    private ScrollView terminalScroll;
    private ListView lvInstalledApps;

    private final List<TerminalSession> sessions = new ArrayList<>();
    private int currentSessionIndex = 0;

    private File appHomeDir;
    private TermuxRepoManager repoManager;
    private CustomizationManager customManager;
    private ScaleGestureDetector scaleGestureDetector;
    private float currentZoomFactor = 1.0f;

    private final List<AppItem> allInstalledApps = new ArrayList<>();
    private final List<AppItem> filteredInstalledApps = new ArrayList<>();
    private AppIconAdapter appIconAdapter;

    private ActivityResultLauncher<String[]> pickWallpaperLauncher;

    public static class AppItem {
        public String label;
        public String packageName;
        public Drawable icon;

        public AppItem(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    private class AppIconAdapter extends ArrayAdapter<AppItem> {
        AppIconAdapter(List<AppItem> items) {
            super(MainActivity.this, R.layout.item_app_icon, items);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView;
            if (row == null) {
                row = LayoutInflater.from(getContext()).inflate(R.layout.item_app_icon, parent, false);
            }
            AppItem item = getItem(position);
            ImageView ivIcon = row.findViewById(R.id.iv_app_icon);
            TextView tvName = row.findViewById(R.id.tv_app_name);
            TextView tvPkg = row.findViewById(R.id.tv_app_pkg);

            if (item != null) {
                ivIcon.setImageDrawable(item.icon);
                tvName.setText(item.label);
                tvPkg.setText(item.packageName);
            }
            return row;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customManager = new CustomizationManager(this);

        pickWallpaperLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri != null) {
                    try {
                        getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                    } catch (Exception ignored) {
                    }
                    if (customManager.saveWallpaperFromUri(uri)) {
                        applyCustomization();
                        Toast.makeText(this, "Wallpaper updated!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to load image.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );

        drawerLayout = findViewById(R.id.drawer_layout);
        ivWallpaper = findViewById(R.id.iv_wallpaper);
        vBgOverlay = findViewById(R.id.v_bg_overlay);
        tvWindowTitle = findViewById(R.id.tv_window_title);
        tvZoomBadge = findViewById(R.id.tv_zoom_badge);
        tvTerminalOutput = findViewById(R.id.tv_terminal_output);
        tvPrompt = findViewById(R.id.tv_prompt);
        etCommandInput = findViewById(R.id.et_command_input);
        etAppFilter = findViewById(R.id.et_app_filter);
        terminalScroll = findViewById(R.id.terminal_scroll);
        lvInstalledApps = findViewById(R.id.lv_installed_apps);

        appHomeDir = getDir("HOME", MODE_PRIVATE);
        repoManager = new TermuxRepoManager(getFilesDir());

        sessions.add(new TerminalSession("Window 1", appHomeDir));
        loadSession(0);

        setupPinchToZoom();
        applyCustomization();

        ImageButton btnMenu = findViewById(R.id.btn_menu);
        btnMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        LinearLayout windowSelector = findViewById(R.id.window_selector);
        windowSelector.setOnClickListener(v -> showWindowPicker());

        ImageButton btnNewWindow = findViewById(R.id.btn_new_window);
        btnNewWindow.setOnClickListener(v -> {
            int num = sessions.size() + 1;
            sessions.add(new TerminalSession("Window " + num, appHomeDir));
            loadSession(sessions.size() - 1);
        });

        ImageButton btnCustomize = findViewById(R.id.btn_customize);
        btnCustomize.setOnClickListener(v -> showCustomizeDialog());

        ImageButton btnCloseWindow = findViewById(R.id.btn_close_window);
        btnCloseWindow.setOnClickListener(v -> {
            if (sessions.size() > 1) {
                sessions.remove(currentSessionIndex);
                currentSessionIndex = Math.max(0, currentSessionIndex - 1);
                loadSession(currentSessionIndex);
            } else {
                sessions.get(0).history = new StringBuilder(":/ $ cd ~\n");
                loadSession(0);
            }
        });

        ImageButton btnMore = findViewById(R.id.btn_more);
        btnMore.setOnClickListener(v -> showMoreMenu());

        etCommandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                String cmd = etCommandInput.getText().toString().trim();
                etCommandInput.setText("");
                executeCommand(cmd);
                return true;
            }
            return false;
        });

        etAppFilter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterApps(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        loadInstalledApps();
    }

    private void setupPinchToZoom() {
        currentZoomFactor = customManager.getFontSizeSp() / 13f;
        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                currentZoomFactor = customManager.getFontSizeSp() / 13f;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                currentZoomFactor *= detector.getScaleFactor();
                currentZoomFactor = Math.max(0.62f, Math.min(2.30f, currentZoomFactor));
                float newSizeSp = 13f * currentZoomFactor;
                customManager.setFontSizeSp(newSizeSp);
                applyFontSizeAndZoom();
                return true;
            }
        });

        terminalScroll.setOnTouchListener((v, event) -> {
            scaleGestureDetector.onTouchEvent(event);
            if (event.getPointerCount() >= 2 && scaleGestureDetector.isInProgress()) {
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP && !scaleGestureDetector.isInProgress()) {
                etCommandInput.requestFocus();
            }
            return false;
        });
    }

    private void applyFontSizeAndZoom() {
        float sizeSp = customManager.getFontSizeSp();
        tvTerminalOutput.setTextSize(sizeSp);
        tvPrompt.setTextSize(sizeSp);
        etCommandInput.setTextSize(sizeSp);
        if (tvZoomBadge != null) {
            tvZoomBadge.setText(customManager.getZoomPercent() + "%");
        }
    }

    private void applyCustomization() {
        applyFontSizeAndZoom();

        // Font Typeface
        tvTerminalOutput.setTypeface(customManager.getTypeface());
        tvPrompt.setTypeface(customManager.getTypeface());
        etCommandInput.setTypeface(customManager.getTypeface());

        // Text & Prompt Colors
        int textColor = customManager.getTextColor();
        int promptColor = customManager.getPromptColor();
        tvTerminalOutput.setTextColor(textColor);
        tvPrompt.setTextColor(promptColor);
        etCommandInput.setTextColor(textColor);

        // Background Wallpaper + Tint Overlay
        if (customManager.hasWallpaper()) {
            Bitmap bmp = customManager.loadWallpaperBitmap();
            if (bmp != null) {
                ivWallpaper.setImageBitmap(bmp);
                ivWallpaper.setVisibility(View.VISIBLE);
            } else {
                ivWallpaper.setVisibility(View.GONE);
            }
        } else {
            ivWallpaper.setImageDrawable(null);
            ivWallpaper.setVisibility(View.GONE);
        }
        vBgOverlay.setBackgroundColor(customManager.getEffectiveOverlayColor());
    }

    private void showCustomizeDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_customize, null);

        Spinner spFont = dialogView.findViewById(R.id.sp_font_style);
        SeekBar sbFontSize = dialogView.findViewById(R.id.sb_font_size);
        TextView tvZoomLabel = dialogView.findViewById(R.id.tv_zoom_label);
        Spinner spTextColor = dialogView.findViewById(R.id.sp_text_color);
        Spinner spPromptColor = dialogView.findViewById(R.id.sp_prompt_color);
        Spinner spBgTheme = dialogView.findViewById(R.id.sp_bg_theme);
        SeekBar sbDim = dialogView.findViewById(R.id.sb_bg_dim);
        TextView tvDimLabel = dialogView.findViewById(R.id.tv_dim_label);
        Button btnPickWp = dialogView.findViewById(R.id.btn_pick_wallpaper);
        Button btnClearWp = dialogView.findViewById(R.id.btn_clear_wallpaper);

        ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.FONT_LABELS);
        spFont.setAdapter(fontAdapter);
        spFont.setSelection(customManager.getFontStyleIndex());

        int initialSize = Math.round(customManager.getFontSizeSp());
        int progressVal = Math.max(0, Math.min(22, initialSize - 8));
        sbFontSize.setProgress(progressVal);
        int initZoom = Math.round(((progressVal + 8) / 13f) * 100f);
        tvZoomLabel.setText("TERMINAL ZOOM / FONT SIZE: " + (progressVal + 8) + "sp (" + initZoom + "%)");

        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.COLOR_PRESET_NAMES);
        spTextColor.setAdapter(colorAdapter);
        spPromptColor.setAdapter(colorAdapter);

        spTextColor.setSelection(findColorIndex(customManager.getTextColor(), 0));
        spPromptColor.setSelection(findColorIndex(customManager.getPromptColor(), 1));

        ArrayAdapter<String> bgAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.BG_THEME_NAMES);
        spBgTheme.setAdapter(bgAdapter);
        spBgTheme.setSelection(findBgIndex(customManager.getBgTintColor()));

        int dimVal = customManager.getBgDimPercent();
        sbDim.setProgress(dimVal);
        tvDimLabel.setText("BACKGROUND DIM / OVERLAY: " + dimVal + "%");

        spFont.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setFontStyleIndex(pos);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        sbFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int sp = progress + 8;
                int zoomPct = Math.round((sp / 13f) * 100f);
                tvZoomLabel.setText("TERMINAL ZOOM / FONT SIZE: " + sp + "sp (" + zoomPct + "%)");
                customManager.setFontSizeSp(sp);
                applyFontSizeAndZoom();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        spTextColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setTextColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spPromptColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setPromptColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spBgTheme.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setBgTintColor(CustomizationManager.BG_THEME_COLORS[pos]);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        sbDim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvDimLabel.setText("BACKGROUND DIM / OVERLAY: " + progress + "%");
                customManager.setBgDimPercent(progress);
                applyCustomization();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnPickWp.setOnClickListener(v -> pickWallpaperLauncher.launch(new String[]{"image/*"}));
        btnClearWp.setOnClickListener(v -> {
            customManager.clearWallpaper();
            sbDim.setProgress(customManager.getBgDimPercent());
            applyCustomization();
            Toast.makeText(this, "Wallpaper cleared.", Toast.LENGTH_SHORT).show();
        });

        new AlertDialog.Builder(this)
            .setTitle("Customize Terminal")
            .setView(dialogView)
            .setPositiveButton("Done", (d, w) -> applyCustomization())
            .show();
    }

    private int findColorIndex(int color, int fallback) {
        for (int i = 0; i < CustomizationManager.COLOR_PRESET_VALUES.length; i++) {
            if (CustomizationManager.COLOR_PRESET_VALUES[i] == color) return i;
        }
        return fallback;
    }

    private int findBgIndex(int color) {
        for (int i = 0; i < CustomizationManager.BG_THEME_COLORS.length; i++) {
            if (CustomizationManager.BG_THEME_COLORS[i] == color) return i;
        }
        return 0;
    }

    private void loadSession(int index) {
        currentSessionIndex = index;
        TerminalSession s = sessions.get(index);
        tvWindowTitle.setText(s.title);
        tvTerminalOutput.setText(s.history.toString());
        updatePrompt();
        scrollToBottom();
    }

    private void updatePrompt() {
        TerminalSession s = sessions.get(currentSessionIndex);
        tvPrompt.setText(":" + s.currentDir.getAbsolutePath() + " $ ");
    }

    private void appendOutput(String text) {
        TerminalSession s = sessions.get(currentSessionIndex);
        s.history.append(text);
        tvTerminalOutput.setText(s.history.toString());
        scrollToBottom();
    }

    private void scrollToBottom() {
        terminalScroll.post(() -> terminalScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void executeCommand(String cmd) {
        TerminalSession s = sessions.get(currentSessionIndex);
        appendOutput(":" + s.currentDir.getAbsolutePath() + " $ " + cmd + "\n");

        if (cmd.isEmpty()) return;

        String[] parts = cmd.split("\\s+");
        String base = parts[0].toLowerCase();

        if (base.equals("clear")) {
            s.history = new StringBuilder();
            tvTerminalOutput.setText("");
            return;
        }

        if (base.equals("customize") || base.equals("theme") || base.equals("wallpaper")) {
            runOnUiThread(this::showCustomizeDialog);
            appendOutput("Opening Terminal Customization dialog...\n");
            return;
        }

        if (base.equals("zoom")) {
            if (parts.length >= 2) {
                String action = parts[1].toLowerCase();
                if (action.equals("in") || action.equals("+")) {
                    customManager.setFontSizeSp(customManager.getFontSizeSp() + 2f);
                    applyFontSizeAndZoom();
                    appendOutput("Zoomed in -> " + customManager.getZoomPercent() + "% (" + Math.round(customManager.getFontSizeSp()) + "sp)\n");
                    return;
                } else if (action.equals("out") || action.equals("-")) {
                    customManager.setFontSizeSp(customManager.getFontSizeSp() - 2f);
                    applyFontSizeAndZoom();
                    appendOutput("Zoomed out -> " + customManager.getZoomPercent() + "% (" + Math.round(customManager.getFontSizeSp()) + "sp)\n");
                    return;
                } else if (action.equals("reset") || action.equals("100")) {
                    customManager.setFontSizeSp(13f);
                    applyFontSizeAndZoom();
                    appendOutput("Zoom reset -> 100% (13sp)\n");
                    return;
                } else {
                    try {
                        int pct = Integer.parseInt(action.replace("%", ""));
                        float sp = (pct / 100f) * 13f;
                        customManager.setFontSizeSp(sp);
                        applyFontSizeAndZoom();
                        appendOutput("Zoom set -> " + customManager.getZoomPercent() + "% (" + Math.round(customManager.getFontSizeSp()) + "sp)\n");
                        return;
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
            appendOutput("Usage: zoom [in|out|reset|<percent>]  (Or pinch with 2 fingers on terminal)\n");
            return;
        }

        if (base.equals("bin")) {
            File bDir = repoManager.getBinDir();
            File[] bFiles = bDir.listFiles();
            appendOutput("Bin directory: " + bDir.getAbsolutePath() + "\n");
            if (bFiles == null || bFiles.length == 0) {
                appendOutput("  (empty - install packages with 'pkg install <name>')\n");
            } else {
                for (File bf : bFiles) {
                    appendOutput("  " + bf.getName() + (bf.canExecute() ? " [exec]" : "") + "\n");
                }
            }
            return;
        }

        if (base.equals("help")) {
            appendOutput(
                "TermLauncher Built-in Commands:\n" +
                "  pkg update              - Sync online Termux package repository\n" +
                "  pkg search <query>      - Search Termux packages online\n" +
                "  pkg install <package>   - Download & install Termux .deb package\n" +
                "  apps                    - List all installed Android apps (with icons in drawer)\n" +
                "  launch <name>           - Open an Android app (e.g. launch chrome)\n" +
                "  zoom [in|out|reset]     - Zoom terminal text in/out (or pinch 2 fingers)\n" +
                "  customize               - Open font, color, and wallpaper customization\n" +
                "  bin                     - List binaries connected in $PREFIX/bin\n" +
                "  su / adb                - Execute su (root) or adb commands via bin\n" +
                "  cd <dir>                - Change directory (~ for app_HOME)\n" +
                "  clear                   - Clear terminal output\n"
            );
            return;
        }

        if (base.equals("cd")) {
            if (parts.length == 1 || parts[1].equals("~")) {
                s.currentDir = appHomeDir;
            } else {
                File target = parts[1].startsWith("/") ? new File(parts[1]) : new File(s.currentDir, parts[1]);
                if (target.exists() && target.isDirectory()) {
                    try {
                        s.currentDir = target.getCanonicalFile();
                    } catch (Exception e) {
                        s.currentDir = target;
                    }
                } else {
                    appendOutput("sh: cd: " + parts[1] + ": No such file or directory\n");
                }
            }
            updatePrompt();
            return;
        }

        if (base.equals("apps")) {
            for (AppItem item : allInstalledApps) {
                appendOutput("  [icon] " + item.label + " (" + item.packageName + ")\n");
            }
            return;
        }

        if (base.equals("launch") && parts.length > 1) {
            String query = cmd.substring(7).trim().toLowerCase();
            for (AppItem item : allInstalledApps) {
                if (item.label.toLowerCase().contains(query) || item.packageName.toLowerCase().contains(query)) {
                    launchAppByPackage(item.packageName);
                    appendOutput("Launching " + item.label + "...\n");
                    return;
                }
            }
            appendOutput("App not found: " + query + "\n");
            return;
        }

        if (base.equals("pkg") || base.equals("apt")) {
            if (parts.length < 2) {
                appendOutput("Usage: pkg [update|search|install] <package>\n");
                return;
            }
            String sub = parts[1];
            if (sub.equals("update")) {
                repoManager.updateRepo(new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            } else if (sub.equals("search") && parts.length >= 3) {
                repoManager.searchPackage(parts[2], new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            } else if ((sub.equals("install") || sub.equals("reinstall")) && parts.length >= 3) {
                repoManager.installPackage(parts[2], new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            }
        }

        new Thread(() -> {
            try {
                String termuxBin = repoManager.getBinDir().getAbsolutePath();
                String prefixPath = repoManager.getPrefixDir().getAbsolutePath();
                String libPath = new File(repoManager.getPrefixDir(), "lib").getAbsolutePath();
                String terminfoPath = new File(repoManager.getPrefixDir(), "share/terminfo").getAbsolutePath();

                String finalCmd = cmd;
                File candidateBin = new File(termuxBin, parts[0]);
                if (base.equals("su")) {
                    // Try real su binaries first, otherwise run wrapper in $PREFIX/bin/su
                    String extraArgs = cmd.length() > 2 ? cmd.substring(2).trim() : "";
                    finalCmd = "for s in /sbin/su /system/bin/su /system/xbin/su /vendor/bin/su /data/adb/ksu/bin/su /data/adb/ap/bin/su; do " +
                               "if [ -x \"$s\" ]; then exec \"$s\" " + extraArgs + "; fi; done; " +
                               "exec '" + termuxBin + "/su' " + extraArgs;
                } else if (base.equals("adb")) {
                    String extraArgs = cmd.length() > 3 ? cmd.substring(3).trim() : "";
                    finalCmd = "if [ -x '" + termuxBin + "/adb.bin' ]; then exec '" + termuxBin + "/adb.bin' " + extraArgs + "; " +
                               "elif [ -x /system/bin/adb ]; then exec /system/bin/adb " + extraArgs + "; " +
                               "else exec '" + termuxBin + "/adb' " + extraArgs + "; fi";
                } else if (candidateBin.exists() && candidateBin.isFile()) {
                    // If binary exists in $PREFIX/bin, execute directly or fallback via Android linker64/linker (bypasses W^X restriction on Android 10+ targetSdk 29+)
                    String extraArgs = cmd.length() > parts[0].length() ? cmd.substring(parts[0].length()).trim() : "";
                    String binAbs = candidateBin.getAbsolutePath();
                    finalCmd = "if [ -x '" + binAbs + "' ]; then '" + binAbs + "' " + extraArgs + "; " +
                               "elif [ -x /system/bin/linker64 ]; then /system/bin/linker64 '" + binAbs + "' " + extraArgs + "; " +
                               "elif [ -x /system/bin/linker ]; then /system/bin/linker '" + binAbs + "' " + extraArgs + "; " +
                               "else '" + binAbs + "' " + extraArgs + "; fi";
                }

                ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", finalCmd);
                pb.directory(s.currentDir);
                pb.redirectErrorStream(true);

                Map<String, String> env = pb.environment();
                String existingPath = env.get("PATH");
                String sysPaths = "/system/bin:/system/xbin:/sbin:/vendor/bin";
                env.put("PATH", termuxBin + ":" + (existingPath != null ? existingPath : sysPaths) + ":" + sysPaths);
                env.put("HOME", appHomeDir.getAbsolutePath());
                env.put("PREFIX", prefixPath);
                env.put("LD_LIBRARY_PATH", libPath);
                env.put("TERMINFO", terminfoPath);
                env.put("TERM", "xterm-256color");
                env.put("TMPDIR", new File(repoManager.getRootDir(), "cache").getAbsolutePath());

                Process process = pb.start();
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    final String outLine = line + "\n";
                    runOnUiThread(() -> appendOutput(outLine));
                }
                int exitCode = process.waitFor();
                if (exitCode != 0 && (base.equals("su") || base.equals("adb"))) {
                    final String hint = "[exit " + exitCode + "]\n";
                    runOnUiThread(() -> appendOutput(hint));
                }
            } catch (Exception e) {
                final String err = "sh: " + e.getMessage() + "\n";
                runOnUiThread(() -> appendOutput(err));
            }
        }).start();
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> pkgAppsList = pm.queryIntentActivities(mainIntent, 0);
        allInstalledApps.clear();
        for (ResolveInfo ri : pkgAppsList) {
            String label = ri.loadLabel(pm).toString();
            String pkg = ri.activityInfo.packageName;
            Drawable icon = ri.loadIcon(pm);
            if (!pkg.equals(getPackageName())) {
                allInstalledApps.add(new AppItem(label, pkg, icon));
            }
        }
        Collections.sort(allInstalledApps, (a, b) -> a.label.compareToIgnoreCase(b.label));

        filteredInstalledApps.clear();
        filteredInstalledApps.addAll(allInstalledApps);

        appIconAdapter = new AppIconAdapter(filteredInstalledApps);
        lvInstalledApps.setAdapter(appIconAdapter);
        lvInstalledApps.setOnItemClickListener((parent, view, position, id) -> {
            AppItem selected = filteredInstalledApps.get(position);
            drawerLayout.closeDrawer(GravityCompat.START);
            launchAppByPackage(selected.packageName);
        });
    }

    private void filterApps(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();
        filteredInstalledApps.clear();
        if (q.isEmpty()) {
            filteredInstalledApps.addAll(allInstalledApps);
        } else {
            for (AppItem item : allInstalledApps) {
                if (item.label.toLowerCase().contains(q) || item.packageName.toLowerCase().contains(q)) {
                    filteredInstalledApps.add(item);
                }
            }
        }
        if (appIconAdapter != null) {
            appIconAdapter.notifyDataSetChanged();
        }
    }

    private void launchAppByPackage(String packageName) {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            startActivity(launchIntent);
        } else {
            Toast.makeText(this, "Cannot launch " + packageName, Toast.LENGTH_SHORT).show();
        }
    }

    private void showWindowPicker() {
        String[] titles = new String[sessions.size()];
        for (int i = 0; i < sessions.size(); i++) {
            titles[i] = sessions.get(i).title;
        }
        new AlertDialog.Builder(this)
            .setTitle("Select Window")
            .setItems(titles, (dialog, which) -> loadSession(which))
            .show();
    }

    private void showMoreMenu() {
        String[] options = {
            "Customize (Font, Color, Wallpaper)",
            "Zoom In (+)",
            "Zoom Out (-)",
            "Reset Zoom (100%)",
            "Sync Termux Repo (pkg update)",
            "Android Settings",
            "Clear Terminal"
        };
        new AlertDialog.Builder(this)
            .setTitle("TermLauncher Options")
            .setItems(options, (dialog, which) -> {
                if (which == 0) showCustomizeDialog();
                else if (which == 1) executeCommand("zoom in");
                else if (which == 2) executeCommand("zoom out");
                else if (which == 3) executeCommand("zoom reset");
                else if (which == 4) executeCommand("pkg update");
                else if (which == 5) startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                else if (which == 6) executeCommand("clear");
            })
            .show();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }
}
