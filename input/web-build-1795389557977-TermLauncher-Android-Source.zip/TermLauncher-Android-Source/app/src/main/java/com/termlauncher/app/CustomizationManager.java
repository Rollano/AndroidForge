package com.termlauncher.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class CustomizationManager {

    private static final String PREFS_NAME = "termlauncher_prefs";
    private static final String KEY_FONT_STYLE = "font_style";
    private static final String KEY_FONT_SIZE_SP = "font_size_sp";
    private static final String KEY_TEXT_COLOR = "text_color";
    private static final String KEY_PROMPT_COLOR = "prompt_color";
    private static final String KEY_BG_TINT_COLOR = "bg_tint_color";
    private static final String KEY_BG_DIM_PERCENT = "bg_dim_percent";
    private static final String KEY_HAS_WALLPAPER = "has_wallpaper";

    public static final String[] FONT_LABELS = {
        "Monospace (Default)",
        "Monospace Bold",
        "Sans-Serif Monospace",
        "Serif Classic",
        "Sans-Serif Clean"
    };

    public static final String[] COLOR_PRESET_NAMES = {
        "Classic Light Grey (#E0E0E0)",
        "Matrix Hacker Green (#00FF66)",
        "Cyber Cyan (#00E5FF)",
        "Amber Retro (#FFB300)",
        "Solarized Mint (#64FFDA)",
        "Pure White (#FFFFFF)"
    };

    public static final int[] COLOR_PRESET_VALUES = {
        0xFFE0E0E0,
        0xFF00FF66,
        0xFF00E5FF,
        0xFFFFB300,
        0xFF64FFDA,
        0xFFFFFFFF
    };

    public static final String[] BG_THEME_NAMES = {
        "Pure Obsidian Black (#000000)",
        "Deep Slate Navy (#0A141D)",
        "Midnight Forest (#071A12)",
        "Dark Plum (#160B1E)",
        "Charcoal Graphite (#181B1E)"
    };

    public static final int[] BG_THEME_COLORS = {
        0xFF000000,
        0xFF0A141D,
        0xFF071A12,
        0xFF160B1E,
        0xFF181B1E
    };

    private final Context context;
    private final SharedPreferences prefs;
    private final File wallpaperFile;

    public CustomizationManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.wallpaperFile = new File(this.context.getFilesDir(), "custom_wallpaper.jpg");
    }

    public int getFontStyleIndex() {
        return prefs.getInt(KEY_FONT_STYLE, 0);
    }

    public void setFontStyleIndex(int index) {
        prefs.edit().putInt(KEY_FONT_STYLE, index).apply();
    }

    public Typeface getTypeface() {
        int idx = getFontStyleIndex();
        switch (idx) {
            case 1:
                return Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
            case 2:
                return Typeface.create("monospace", Typeface.NORMAL);
            case 3:
                return Typeface.create(Typeface.SERIF, Typeface.NORMAL);
            case 4:
                return Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
            case 0:
            default:
                return Typeface.MONOSPACE;
        }
    }

    public float getFontSizeSp() {
        return prefs.getFloat(KEY_FONT_SIZE_SP, 13f);
    }

    public void setFontSizeSp(float sizeSp) {
        float clamped = Math.max(8f, Math.min(30f, sizeSp));
        prefs.edit().putFloat(KEY_FONT_SIZE_SP, clamped).apply();
    }

    public int getZoomPercent() {
        return Math.round((getFontSizeSp() / 13f) * 100f);
    }

    public int getTextColor() {
        return prefs.getInt(KEY_TEXT_COLOR, 0xFFE0E0E0);
    }

    public void setTextColor(int color) {
        prefs.edit().putInt(KEY_TEXT_COLOR, color).apply();
    }

    public int getPromptColor() {
        return prefs.getInt(KEY_PROMPT_COLOR, 0xFF00FF66);
    }

    public void setPromptColor(int color) {
        prefs.edit().putInt(KEY_PROMPT_COLOR, color).apply();
    }

    public int getBgTintColor() {
        return prefs.getInt(KEY_BG_TINT_COLOR, 0xFF000000);
    }

    public void setBgTintColor(int color) {
        prefs.edit().putInt(KEY_BG_TINT_COLOR, color).apply();
    }

    public int getBgDimPercent() {
        return prefs.getInt(KEY_BG_DIM_PERCENT, hasWallpaper() ? 65 : 100);
    }

    public void setBgDimPercent(int percent) {
        int clamped = Math.max(0, Math.min(100, percent));
        prefs.edit().putInt(KEY_BG_DIM_PERCENT, clamped).apply();
    }

    public int getEffectiveOverlayColor() {
        int base = getBgTintColor();
        int alpha = Math.round((getBgDimPercent() / 100f) * 255f);
        return Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base));
    }

    public boolean hasWallpaper() {
        return prefs.getBoolean(KEY_HAS_WALLPAPER, false) && wallpaperFile.exists();
    }

    public Bitmap loadWallpaperBitmap() {
        if (!hasWallpaper()) return null;
        return BitmapFactory.decodeFile(wallpaperFile.getAbsolutePath());
    }

    public boolean saveWallpaperFromUri(Uri uri) {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) return false;
            Bitmap decoded = BitmapFactory.decodeStream(in);
            if (decoded == null) return false;

            // Downscale if huge to keep memory lightweight
            int maxDim = 1920;
            int w = decoded.getWidth();
            int h = decoded.getHeight();
            if (w > maxDim || h > maxDim) {
                float scale = Math.min((float) maxDim / w, (float) maxDim / h);
                decoded = Bitmap.createScaledBitmap(decoded, Math.round(w * scale), Math.round(h * scale), true);
            }

            try (FileOutputStream out = new FileOutputStream(wallpaperFile)) {
                decoded.compress(Bitmap.CompressFormat.JPEG, 88, out);
            }
            prefs.edit()
                .putBoolean(KEY_HAS_WALLPAPER, true)
                .putInt(KEY_BG_DIM_PERCENT, Math.min(getBgDimPercent(), 60))
                .apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void clearWallpaper() {
        if (wallpaperFile.exists()) {
            wallpaperFile.delete();
        }
        prefs.edit()
            .putBoolean(KEY_HAS_WALLPAPER, false)
            .putInt(KEY_BG_DIM_PERCENT, 100)
            .apply();
    }
}
