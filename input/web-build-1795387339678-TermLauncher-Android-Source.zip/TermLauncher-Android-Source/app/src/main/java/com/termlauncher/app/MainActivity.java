package com.termlauncher.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private TextView tvWindowTitle;
    private TextView tvTerminalOutput;
    private TextView tvPrompt;
    private EditText etCommandInput;
    private ScrollView terminalScroll;
    private ListView lvInstalledApps;

    private final List<TerminalSession> sessions = new ArrayList<>();
    private int currentSessionIndex = 0;

    private File appHomeDir;
    private TermuxRepoManager repoManager;

    private final List<AppItem> installedApps = new ArrayList<>();

    public static class AppItem {
        public String label;
        public String packageName;

        public AppItem(String label, String packageName) {
            this.label = label;
            this.packageName = packageName;
        }

        @Override
        public String toString() {
            return label + "  [" + packageName + "]";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.drawer_layout);
        tvWindowTitle = findViewById(R.id.tv_window_title);
        tvTerminalOutput = findViewById(R.id.tv_terminal_output);
        tvPrompt = findViewById(R.id.tv_prompt);
        etCommandInput = findViewById(R.id.et_command_input);
        terminalScroll = findViewById(R.id.terminal_scroll);
        lvInstalledApps = findViewById(R.id.lv_installed_apps);

        // Setup app_HOME directory matching the screenshot path style
        appHomeDir = getDir("HOME", MODE_PRIVATE);
        repoManager = new TermuxRepoManager(getFilesDir());

        // Create initial Window 1
        sessions.add(new TerminalSession("Window 1", appHomeDir));
        loadSession(0);

        // Toolbar buttons
        ImageButton btnMenu = findViewById(R.id.btn_menu);
        btnMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        LinearLayout windowSelector = findViewById(R.id.window_selector);
        windowSelector.setOnClickListener(v -> showWindowPicker());

        ImageButton btnNewWindow = findViewById(R.id.btn_new_window);
        btnNewWindow.setOnClickListener(v -> {
            int num = sessions.size() + 1;
            sessions.add(new TerminalSession("Window " + num, appHomeDir));
            loadSession(sessions.size() - 1);
        });

        ImageButton btnCloseWindow = findViewById(R.id.btn_close_window);
        btnCloseWindow.setOnClickListener(v -> {
            if (sessions.size() > 1) {
                sessions.remove(currentSessionIndex);
                currentSessionIndex = Math.max(0, currentSessionIndex - 1);
                loadSession(currentSessionIndex);
            } else {
                // Clear current session
                sessions.get(0).history = new StringBuilder(":/ $ cd ~\n");
                loadSession(0);
            }
        });

        ImageButton btnMore = findViewById(R.id.btn_more);
        btnMore.setOnClickListener(v -> showMoreMenu());

        // Handle Enter key on Keyboard
        etCommandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                String cmd = etCommandInput.getText().toString().trim();
                etCommandInput.setText("");
                executeCommand(cmd);
                return true;
            }
            return false;
        });

        // Focus input when tapping anywhere on black terminal
        terminalScroll.setOnClickListener(v -> etCommandInput.requestFocus());

        loadInstalledApps();
    }

    private void loadSession(int index) {
        currentSessionIndex = index;
        TerminalSession s = sessions.get(index);
        tvWindowTitle.setText(s.title);
        tvTerminalOutput.setText(s.history.toString());
        updatePrompt();
        scrollToBottom();
    }

    private void updatePrompt() {
        TerminalSession s = sessions.get(currentSessionIndex);
        tvPrompt.setText(":" + s.currentDir.getAbsolutePath() + " $ ");
    }

    private void appendOutput(String text) {
        TerminalSession s = sessions.get(currentSessionIndex);
        s.history.append(text);
        tvTerminalOutput.setText(s.history.toString());
        scrollToBottom();
    }

    private void scrollToBottom() {
        terminalScroll.post(() -> terminalScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void executeCommand(String cmd) {
        TerminalSession s = sessions.get(currentSessionIndex);
        appendOutput(":" + s.currentDir.getAbsolutePath() + " $ " + cmd + "\n");

        if (cmd.isEmpty()) return;

        String[] parts = cmd.split("\\s+");
        String base = parts[0];

        if (base.equals("clear")) {
            s.history = new StringBuilder();
            tvTerminalOutput.setText("");
            return;
        }

        if (base.equals("help")) {
            appendOutput(
                "TermLauncher Built-in Commands:\n" +
                "  pkg update              - Sync online Termux package repository\n" +
                "  pkg search <query>      - Search Termux packages online\n" +
                "  pkg install <package>   - Download & install Termux .deb package\n" +
                "  apps                    - List all installed Android apps\n" +
                "  launch <name>           - Open an Android app (e.g. launch chrome)\n" +
                "  cd <dir>                - Change directory (~ for app_HOME)\n" +
                "  clear                   - Clear terminal output\n" +
                "  (Plus any standard Android shell / installed Termux binary)\n"
            );
            return;
        }

        if (base.equals("cd")) {
            if (parts.length == 1 || parts[1].equals("~")) {
                s.currentDir = appHomeDir;
            } else {
                File target = parts[1].startsWith("/") ? new File(parts[1]) : new File(s.currentDir, parts[1]);
                if (target.exists() && target.isDirectory()) {
                    try {
                        s.currentDir = target.getCanonicalFile();
                    } catch (Exception e) {
                        s.currentDir = target;
                    }
                } else {
                    appendOutput("sh: cd: " + parts[1] + ": No such file or directory\n");
                }
            }
            updatePrompt();
            return;
        }

        // Home Launcher Commands: apps & launch
        if (base.equals("apps")) {
            for (AppItem item : installedApps) {
                appendOutput("  " + item.label + " (" + item.packageName + ")\n");
            }
            return;
        }

        if (base.equals("launch") && parts.length > 1) {
            String query = cmd.substring(7).trim().toLowerCase();
            for (AppItem item : installedApps) {
                if (item.label.toLowerCase().contains(query) || item.packageName.toLowerCase().contains(query)) {
                    launchAppByPackage(item.packageName);
                    appendOutput("Launching " + item.label + "...\n");
                    return;
                }
            }
            appendOutput("App not found: " + query + "\n");
            return;
        }

        // Termux Repository Commands: pkg / apt
        if (base.equals("pkg") || base.equals("apt")) {
            if (parts.length < 2) {
                appendOutput("Usage: pkg [update|search|install] <package>\n");
                return;
            }
            String sub = parts[1];
            if (sub.equals("update")) {
                repoManager.updateRepo(new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            } else if (sub.equals("search") && parts.length >= 3) {
                repoManager.searchPackage(parts[2], new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            } else if (sub.equals("install") && parts.length >= 3) {
                repoManager.installPackage(parts[2], new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            }
        }

        // Execute Native Shell Command (with Termux bin directory injected into PATH)
        new Thread(() -> {
            try {
                ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", cmd);
                pb.directory(s.currentDir);
                pb.redirectErrorStream(true);

                Map<String, String> env = pb.environment();
                String existingPath = env.get("PATH");
                String termuxBin = repoManager.getBinDir().getAbsolutePath();
                env.put("PATH", termuxBin + ":" + (existingPath != null ? existingPath : "/system/bin:/system/xbin"));
                env.put("HOME", appHomeDir.getAbsolutePath());
                env.put("PREFIX", repoManager.getPrefixDir().getAbsolutePath());
                env.put("LD_LIBRARY_PATH", new File(repoManager.getPrefixDir(), "lib").getAbsolutePath());

                Process process = pb.start();
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    final String outLine = line + "\n";
                    runOnUiThread(() -> appendOutput(outLine));
                }
                process.waitFor();
            } catch (Exception e) {
                final String err = "sh: " + e.getMessage() + "\n";
                runOnUiThread(() -> appendOutput(err));
            }
        }).start();
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> pkgAppsList = pm.queryIntentActivities(mainIntent, 0);
        installedApps.clear();
        for (ResolveInfo ri : pkgAppsList) {
            String label = ri.loadLabel(pm).toString();
            String pkg = ri.activityInfo.packageName;
            if (!pkg.equals(getPackageName())) {
                installedApps.add(new AppItem(label, pkg));
            }
        }
        Collections.sort(installedApps, (a, b) -> a.label.compareToIgnoreCase(b.label));

        ArrayAdapter<AppItem> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, installedApps);
        lvInstalledApps.setAdapter(adapter);
        lvInstalledApps.setOnItemClickListener((parent, view, position, id) -> {
            AppItem selected = installedApps.get(position);
            drawerLayout.closeDrawer(GravityCompat.START);
            launchAppByPackage(selected.packageName);
        });
    }

    private void launchAppByPackage(String packageName) {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            startActivity(launchIntent);
        } else {
            Toast.makeText(this, "Cannot launch " + packageName, Toast.LENGTH_SHORT).show();
        }
    }

    private void showWindowPicker() {
        String[] titles = new String[sessions.size()];
        for (int i = 0; i < sessions.size(); i++) {
            titles[i] = sessions.get(i).title;
        }
        new AlertDialog.Builder(this)
            .setTitle("Select Window")
            .setItems(titles, (dialog, which) -> loadSession(which))
            .show();
    }

    private void showMoreMenu() {
        String[] options = {"Sync Termux Repo (pkg update)", "List Installed Apps (apps)", "Android Settings", "Clear Terminal"};
        new AlertDialog.Builder(this)
            .setTitle("TermLauncher Options")
            .setItems(options, (dialog, which) -> {
                if (which == 0) executeCommand("pkg update");
                else if (which == 1) executeCommand("apps");
                else if (which == 2) startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                else if (which == 3) executeCommand("clear");
            })
            .show();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        // Do nothing on back press because this is a Home Launcher!
    }
}
