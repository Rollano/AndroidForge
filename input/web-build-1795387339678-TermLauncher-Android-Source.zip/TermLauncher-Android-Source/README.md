# TermLauncher (Android Terminal Emulator & Home Launcher)

Isang Android Home Launcher na may built-in Terminal Emulator (hawig sa TermOnePlus UI) at konektado sa online **Termux Repository** (`packages-cf.termux.dev`).

## Paano i-build bilang APK (Gamit ang Android Studio o AIDE):
1. I-extract ang `TermLauncher-Android-Source.zip`.
2. Buksan ang folder sa **Android Studio** (o **AndroidIDE** sa Android phone).
3. Hintayin matapos ang Gradle sync, pagkatapos ay i-click ang **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. I-install ang nabuong `app-debug.apk` at piliin ang **TermLauncher** bilang default Home App ng iyong phone.

## Mga Built-in Commands sa Terminal:
- `pkg update` — Kokonekta online sa Termux repository para kunin ang listahan ng mga packages (`aarch64` / `arm` / `x86_64`).
- `pkg search <pangalan>` — Maghanap ng available na package sa Termux repo.
- `pkg install <package>` — Mag-download at mag-extract ng `.deb` package mula sa Termux online repo diretso sa `usr/bin` ng app.
- `apps` — Ipakita ang lahat ng naka-install na Android apps.
- `launch <app>` — Magbukas ng app gamit ang terminal (halimbawa: `launch settings`, `launch chrome`).
- Maaari ring mag-swipe mula sa kaliwang gilid (o pindutin ang `≡` menu icon) para lumabas ang App Drawer.
