# termux-vision (v29 — Fix Soft Keyboard Not Showing)

- Changes `MainActivity` `windowSoftInputMode` in `AndroidManifest.xml` from `stateHidden` to `adjustResize|stateVisible`.
- Triggers `focusTerminalInput()` on `onWindowFocusChanged(true)` and adds a one-tap `KB` button (`forceOpenKeyboard()`) in the prompt bar so the soft keyboard reliably opens on Android devices.
