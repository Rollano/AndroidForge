package com.example.nhterminallauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LauncherTerminalActivity extends Activity {

    private static final String PREFS_NAME = "nh_launcher_prefs";
    private static final int REQ_STORAGE_PERMS = 204;

    private static class AppEntry {
        final String label;
        final String packageName;
        final Drawable icon;

        AppEntry(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final List<String> history = new ArrayList<>();
    private final List<AppEntry> installedApps = new ArrayList<>();
    private final List<File> audioPlaylist = new ArrayList<>();
    private final SpannableStringBuilder terminalLog = new SpannableStringBuilder();

    private SharedPreferences prefs;
    private MediaPlayer mediaPlayer;
    private int currentTrackIndex = -1;

    private String username = "termux";
    private File currentDir = new File("/");
    private boolean suMode = false;
    private boolean ctrlActive = false;
    private boolean altActive = false;
    private boolean cursorVisible = true;
    private boolean updatingInput = false;
    private int historyIndex = -1;

    private FrameLayout rootFrame;
    private LinearLayout mainColumn;
    private ScrollView logScroll;
    private TextView logOutput;
    private EditText commandInput;
    private Button ctrlBtn;
    private Button altBtn;

    private final Runnable cursorRunnable = new Runnable() {
        @Override
        public void run() {
            cursorVisible = !cursorVisible;
            renderCurrentLine();
            mainHandler.postDelayed(this, 530L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        username = prefs.getString("prompt_user", "termux");
        currentDir = new File("/");

        buildLayout();
        loadInstalledAppsAsync();

        appendBanner();
        renderCurrentLine();
        animateLaunch();

        mainHandler.postDelayed(cursorRunnable, 530L);
        focusInputAndShowKeyboard();
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderCurrentLine();
        focusInputAndShowKeyboard();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            focusInputAndShowKeyboard();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE_PERMS) {
            linkStorageDirectories();
        }
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacks(cursorRunnable);
        mainHandler.removeCallbacksAndMessages(null);
        stopMusicPlayer();
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (suMode) {
            suMode = false;
            appendPlain("[Exited root shell]\n");
            renderCurrentLine();
            return;
        }
        focusInputAndShowKeyboard();
    }

    private void appendBanner() {
        appendColored("Welcome to Termux Launcher!\n\n", 0xFFD1D5DB);
        appendColored("Commands:\n", 0xFF9CA3AF);
        appendColored(" - setup-storage : request storage & link folders\n", 0xFFD1D5DB);
        appendColored(" - play music    : play audio [next | stop | <name>]\n", 0xFFD1D5DB);
        appendColored(" - apps / open   : list or launch Android apps\n", 0xFFD1D5DB);
        appendColored(" - su / adb      : root shell & ADB commands\n", 0xFFD1D5DB);
        appendColored(" - clear / help  : clear screen or show help\n\n", 0xFFD1D5DB);
        appendColored("Type 'help' for full command list.\n", 0xFF9CA3AF);
    }

    private void buildLayout() {
        rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(0xFF000000);

        mainColumn = new LinearLayout(this);
        mainColumn.setOrientation(LinearLayout.VERTICAL);
        mainColumn.setBackgroundColor(0xFF000000);

        // Full-black terminal viewport matching 424.png (no top bar clutter)
        logScroll = new ScrollView(this);
        logScroll.setFillViewport(true);
        logScroll.setBackgroundColor(0xFF000000);
        logScroll.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                focusInputAndShowKeyboard();
            }
            return false;
        });

        LinearLayout innerScroll = new LinearLayout(this);
        innerScroll.setOrientation(LinearLayout.VERTICAL);
        innerScroll.setBackgroundColor(0xFF000000);
        innerScroll.setPadding(dp(6), dp(6), dp(6), dp(8));

        logOutput = new TextView(this);
        logOutput.setTextColor(0xFFD1D5DB);
        logOutput.setTextSize(13.5f);
        logOutput.setTypeface(Typeface.MONOSPACE);
        logOutput.setLineSpacing(0f, 1.15f);
        logOutput.setBackgroundColor(0xFF000000);
        logOutput.setOnClickListener(v -> focusInputAndShowKeyboard());
        innerScroll.addView(logOutput, new LinearLayout.LayoutParams(-1, -2));

        // Transparent/black EditText right below output so typed characters & soft keyboard work seamlessly
        commandInput = new EditText(this);
        commandInput.setSingleLine(false);
        commandInput.setBackgroundColor(0xFF000000);
        commandInput.setPadding(dp(2), dp(2), dp(2), dp(2));
        commandInput.setTextColor(0xFFD1D5DB);
        commandInput.setHintTextColor(0xFF4B5563);
        commandInput.setTextSize(13.5f);
        commandInput.setTypeface(Typeface.MONOSPACE);
        commandInput.setFocusable(true);
        commandInput.setFocusableInTouchMode(true);
        commandInput.setClickable(true);
        commandInput.setEnabled(true);
        commandInput.setCursorVisible(false);
        commandInput.setImeOptions(EditorInfo.IME_ACTION_SEND | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        commandInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        commandInput.setOnClickListener(v -> focusInputAndShowKeyboard());
        commandInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!updatingInput) {
                    renderCurrentLine();
                }
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
        commandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                submitCommand();
                return true;
            }
            return false;
        });
        commandInput.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    submitCommand();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_UP && !history.isEmpty()) {
                    if (historyIndex < 0) historyIndex = history.size() - 1;
                    else if (historyIndex > 0) historyIndex--;
                    setInputText(history.get(historyIndex));
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN && !history.isEmpty()) {
                    if (historyIndex >= 0 && historyIndex < history.size() - 1) {
                        historyIndex++;
                        setInputText(history.get(historyIndex));
                    } else {
                        historyIndex = -1;
                        setInputText("");
                    }
                    return true;
                }
            }
            return false;
        });
        innerScroll.addView(commandInput, new LinearLayout.LayoutParams(-1, dp(140)));

        logScroll.addView(innerScroll, new ScrollView.LayoutParams(-1, -2));
        mainColumn.addView(logScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // 2-Row Termux Extra Keys Bar matching 424.png:
        // Row 1: ESC  /  -  HOME  ↑  END  PGUP
        // Row 2: ⇥  CTRL  ALT  ←  ↓  →  PGDN
        mainColumn.addView(buildTermuxExtraKeysBar(), new LinearLayout.LayoutParams(-1, -2));

        rootFrame.addView(mainColumn, new FrameLayout.LayoutParams(-1, -1));
        setContentView(rootFrame);
    }

    private View buildTermuxExtraKeysBar() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF000000);
        panel.setPadding(dp(4), dp(2), dp(4), dp(4));

        HorizontalScrollView row1Scroll = new HorizontalScrollView(this);
        row1Scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        for (final String k : new String[]{"ESC", "/", "-", "HOME", "↑", "END", "PGUP"}) {
            Button b = createTermuxKeyBtn(k);
            b.setOnClickListener(v -> {
                animatePress(v);
                onExtraKey(k);
            });
            row1.addView(b);
        }
        row1Scroll.addView(row1);

        HorizontalScrollView row2Scroll = new HorizontalScrollView(this);
        row2Scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(-1, -2);
        r2lp.topMargin = dp(2);

        Button tabBtn = createTermuxKeyBtn("⇥");
        tabBtn.setOnClickListener(v -> {
            animatePress(v);
            onExtraKey("TAB");
        });
        row2.addView(tabBtn);

        ctrlBtn = createTermuxKeyBtn("CTRL");
        ctrlBtn.setOnClickListener(v -> {
            animatePress(v);
            ctrlActive = !ctrlActive;
            updateModifierStyles();
        });
        row2.addView(ctrlBtn);

        altBtn = createTermuxKeyBtn("ALT");
        altBtn.setOnClickListener(v -> {
            animatePress(v);
            altActive = !altActive;
            updateModifierStyles();
        });
        row2.addView(altBtn);

        for (final String k : new String[]{"←", "↓", "→", "PGDN"}) {
            Button b = createTermuxKeyBtn(k);
            b.setOnClickListener(v -> {
                animatePress(v);
                onExtraKey(k);
            });
            row2.addView(b);
        }
        row2Scroll.addView(row2);

        panel.addView(row1Scroll, new LinearLayout.LayoutParams(-1, -2));
        panel.addView(row2Scroll, r2lp);
        return panel;
    }

    private void onExtraKey(String key) {
        if ("ESC".equals(key)) {
            if (ctrlActive) {
                appendColored("^C\n", 0xFFF87171);
                ctrlActive = false;
                updateModifierStyles();
            }
            setInputText("");
            return;
        }
        if ("/".equals(key)) {
            insertAtCursor("/");
            return;
        }
        if ("-".equals(key)) {
            insertAtCursor("-");
            return;
        }
        if ("TAB".equals(key)) {
            insertAtCursor("  ");
            return;
        }
        if ("HOME".equals(key) && commandInput != null) {
            commandInput.setSelection(0);
            renderCurrentLine();
            return;
        }
        if ("END".equals(key) && commandInput != null) {
            commandInput.setSelection(commandInput.getText().length());
            renderCurrentLine();
            return;
        }
        if ("←".equals(key) && commandInput != null) {
            int pos = Math.max(0, commandInput.getSelectionStart() - 1);
            commandInput.setSelection(pos);
            renderCurrentLine();
            return;
        }
        if ("→".equals(key) && commandInput != null) {
            int pos = Math.min(commandInput.getText().length(), commandInput.getSelectionEnd() + 1);
            commandInput.setSelection(pos);
            renderCurrentLine();
            return;
        }
        if ("↑".equals(key)) {
            if (!history.isEmpty()) {
                if (historyIndex < 0) historyIndex = history.size() - 1;
                else if (historyIndex > 0) historyIndex--;
                setInputText(history.get(historyIndex));
            }
            return;
        }
        if ("↓".equals(key)) {
            if (!history.isEmpty() && historyIndex >= 0 && historyIndex < history.size() - 1) {
                historyIndex++;
                setInputText(history.get(historyIndex));
            } else {
                historyIndex = -1;
                setInputText("");
            }
            return;
        }
        if ("PGUP".equals(key) && logScroll != null) {
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_UP));
            return;
        }
        if ("PGDN".equals(key) && logScroll != null) {
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void updateModifierStyles() {
        if (ctrlBtn != null) {
            ctrlBtn.setTextColor(ctrlActive ? 0xFF4ADE80 : 0xFFE5E7EB);
        }
        if (altBtn != null) {
            altBtn.setTextColor(altActive ? 0xFF4ADE80 : 0xFFE5E7EB);
        }
    }

    private void setInputText(String txt) {
        if (commandInput == null) return;
        updatingInput = true;
        commandInput.setText(txt);
        commandInput.setSelection(commandInput.getText().length());
        updatingInput = false;
        renderCurrentLine();
        focusInputAndShowKeyboard();
    }

    private void insertAtCursor(String snippet) {
        if (commandInput == null) return;
        int start = Math.max(0, commandInput.getSelectionStart());
        int end = Math.max(start, commandInput.getSelectionEnd());
        updatingInput = true;
        commandInput.getText().replace(start, end, snippet);
        updatingInput = false;
        renderCurrentLine();
        focusInputAndShowKeyboard();
    }

    private void renderCurrentLine() {
        if (logOutput == null) return;
        String typed = commandInput != null ? commandInput.getText().toString() : "";
        String dirDisplay = formatShortDir(currentDir);
        String sigil = suMode ? "# " : "$ ";

        SpannableStringBuilder full = new SpannableStringBuilder(terminalLog);
        int lineStart = full.length();
        full.append(dirDisplay).append(" ");
        full.setSpan(new ForegroundColorSpan(0xFF60A5FA), lineStart, full.length() - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        int sigStart = full.length();
        full.append(sigil);
        full.setSpan(new ForegroundColorSpan(suMode ? 0xFFF87171 : 0xFF4ADE80), sigStart, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        int cmdStart = full.length();
        full.append(typed);
        full.setSpan(new ForegroundColorSpan(0xFFE5E7EB), cmdStart, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        if (cursorVisible) {
            int curStart = full.length();
            full.append("█");
            full.setSpan(new ForegroundColorSpan(0xFFE5E7EB), curStart, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        logOutput.setText(full);
        if (logScroll != null) {
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private String formatShortDir(File dir) {
        if (dir == null) return "/";
        String abs = dir.getAbsolutePath();
        if ("/".equals(abs)) return "/";
        File ext = Environment.getExternalStorageDirectory();
        if (ext != null && abs.equals(ext.getAbsolutePath())) {
            return "~";
        }
        String name = dir.getName();
        return TextUtils.isEmpty(name) ? abs : name;
    }

    private void submitCommand() {
        if (commandInput == null) return;
        String raw = commandInput.getText().toString().trim();
        setInputText("");
        historyIndex = -1;

        String dirDisplay = formatShortDir(currentDir);
        String sigil = suMode ? "# " : "$ ";
        int pStart = terminalLog.length();
        terminalLog.append(dirDisplay).append(" ");
        terminalLog.setSpan(new ForegroundColorSpan(0xFF60A5FA), pStart, terminalLog.length() - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int sStart = terminalLog.length();
        terminalLog.append(sigil);
        terminalLog.setSpan(new ForegroundColorSpan(suMode ? 0xFFF87171 : 0xFF4ADE80), sStart, terminalLog.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        terminalLog.append(raw).append("\n");

        if (raw.isEmpty()) {
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        history.add(raw);
        if (ctrlActive) {
            ctrlActive = false;
            updateModifierStyles();
        }

        String lower = raw.toLowerCase(Locale.ROOT);

        if ("clear".equals(lower)) {
            terminalLog.clear();
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if ("help".equals(lower)) {
            appendColored(
                "setup-storage          Request storage & prepare folders\n" +
                "play music             Scan & play music (next / stop / <name>)\n" +
                "apps / open <app>      List or launch installed Android apps\n" +
                "pwd / ls / cd          Filesystem navigation\n" +
                "su / su <cmd>          Root shell (type 'exit' to leave)\n" +
                "adb <cmd>              Root-mapped ADB commands\n" +
                "clear                  Clear screen\n",
                0xFFD1D5DB
            );
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if ("setup-storage".equals(lower)) {
            runSetupStorage();
            return;
        }

        if ("play music".equals(lower) || lower.startsWith("play music ")) {
            String arg = lower.length() > 10 ? raw.substring(10).trim() : "";
            handlePlayMusicCommand(arg);
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if ("apps".equals(lower)) {
            showAppDrawerDialog();
            return;
        }

        if (lower.startsWith("open ")) {
            launchAppByQuery(raw.substring(5).trim());
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if (lower.startsWith("user ")) {
            String nextUser = raw.substring(5).trim().replaceAll("[^a-zA-Z0-9_-]", "");
            if (!nextUser.isEmpty()) {
                username = nextUser;
                prefs.edit().putString("prompt_user", username).apply();
                appendColored("[user: " + username + "]\n", 0xFF9CA3AF);
            }
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if ("pwd".equals(lower)) {
            appendColored(currentDir.getAbsolutePath() + "\n", 0xFFD1D5DB);
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if ("ls".equals(lower) || lower.startsWith("ls ")) {
            String targetPath = raw.length() > 2 ? raw.substring(2).trim() : "";
            File dir = targetPath.isEmpty() ? currentDir : resolveFile(targetPath);
            File[] files = dir.listFiles();
            if (files == null || files.length == 0) {
                appendColored("[empty or inaccessible: " + dir.getAbsolutePath() + "]\n", 0xFF9CA3AF);
            } else {
                for (File f : files) {
                    if (f.isDirectory()) {
                        appendColored(f.getName() + "/  ", 0xFF60A5FA);
                    } else {
                        appendColored(f.getName() + "  ", 0xFFD1D5DB);
                    }
                }
                appendPlain("\n");
            }
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if (lower.startsWith("cd ")) {
            File next = resolveFile(raw.substring(3).trim());
            if (next.exists() && next.isDirectory()) {
                currentDir = next;
                appendColored(currentDir.getAbsolutePath() + "\n", 0xFFD1D5DB);
            } else {
                appendColored("cd: no such directory: " + next.getAbsolutePath() + "\n", 0xFFF87171);
            }
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if (suMode && "exit".equals(lower)) {
            suMode = false;
            appendColored("[exited root shell]\n", 0xFF9CA3AF);
            renderCurrentLine();
            focusInputAndShowKeyboard();
            return;
        }

        if ("su".equals(lower)) {
            suMode = true;
            runRootShell("id");
            return;
        }

        if (lower.startsWith("su ")) {
            String rootCmd = raw.substring(3).trim();
            if (rootCmd.startsWith("-c ")) {
                rootCmd = rootCmd.substring(3).trim();
            }
            runRootShell(mapAdbToRootCmd(rootCmd));
            return;
        }

        if (suMode) {
            runRootShell(mapAdbToRootCmd(raw));
            return;
        }

        if (lower.startsWith("adb ")) {
            runRootShell(mapAdbToRootCmd(raw));
            return;
        }

        runNormalShell(raw);
    }

    private void runSetupStorage() {
        appendColored("[setup-storage] Checking storage permissions...\n", 0xFF9CA3AF);
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception ignored) { }
        }
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> needed = new ArrayList<>();
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                needed.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                needed.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(android.Manifest.permission.READ_MEDIA_AUDIO);
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), REQ_STORAGE_PERMS);
                renderCurrentLine();
                return;
            }
        }
        linkStorageDirectories();
    }

    private void linkStorageDirectories() {
        File ext = Environment.getExternalStorageDirectory();
        if (ext != null && ext.exists()) {
            currentDir = ext;
        }
        appendColored("[setup-storage] Storage ready: " + (ext != null ? ext.getAbsolutePath() : "/") + "\n", 0xFF4ADE80);
        appendColored("  shared   -> /sdcard\n", 0xFFD1D5DB);
        appendColored("  music    -> /sdcard/Music\n", 0xFFD1D5DB);
        appendColored("  download -> /sdcard/Download\n", 0xFFD1D5DB);
        renderCurrentLine();
        focusInputAndShowKeyboard();
    }

    private void handlePlayMusicCommand(String arg) {
        String sub = arg.trim().toLowerCase(Locale.ROOT);
        if ("stop".equals(sub)) {
            stopMusicPlayer();
            appendColored("[music stopped]\n", 0xFF9CA3AF);
            return;
        }
        if ("next".equals(sub)) {
            if (audioPlaylist.isEmpty()) scanMusicFiles();
            if (audioPlaylist.isEmpty()) {
                appendColored("[no music files found]\n", 0xFF9CA3AF);
                return;
            }
            currentTrackIndex = (currentTrackIndex + 1) % audioPlaylist.size();
            playAudioFile(audioPlaylist.get(currentTrackIndex));
            return;
        }

        if (audioPlaylist.isEmpty()) scanMusicFiles();
        if (audioPlaylist.isEmpty()) {
            appendColored("[no music files found (.mp3, .m4a, .wav, .ogg, .flac)]\n", 0xFF9CA3AF);
            return;
        }

        if (!TextUtils.isEmpty(sub)) {
            for (int i = 0; i < audioPlaylist.size(); i++) {
                if (audioPlaylist.get(i).getName().toLowerCase(Locale.ROOT).contains(sub)) {
                    currentTrackIndex = i;
                    playAudioFile(audioPlaylist.get(i));
                    return;
                }
            }
        }

        if (currentTrackIndex < 0 || currentTrackIndex >= audioPlaylist.size()) {
            currentTrackIndex = 0;
        }
        playAudioFile(audioPlaylist.get(currentTrackIndex));
    }

    private void scanMusicFiles() {
        audioPlaylist.clear();
        File ext = Environment.getExternalStorageDirectory();
        if (ext == null || !ext.exists()) return;
        File[] roots = {
            new File(ext, "Music"),
            new File(ext, "Download"),
            ext
        };
        for (File dir : roots) {
            if (dir.exists() && dir.isDirectory()) {
                collectAudioRecursive(dir, 0, 2);
            }
            if (!audioPlaylist.isEmpty()) break;
        }
    }

    private void collectAudioRecursive(File dir, int depth, int maxDepth) {
        if (depth > maxDepth || audioPlaylist.size() >= 60) return;
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (f.isDirectory()) {
                collectAudioRecursive(f, depth + 1, maxDepth);
            } else if (f.isFile()) {
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (n.endsWith(".mp3") || n.endsWith(".m4a") || n.endsWith(".wav") || n.endsWith(".ogg") || n.endsWith(".flac")) {
                    if (!audioPlaylist.contains(f)) {
                        audioPlaylist.add(f);
                    }
                }
            }
        }
    }

    private void playAudioFile(File file) {
        stopMusicPlayer();
        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(file.getAbsolutePath());
            mediaPlayer.setOnCompletionListener(mp -> {
                if (!audioPlaylist.isEmpty()) {
                    currentTrackIndex = (currentTrackIndex + 1) % audioPlaylist.size();
                    playAudioFile(audioPlaylist.get(currentTrackIndex));
                }
            });
            mediaPlayer.prepare();
            mediaPlayer.start();
            appendColored("[playing (" + (currentTrackIndex + 1) + "/" + audioPlaylist.size() + ")]: " + file.getName() + "\n", 0xFF4ADE80);
        } catch (Exception e) {
            appendColored("[play music error]: " + e.getMessage() + "\n", 0xFFF87171);
        }
    }

    private void stopMusicPlayer() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception ignored) { }
            mediaPlayer = null;
        }
    }

    private File resolveFile(String pathArg) {
        if (pathArg == null || pathArg.trim().isEmpty() || "~".equals(pathArg.trim())) {
            File ext = Environment.getExternalStorageDirectory();
            return ext != null ? ext : new File("/");
        }
        String p = pathArg.trim();
        File candidate = p.startsWith("/") ? new File(p) : new File(currentDir, p);
        try {
            return candidate.getCanonicalFile();
        } catch (Exception ignored) {
            return candidate;
        }
    }

    private String mapAdbToRootCmd(String raw) {
        String cmd = raw == null ? "" : raw.trim();
        if (!cmd.toLowerCase(Locale.ROOT).startsWith("adb")) return cmd;
        String rest = cmd.length() > 3 ? cmd.substring(3).trim() : "";
        String lower = rest.toLowerCase(Locale.ROOT);
        if (lower.isEmpty() || lower.equals("devices")) {
            return "echo 'List of devices attached'; echo 'local-device\tdevice (root-su)'";
        }
        if (lower.equals("root")) {
            return "setprop service.adb.tcp.port 5555; stop adbd; start adbd; id";
        }
        if (lower.startsWith("tcpip ")) {
            String port = rest.substring(6).trim();
            if (port.isEmpty()) port = "5555";
            return "setprop service.adb.tcp.port " + port + "; stop adbd; start adbd";
        }
        if (lower.equals("shell")) {
            return "id";
        }
        if (lower.startsWith("shell ")) {
            return rest.substring(6).trim();
        }
        if (lower.startsWith("install ")) {
            String apk = rest.substring(8).trim().replaceFirst("^-[rtdg]+\s+", "");
            return "pm install -r " + apk;
        }
        if (lower.startsWith("uninstall ")) {
            String pkg = rest.substring(10).trim().replaceFirst("^-[k]+\s+", "");
            return "pm uninstall " + pkg;
        }
        if (lower.startsWith("reboot")) {
            String target = rest.length() > 6 ? rest.substring(6).trim() : "";
            return target.isEmpty() ? "svc power reboot || reboot" : ("svc power reboot " + target + " || reboot " + target);
        }
        return rest;
    }

    private void runNormalShell(final String cmd) {
        executor.execute(() -> {
            StringBuilder out = new StringBuilder();
            int code = -1;
            try {
                ProcessBuilder pb = new ProcessBuilder("sh", "-c", cmd);
                pb.directory(currentDir.exists() ? currentDir : new File("/"));
                pb.redirectErrorStream(true);
                Process proc = pb.start();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream(), "UTF-8"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        out.append(line).append("\n");
                    }
                }
                code = proc.waitFor();
            } catch (Exception e) {
                out.append("[sh error]: ").append(e.getMessage()).append("\n");
            }
            final String text = out.toString();
            final int exitCode = code;
            mainHandler.post(() -> {
                if (!text.isEmpty()) appendColored(text, 0xFFD1D5DB);
                appendColored("[exit " + exitCode + "]\n", 0xFF9CA3AF);
                renderCurrentLine();
                focusInputAndShowKeyboard();
            });
        });
    }

    private void runRootShell(final String rootCmd) {
        executor.execute(() -> {
            StringBuilder out = new StringBuilder();
            int code = -1;
            try {
                ProcessBuilder pb = new ProcessBuilder("su", "-c", rootCmd);
                pb.redirectErrorStream(true);
                Process proc = pb.start();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream(), "UTF-8"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        out.append(line).append("\n");
                    }
                }
                code = proc.waitFor();
            } catch (Exception e) {
                out.append("[su error]: ").append(e.getMessage()).append("\n");
            }
            final String text = out.toString();
            final int exitCode = code;
            mainHandler.post(() -> {
                if (!text.isEmpty()) appendColored(text, 0xFFD1D5DB);
                appendColored("[su exit " + exitCode + "]\n", 0xFF9CA3AF);
                renderCurrentLine();
                focusInputAndShowKeyboard();
            });
        });
    }

    private void loadInstalledAppsAsync() {
        executor.execute(() -> {
            PackageManager pm = getPackageManager();
            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(mainIntent, 0);
            List<AppEntry> loaded = new ArrayList<>();
            for (ResolveInfo ri : list) {
                if (ri.activityInfo == null) continue;
                String pkg = ri.activityInfo.packageName;
                if (getPackageName().equals(pkg)) continue;
                CharSequence lblSeq = ri.loadLabel(pm);
                String label = lblSeq != null ? lblSeq.toString() : pkg;
                Drawable icon = ri.loadIcon(pm);
                loaded.add(new AppEntry(label, pkg, icon));
            }
            Collections.sort(loaded, (a, b) -> a.label.compareToIgnoreCase(b.label));
            mainHandler.post(() -> {
                installedApps.clear();
                installedApps.addAll(loaded);
            });
        });
    }

    private void launchAppByQuery(String query) {
        if (TextUtils.isEmpty(query)) {
            showAppDrawerDialog();
            return;
        }
        String qLower = query.toLowerCase(Locale.ROOT);
        for (AppEntry app : installedApps) {
            if (app.packageName.equalsIgnoreCase(query) || app.label.toLowerCase(Locale.ROOT).contains(qLower)) {
                launchPackage(app.packageName, app.label);
                return;
            }
        }
        launchPackage(query, query);
    }

    private void launchPackage(String pkg, String label) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) {
                appendColored("[not found: " + label + "]\n", 0xFFF87171);
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            appendColored("[launched " + label + "]\n", 0xFF4ADE80);
        } catch (Exception e) {
            appendColored("[launch error]: " + e.getMessage() + "\n", 0xFFF87171);
        }
    }

    private void showAppDrawerDialog() {
        if (installedApps.isEmpty()) {
            loadInstalledAppsAsync();
            Toast.makeText(this, "Loading apps...", Toast.LENGTH_SHORT).show();
            return;
        }

        ScrollView sv = new ScrollView(this);
        LinearLayout listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        listBox.setBackgroundColor(0xFF000000);
        listBox.setPadding(dp(12), dp(12), dp(12), dp(12));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Installed Apps (" + installedApps.size() + ")")
            .setView(sv)
            .setNegativeButton("Close", (d, w) -> focusInputAndShowKeyboard())
            .create();

        for (final AppEntry app : installedApps) {
            LinearLayout itemRow = new LinearLayout(this);
            itemRow.setOrientation(LinearLayout.HORIZONTAL);
            itemRow.setGravity(Gravity.CENTER_VERTICAL);
            itemRow.setPadding(dp(8), dp(8), dp(8), dp(8));

            ImageView iv = new ImageView(this);
            iv.setImageDrawable(app.icon);
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(34), dp(34));
            iconLp.rightMargin = dp(10);
            itemRow.addView(iv, iconLp);

            LinearLayout textCol = new LinearLayout(this);
            textCol.setOrientation(LinearLayout.VERTICAL);

            TextView nameTv = new TextView(this);
            nameTv.setText(app.label);
            nameTv.setTextColor(0xFFE5E7EB);
            nameTv.setTextSize(13.5f);
            nameTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            textCol.addView(nameTv);

            TextView pkgTv = new TextView(this);
            pkgTv.setText(app.packageName);
            pkgTv.setTextColor(0xFF9CA3AF);
            pkgTv.setTextSize(11f);
            pkgTv.setTypeface(Typeface.MONOSPACE);
            textCol.addView(pkgTv);

            itemRow.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1f));
            itemRow.setOnClickListener(v -> {
                dialog.dismiss();
                launchPackage(app.packageName, app.label);
            });
            listBox.addView(itemRow, new LinearLayout.LayoutParams(-1, -2));
        }

        sv.addView(listBox);
        dialog.show();
    }

    private void appendPlain(String text) {
        if (text == null) return;
        terminalLog.append(text);
        trimLogBuffer();
    }

    private void appendColored(String text, int color) {
        if (text == null) return;
        int start = terminalLog.length();
        terminalLog.append(text);
        terminalLog.setSpan(new ForegroundColorSpan(color), start, terminalLog.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        trimLogBuffer();
    }

    private void trimLogBuffer() {
        if (terminalLog.length() > 24000) {
            terminalLog.delete(0, terminalLog.length() - 18000);
        }
    }

    private void focusInputAndShowKeyboard() {
        if (commandInput == null) return;
        try {
            commandInput.setVisibility(View.VISIBLE);
            commandInput.setEnabled(true);
            commandInput.setFocusable(true);
            commandInput.setFocusableInTouchMode(true);
            commandInput.requestFocus();
            commandInput.requestFocusFromTouch();
            commandInput.postDelayed(() -> {
                try {
                    if (commandInput == null) return;
                    commandInput.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        boolean shown = imm.showSoftInput(commandInput, InputMethodManager.SHOW_IMPLICIT);
                        if (!shown) {
                            imm.showSoftInput(commandInput, InputMethodManager.SHOW_FORCED);
                        }
                    }
                } catch (Exception ignored) { }
            }, 80L);
        } catch (Exception ignored) { }
    }

    private void animateLaunch() {
        if (mainColumn == null) return;
        mainColumn.setAlpha(0f);
        mainColumn.animate()
            .alpha(1f)
            .setDuration(180L)
            .start();
    }

    private void animatePress(View v) {
        if (v == null) return;
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(55L)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(75L).start())
            .start();
    }

    private Button createTermuxKeyBtn(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(0xFFE5E7EB);
        b.setTextSize(12f);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setMinHeight(dp(34));
        b.setMinimumHeight(dp(34));
        b.setMinWidth(dp(44));
        b.setMinimumWidth(dp(44));
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
