# NH Terminal Launcher (v1.3 — Fix ProGuard File Name in app/build.gradle)

- Fixes `proguard-proguard-android-optimize.txt` typo in `app/build.gradle` to `proguard-android-optimize.txt`.
- Retains the `#000000` Termux UI, 2-row extra keys bar, `setup-storage`, `play music`, `apps` / `open <app>`, `pwd` / `ls` / `cd`, `su` / `adb <cmd>`, and `clear`.
