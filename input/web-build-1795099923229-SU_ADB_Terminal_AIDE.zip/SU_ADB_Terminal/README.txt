SU ADB TERMINAL - SOURCE PROJECT
================================

A lightweight Java Android terminal that starts `su` (root) or `sh` (normal
shell) directly from the app. It does not need Termux. A root manager such as
Magisk, KernelSU, or APatch must already provide a working `su` binary.

WHAT IT DOES
------------
- Opens a persistent local Android shell.
- Requests root permission at startup using `su`.
- Lets you switch between ROOT and normal SHELL modes.
- Streams command output while commands are running.
- Supports command-line input, clear screen, and help.
- Supports these ADB-style shortcuts:
    adb shell <command>  -> runs <command> in this phone's local shell
    adb logcat            -> runs logcat
    adb reboot            -> runs reboot (root is usually required)

IMPORTANT ADB LIMITATION
------------------------
This is an ON-DEVICE ROOT SHELL, not a complete Android Debug Bridge host.
It cannot independently provide `adb devices`, `adb push`, `adb pull`, or
`adb install`. Those commands require an ADB client/host and an adbd connection.
Use Android shell equivalents such as `pm`, `am`, `getprop`, `dumpsys`, `logcat`,
and `settings` where appropriate.

BUILD WITH CLASSIC AIDE
-----------------------
1. Extract this ZIP into a normal folder on your phone's internal storage.
2. Open AIDE and use its file browser to locate the extracted folder.
3. Open it as an Android App Project (the folder includes Eclipse/AIDE project
   metadata: .project, .classpath, AndroidManifest.xml, src/, and res/).
4. Make sure the Android SDK platform referenced by project.properties is
   installed. This project currently targets android-35. If your AIDE install
   only has another platform, change project.properties to that installed
   platform (for example target=android-28) and build with that SDK.
5. Tap Run/Build in AIDE and install the generated APK.

BUILD WITH ANDROIDIDE / GRADLE-BASED IDE
---------------------------------------
Open the extracted project root (the folder containing settings.gradle) as an
existing project and sync/build. The Gradle configuration uses Android Gradle
Plugin 8.6.1, Gradle 8.7, JDK 17, and compile SDK 35. The IDE may need internet
access once to download build dependencies.

PACKAGE
-------
Application ID: com.dva.suadbterminal
Minimum Android: 6.0 (API 23)
Target SDK: 28
Version: 1.0
Language: Java (no AndroidX or third-party dependencies)

SAFETY
------
Commands in ROOT mode execute with full root privileges. A wrong command can
wipe data, break Android, or make the phone unbootable. Do not run commands
unless you understand what they do. The app itself does not flash partitions,
modify boot images, or run commands automatically beyond checking `id` after
shell startup.
