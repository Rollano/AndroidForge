package com.dva.suadbterminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

/**
 * Lightweight on-device Android shell. Root access is provided by the installed
 * su implementation (Magisk, KernelSU, APatch, etc.). This is not an ADB host.
 */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 12, 18);
    private static final int PANEL = Color.rgb(15, 22, 31);
    private static final int GREEN = Color.rgb(105, 230, 155);
    private static final int CYAN = Color.rgb(83, 205, 232);
    private static final int MUTED = Color.rgb(143, 158, 174);
    private static final int ORANGE = Color.rgb(255, 190, 95);
    private static final int WHITE = Color.rgb(232, 240, 248);
    private static final int MAX_OUTPUT_CHARS = 50000;

    private final Object shellLock = new Object();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private LinearLayout rootLayout;
    private TextView statusView;
    private TextView outputView;
    private ScrollView outputScroll;
    private EditText commandInput;
    private Button modeButton;

    private Process shellProcess;
    private DataOutputStream shellInput;
    private Thread readerThread;
    private volatile boolean rootMode = true;
    private volatile boolean rootConfirmed = false;
    private volatile boolean shellStarting = false;
    private volatile boolean closing = false;
    private final StringBuilder detectionBuffer = new StringBuilder();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildInterface();
        appendSystem("SU ADB Terminal started. Commands run on this phone.\n");
        appendSystem("Requesting root through su... approve the superuser prompt.\n\n");
        startShell(true);
    }

    private void buildInterface() {
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setPadding(dp(12), dp(12), dp(12), dp(10));
        rootLayout.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("SU ADB TERMINAL");
        title.setTextColor(WHITE);
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView subtitle = new TextView(this);
        subtitle.setText("ANDROID LOCAL SHELL  •  NO TERMUX REQUIRED");
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(9);
        subtitle.setPadding(0, dp(3), 0, 0);
        titleBox.addView(title);
        titleBox.addView(subtitle);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));

        statusView = new TextView(this);
        statusView.setText("ROOT: STARTING");
        statusView.setTextColor(ORANGE);
        statusView.setTextSize(10);
        statusView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        statusView.setPadding(dp(9), dp(7), dp(9), dp(7));
        statusView.setBackground(roundRect(PANEL, dp(9), Color.rgb(65, 75, 87)));
        header.addView(statusView);
        rootLayout.addView(header);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(38, 51, 65));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.topMargin = dp(12);
        dividerParams.bottomMargin = dp(10);
        rootLayout.addView(divider, dividerParams);

        outputScroll = new ScrollView(this);
        outputScroll.setFillViewport(true);
        outputScroll.setBackground(roundRect(Color.rgb(3, 7, 11), dp(12), Color.rgb(31, 46, 58)));
        outputScroll.setClipToPadding(true);
        outputScroll.setPadding(dp(10), dp(10), dp(10), dp(10));

        outputView = new TextView(this);
        outputView.setTextColor(GREEN);
        outputView.setTextSize(12);
        outputView.setTypeface(Typeface.MONOSPACE);
        outputView.setTextIsSelectable(true);
        outputView.setLineSpacing(dp(2), 1.0f);
        outputScroll.addView(outputView, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams terminalParams = new LinearLayout.LayoutParams(-1, 0, 1);
        rootLayout.addView(outputScroll, terminalParams);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionsParams = new LinearLayout.LayoutParams(-1, -2);
        actionsParams.topMargin = dp(10);
        actionsParams.bottomMargin = dp(9);

        modeButton = makeButton("ROOT ON", CYAN);
        modeButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                setShellMode(!rootMode);
            }
        });
        actionRow.addView(modeButton, weightedButtonParams());

        Button clearButton = makeButton("CLEAR", WHITE);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                outputView.setText("");
            }
        });
        actionRow.addView(clearButton, weightedButtonParams());

        Button helpButton = makeButton("HELP", ORANGE);
        helpButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showHelp();
            }
        });
        actionRow.addView(helpButton, weightedButtonParams());
        rootLayout.addView(actionRow, actionsParams);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);

        commandInput = new EditText(this);
        commandInput.setSingleLine(true);
        commandInput.setTextSize(13);
        commandInput.setTextColor(WHITE);
        commandInput.setHintTextColor(MUTED);
        commandInput.setHint("Enter command  (e.g. id, getprop, ls)");
        commandInput.setTypeface(Typeface.MONOSPACE);
        commandInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        commandInput.setImeOptions(EditorInfo.IME_ACTION_SEND);
        commandInput.setPadding(dp(12), 0, dp(8), 0);
        commandInput.setBackground(roundRect(PANEL, dp(10), Color.rgb(46, 63, 79)));
        commandInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                    submitCommand();
                    return true;
                }
                return false;
            }
        });
        inputRow.addView(commandInput, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button runButton = makeButton("RUN", GREEN);
        runButton.setTextSize(12);
        runButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                submitCommand();
            }
        });
        LinearLayout.LayoutParams runParams = new LinearLayout.LayoutParams(dp(68), dp(48));
        runParams.leftMargin = dp(8);
        inputRow.addView(runButton, runParams);
        rootLayout.addView(inputRow);

        TextView footer = new TextView(this);
        footer.setText("ROOT REQUIRES MAGISK / KERNELSU / APATCH  •  USE COMMANDS CAREFULLY");
        footer.setTextColor(MUTED);
        footer.setTextSize(8);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(9), 0, 0);
        rootLayout.addView(footer);

        setContentView(rootLayout);
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(38), 1);
        p.leftMargin = dp(3);
        p.rightMargin = dp(3);
        return p;
    }

    private Button makeButton(String text, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(textColor);
        b.setTextSize(10);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackground(roundRect(PANEL, dp(9), Color.rgb(45, 61, 77)));
        return b;
    }

    private GradientDrawable roundRect(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setShellMode(boolean useRoot) {
        if (rootMode == useRoot && shellProcess != null) return;
        rootMode = useRoot;
        stopShell();
        appendSystem("\n[!] Switching to " + (rootMode ? "ROOT" : "NORMAL") + " shell...\n");
        startShell(rootMode);
    }

    private void startShell(final boolean useRoot) {
        shellStarting = true;
        rootConfirmed = false;
        closing = false;
        synchronized (detectionBuffer) {
            detectionBuffer.setLength(0);
        }
        updateStatus(useRoot ? "ROOT: REQUESTING" : "SHELL: STARTING", ORANGE);

        Thread starter = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    ProcessBuilder builder = new ProcessBuilder(useRoot ? "su" : "sh");
                    builder.redirectErrorStream(true);
                    builder.environment().put("TERM", "xterm-256color");
                    builder.environment().put("PATH", "/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/odm/bin");
                    Process process = builder.start();
                    DataOutputStream input = new DataOutputStream(process.getOutputStream());
                    synchronized (shellLock) {
                        shellProcess = process;
                        shellInput = input;
                    }
                    shellStarting = false;
                    writeToShell("export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/odm/bin:$PATH; export HOME=/data/local/tmp; export PS1=''; echo __SUADB_READY__; id\n");
                    readerThread = new Thread(new Runnable() {
                        @Override public void run() {
                            readShellOutput(process, useRoot);
                        }
                    }, "SuAdbOutputReader");
                    readerThread.setDaemon(true);
                    readerThread.start();
                } catch (final IOException e) {
                    shellStarting = false;
                    updateStatus(useRoot ? "ROOT: UNAVAILABLE" : "SHELL: FAILED", Color.rgb(255, 105, 105));
                    appendSystem("[ERROR] Could not start " + (useRoot ? "su" : "sh") + ": " + e.getMessage() + "\n");
                    if (useRoot) appendSystem("Install/enable a root manager and make sure its su binary is available.\n");
                }
            }
        }, "SuAdbShellStarter");
        starter.setDaemon(true);
        starter.start();
    }

    private void readShellOutput(final Process process, final boolean useRoot) {
        InputStream stream = process.getInputStream();
        byte[] buffer = new byte[2048];
        try {
            int count;
            while ((count = stream.read(buffer)) != -1) {
                final String chunk = new String(buffer, 0, count, Charset.forName("UTF-8"));
                detectShellState(chunk, useRoot);
                String visible = chunk.replace("__SUADB_READY__", "");
                if (visible.length() > 0) {
                    mainHandler.post(new Runnable() {
                        @Override public void run() {
                            appendOutput(visible, GREEN);
                        }
                    });
                }
            }
        } catch (IOException e) {
            if (!closing) appendSystem("\n[Shell output closed: " + e.getMessage() + "]\n");
        }

        int exitCode = -1;
        try {
            exitCode = process.waitFor();
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        final int code = exitCode;
        mainHandler.post(new Runnable() {
            @Override public void run() {
                if (shellProcess == process && !closing) {
                    updateStatus(useRoot ? "ROOT: SHELL CLOSED" : "SHELL: CLOSED", Color.rgb(255, 170, 90));
                    appendSystem("\n[Shell process ended, exit code " + code + "]. Tap ROOT/USER to start a new shell.\n");
                    synchronized (shellLock) {
                        shellProcess = null;
                        shellInput = null;
                    }
                }
            }
        });
    }

    private void detectShellState(String chunk, boolean useRoot) {
        boolean hasMarker = false;
        boolean hasRootId = false;
        synchronized (detectionBuffer) {
            detectionBuffer.append(chunk);
            if (detectionBuffer.indexOf("__SUADB_READY__") >= 0) hasMarker = true;
            if (detectionBuffer.indexOf("uid=0") >= 0) hasRootId = true;
            if (detectionBuffer.length() > 4096) {
                detectionBuffer.delete(0, detectionBuffer.length() - 2048);
            }
        }
        if (useRoot && hasRootId) {
            rootConfirmed = true;
            updateStatus("ROOT: ACTIVE", GREEN);
        } else if (!useRoot && hasMarker) {
            updateStatus("SHELL: READY", CYAN);
        } else if (useRoot && hasMarker && !rootConfirmed) {
            updateStatus("ROOT: CHECKING", ORANGE);
        }
    }

    private void writeToShell(String command) {
        synchronized (shellLock) {
            if (shellInput == null) {
                appendSystem("[ERROR] Shell is not running.\n");
                return;
            }
            try {
                shellInput.write(command.getBytes("UTF-8"));
                shellInput.flush();
            } catch (IOException e) {
                appendSystem("[ERROR] Could not write to shell: " + e.getMessage() + "\n");
            }
        }
    }

    private void submitCommand() {
        String command = commandInput.getText().toString().trim();
        if (command.length() == 0) return;
        commandInput.setText("");
        hideKeyboard();

        if ("clear".equals(command)) {
            outputView.setText("");
            return;
        }

        String actualCommand = translateAdbShortcut(command);
        if (actualCommand == null) return;

        appendCommand((rootMode ? "root" : "shell") + " $ " + command + "\n");
        writeToShell(actualCommand + "\n");
    }

    /** Supports common `adb shell ...` syntax as a shortcut to this phone's own shell. */
    private String translateAdbShortcut(String command) {
        if (command.equals("adb shell")) {
            appendSystem("Already inside this phone's local Android shell. Type a command such as getprop, pm list packages, or dumpsys battery.\n");
            return null;
        }
        if (command.startsWith("adb shell ")) {
            return command.substring("adb shell ".length());
        }
        if (command.equals("adb logcat")) return "logcat";
        if (command.startsWith("adb logcat ")) return command.substring(4);
        if (command.equals("adb reboot")) return "reboot";
        if (command.startsWith("adb reboot ")) return "reboot " + command.substring("adb reboot ".length());
        if (command.startsWith("adb ")) {
            appendCommand("[ADB] ");
            appendSystem("This app runs commands locally on the phone; it is not a full ADB client.\n");
            appendSystem("Supported shortcuts: adb shell <command>, adb logcat, adb reboot.\n");
            appendSystem("Commands such as adb devices, push, pull, and install need a separate ADB host/client.\n");
            return null;
        }
        return command;
    }

    private void stopShell() {
        closing = true;
        Process oldProcess;
        DataOutputStream oldInput;
        synchronized (shellLock) {
            oldProcess = shellProcess;
            oldInput = shellInput;
            shellProcess = null;
            shellInput = null;
        }
        if (oldInput != null) {
            try { oldInput.write("exit\n".getBytes("UTF-8")); oldInput.flush(); } catch (Exception ignored) { }
            try { oldInput.close(); } catch (Exception ignored) { }
        }
        if (oldProcess != null) {
            try { oldProcess.destroy(); } catch (Exception ignored) { }
        }
    }

    private void updateStatus(final String text, final int color) {
        mainHandler.post(new Runnable() {
            @Override public void run() {
                if (statusView != null) {
                    statusView.setText(text);
                    statusView.setTextColor(color);
                    if (modeButton != null) modeButton.setText(rootMode ? "ROOT ON" : "ROOT OFF");
                }
            }
        });
    }

    private void appendSystem(final String text) {
        mainHandler.post(new Runnable() {
            @Override public void run() {
                appendOutput(text, MUTED);
            }
        });
    }

    private void appendCommand(final String text) {
        appendOutput(text, ORANGE);
    }

    private void appendOutput(final String text, final int color) {
        if (outputView == null || text == null || text.length() == 0) return;
        android.text.SpannableString styled = new android.text.SpannableString(text);
        styled.setSpan(new android.text.style.ForegroundColorSpan(color), 0, styled.length(), 0);
        outputView.append(styled);
        if (outputView.length() > MAX_OUTPUT_CHARS) {
            int trimCount = outputView.length() - MAX_OUTPUT_CHARS;
            CharSequence tail = outputView.getText().subSequence(trimCount, outputView.length());
            outputView.setText(tail, TextView.BufferType.SPANNABLE);
        }
        outputScroll.post(new Runnable() {
            @Override public void run() { outputScroll.fullScroll(View.FOCUS_DOWN); }
        });
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(commandInput.getWindowToken(), 0);
            commandInput.clearFocus();
        } catch (Exception ignored) { }
    }

    private void showHelp() {
        String message =
                "ROOT MODE\n" +
                "Runs commands through the installed su manager. Approve the root request when prompted.\n\n" +
                "EXAMPLES\n" +
                "id                 Check current user\n" +
                "getprop            Android system properties\n" +
                "df -h              Storage usage\n" +
                "pm list packages   Installed package names\n" +
                "dumpsys battery    Battery details\n" +
                "logcat -d          Read system logs\n" +
                "adb shell getprop  ADB-style local-shell shortcut\n\n" +
                "LIMITATION\n" +
                "This is an on-device shell, not an ADB host. adb devices/push/pull/install require a separate ADB client and connection.\n\n" +
                "Root commands can change or damage your system. Only run commands you understand.";
        new AlertDialog.Builder(this)
                .setTitle("Terminal Help")
                .setMessage(message)
                .setPositiveButton("GOT IT", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        stopShell();
        super.onDestroy();
    }
}
