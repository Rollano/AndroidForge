# termux-vision (v6 — Two-Finger Pinch Zoom, Extra Keys & Running Lock Fix)

- **2-Finger Pinch Zoom**: Zoom terminal text in/out smoothly like Termux (`7sp` to `34sp`), with live zoom indicator and saved preference.
- **Termux-style Extra Keys Bar at Bottom**: Includes `CTRL`, `ALT`, `ESC`, `TAB`, `-`, `/`, `|`, `~`, `$`, `↑`, `↓`, `←`, `→`, and `UNLOCK` (toggleable in `⋮` menu).
- **Running Lock Fix**: Prevents getting locked out if a command hangs or doesn't return a callback — includes `^C / UNLOCK`, `UNLOCK` key, `unlock` command, and auto-recovery on stale sessions.
