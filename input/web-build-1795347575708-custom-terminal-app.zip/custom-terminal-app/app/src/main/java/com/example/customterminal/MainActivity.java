package com.example.customterminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 101;
    private static final String TERMUX_PACKAGE = "com.termux";
    private static final String RUN_PERMISSION = "com.termux.permission.RUN_COMMAND";
    private static final String DEFAULT_HOME = "/data/data/com.termux/files/home";
    private static final AtomicInteger executionIds = new AtomicInteger(1000);
    private static volatile MainActivity activeActivity;

    // Color themes: {topBarBg, terminalBg, accent/text, prompt/secondary, chipBg}
    private static final String[] PALETTE_NAMES = {
        "Classic Slate (Default)",
        "Matrix Dark",
        "Neon Night",
        "Mint Dark",
        "Pure Black + Green"
    };
    private final int[][] palettes = {
        {0xFF546E7A, 0xFF000000, 0xFFFFFFFF, 0xFFB0BEC5, 0xFF263238},
        {0xFF0E2233, 0xFF07111D, 0xFF73FBD3, 0xFF80CBC4, 0xFF112A3A},
        {0xFF2B193D, 0xFF120B1A, 0xFFFF78C8, 0xFFF8BBD0, 0xFF38203A},
        {0xFF1F3324, 0xFF0D140E, 0xFFA6F28A, 0xFFC5E1A5, 0xFF263421},
        {0xFF102810, 0xFF000000, 0xFF39FF14, 0xFF76FF03, 0xFF101F10}
    };
    private static final String[] FONT_NAMES = {"Monospace", "Sans Serif", "Serif", "Casual"};

    private static class TerminalWindow {
        final String id;
        String title;
        final StringBuilder logBuffer = new StringBuilder();
        File workingDir;
        String activeSessionToken;
        boolean activeSessionReceivedLines;
        boolean commandRunning;
        String pendingInstallPackage;
        boolean awaitingConfirm;
        String confirmPromptText;

        TerminalWindow(String id, String title, File dir) {
            this.id = id;
            this.title = title;
            this.workingDir = dir;
        }
    }

    private static class CustomCommand {
        final String name;
        final String command;
        CustomCommand(String name, String command) {
            this.name = name;
            this.command = command;
        }
    }

    private static class AppEntry {
        final String label;
        final String packageName;
        final Drawable icon;
        AppEntry(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    private final ArrayList<TerminalWindow> windows = new ArrayList<>();
    private int activeWindowIndex = 0;

    private final ArrayList<String> commandHistory = new ArrayList<>();
    private final ArrayList<CustomCommand> customCommands = new ArrayList<>();

    private int palette = 0;
    private int fontFamily = 0;
    private int fontSize = 13;
    private int overlayPercent = 100;

    private SharedPreferences preferences;
    private FrameLayout root;
    private ImageView wallpaper;
    private View shade;

    // Top bar (TermOne Plus style)
    private LinearLayout topBar;
    private TextView windowSelectorText;
    private LinearLayout windowDropdownChip;
    private TextView menuIconBtn;
    private TextView addWinBtn;
    private TextView closeWinBtn;
    private TextView overflowBtn;

    // Terminal area
    private ScrollView scroll;
    private LinearLayout terminalContainer;
    private TextView output;
    private LinearLayout promptRow;
    private TextView promptLabel;
    private EditText input;

    // Inline confirmation banner (for [Y/n] prompts)
    private LinearLayout confirmBar;
    private TextView confirmMessage;
    private Button confirmYesBtn;
    private Button confirmNoBtn;

    // Collapsible quick tools bar
    private HorizontalScrollView quickBarScroll;
    private boolean quickBarVisible = false;
    private LinearLayout customChips;

    // Navigation drawer
    private LinearLayout drawerPanel;
    private List<AppEntry> launchableApps;
    private LinearLayout appRows;
    private EditText appSearch;
    private View drawerScrim;
    private boolean drawerOpen = false;
    private int drawerWidth;

    private final Handler commandHandler = new Handler(Looper.getMainLooper());
    private final Runnable commandTimeout = () -> {
        TerminalWindow w = currentWindow();
        if (w == null || !w.commandRunning) return;
        appendToWindow(w, "\n[No response from Termux. Check Termux or tap ⋮ > Termux Connection.]\n");
        w.activeSessionToken = null;
        w.commandRunning = false;
        w.awaitingConfirm = false;
        updateInputState();
    };

    private TerminalWindow currentWindow() {
        if (windows.isEmpty()) return null;
        if (activeWindowIndex < 0 || activeWindowIndex >= windows.size()) activeWindowIndex = 0;
        return windows.get(activeWindowIndex);
    }

    private TerminalWindow findWindowByToken(String token) {
        if (token == null) return null;
        for (TerminalWindow w : windows) {
            if (token.equals(w.activeSessionToken)) return w;
        }
        return null;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("custom-terminal", MODE_PRIVATE);
        palette = preferences.getInt("palette", 0);
        fontFamily = preferences.getInt("font_family", 0);
        fontSize = preferences.getInt("font_size", 13);
        overlayPercent = preferences.getInt("overlay", 100);
        quickBarVisible = preferences.getBoolean("quick_bar_visible", false);

        loadCustomCommands();
        loadCommandHistory();

        File initialDir = new File(preferences.getString("working_directory", DEFAULT_HOME));
        TerminalWindow win1 = new TerminalWindow(UUID.randomUUID().toString(), "Window 1", initialDir);
        windows.add(win1);
        activeWindowIndex = 0;

        buildUi();

        String savedWallpaper = preferences.getString("wallpaper", null);
        if (savedWallpaper != null) {
            try {
                wallpaper.setImageURI(Uri.parse(savedWallpaper));
            } catch (Exception ignored) { }
        }

        appendToWindow(win1, "Termux Vision Shell · Type 'help' for commands or tap ⋮ for tools.\n");
        syncWindowUi();
        focusTerminalInput();
    }

    @Override
    protected void onResume() {
        super.onResume();
        activeActivity = this;
    }

    @Override
    protected void onPause() {
        if (activeActivity == this) activeActivity = null;
        super.onPause();
    }

    static void receiveTermuxLog(String token, String line) {
        MainActivity a = activeActivity;
        if (a == null || token == null) return;
        a.runOnUiThread(() -> {
            TerminalWindow w = a.findWindowByToken(token);
            if (w == null) return;
            w.activeSessionReceivedLines = true;
            a.appendToWindow(w, line + "\n");
            a.detectConfirmationPrompt(w, line);
        });
    }

    static void receiveTermuxResult(String token, String text, int exitCode) {
        MainActivity a = activeActivity;
        if (a == null || token == null) return;
        a.runOnUiThread(() -> {
            TerminalWindow w = a.findWindowByToken(token);
            if (w == null) return;
            a.commandHandler.removeCallbacks(a.commandTimeout);
            if (!w.activeSessionReceivedLines && text != null && !text.isEmpty()) {
                a.appendToWindow(w, text);
                if (!text.endsWith("\n")) a.appendToWindow(w, "\n");
                a.detectConfirmationPrompt(w, text);
            }
            if (exitCode != 0) {
                a.appendToWindow(w, "[exit " + exitCode + "]\n");
            }
            w.activeSessionToken = null;
            w.commandRunning = false;
            if (w == a.currentWindow()) {
                a.updateInputState();
            }
        });
    }

    private void detectConfirmationPrompt(TerminalWindow w, String rawText) {
        if (rawText == null) return;
        String lower = rawText.toLowerCase();
        boolean isYesNoPrompt =
            lower.contains("[y/n]") ||
            lower.contains("(y/n)") ||
            lower.contains("do you want to continue") ||
            lower.contains("proceed? [y/n]") ||
            lower.contains("confirm [y/n]");

        if (isYesNoPrompt) {
            w.awaitingConfirm = true;
            w.confirmPromptText = rawText.trim();
            if (w == currentWindow()) {
                showConfirmBanner(w.confirmPromptText);
            }
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);

        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));

        shade = new View(this);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        // 1. Top Action Bar (TermOne Plus style: ☰ | Window 1 ▼ | + | × | ⋮)
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), dp(6), dp(6), dp(6));
        topBar.setElevation(dp(4));

        menuIconBtn = createActionIcon("☰", "Open drawer");
        menuIconBtn.setOnClickListener(v -> openDrawer());
        topBar.addView(menuIconBtn);

        windowDropdownChip = new LinearLayout(this);
        windowDropdownChip.setOrientation(LinearLayout.HORIZONTAL);
        windowDropdownChip.setGravity(Gravity.CENTER_VERTICAL);
        windowDropdownChip.setPadding(dp(10), dp(6), dp(10), dp(6));
        windowDropdownChip.setOnClickListener(v -> showWindowSwitcherDialog());

        windowSelectorText = new TextView(this);
        windowSelectorText.setText("Window 1   ▾");
        windowSelectorText.setTextSize(16);
        windowSelectorText.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        windowDropdownChip.addView(windowSelectorText);

        LinearLayout.LayoutParams titleWrapParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleWrapParams.leftMargin = dp(8);
        topBar.addView(windowDropdownChip, titleWrapParams);

        addWinBtn = createActionIcon("⊕", "New window");
        addWinBtn.setOnClickListener(v -> addNewWindow());
        topBar.addView(addWinBtn);

        closeWinBtn = createActionIcon("✕", "Close window");
        closeWinBtn.setOnClickListener(v -> closeCurrentWindow());
        topBar.addView(closeWinBtn);

        overflowBtn = createActionIcon("⋮", "More options");
        overflowBtn.setOnClickListener(v -> showOverflowMenu());
        topBar.addView(overflowBtn);

        page.addView(topBar, new LinearLayout.LayoutParams(-1, dp(48)));

        // 2. Optional collapsible quick toolbar (toggled from ⋮ menu)
        quickBarScroll = new HorizontalScrollView(this);
        quickBarScroll.setHorizontalScrollBarEnabled(false);
        quickBarScroll.setVisibility(quickBarVisible ? View.VISIBLE : View.GONE);
        quickBarScroll.setPadding(dp(6), dp(4), dp(6), dp(4));

        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER_VERTICAL);

        Button pkgBtn = chipButton("PKG INSTALL");
        pkgBtn.setOnClickListener(v -> showPackageInstallerDialog());
        chips.addView(pkgBtn);

        Button yesChip = chipButton("Y");
        yesChip.setOnClickListener(v -> sendConfirmationResponse(true));
        chips.addView(yesChip);

        Button noChip = chipButton("N");
        noChip.setOnClickListener(v -> sendConfirmationResponse(false));
        chips.addView(noChip);

        String[] quickCmds = {"ls", "pwd", "pkg update", "pkg list-installed"};
        for (String cmd : quickCmds) {
            Button b = chipButton(cmd);
            b.setOnClickListener(v -> {
                input.setText(cmd);
                runCommand();
            });
            chips.addView(b);
        }

        Button addCustom = chipButton("+ CUSTOM");
        addCustom.setOnClickListener(v -> showAddCustomDialog());
        chips.addView(addCustom);

        Button procBtn = chipButton("PROCESSES");
        procBtn.setOnClickListener(v -> listTermuxProcesses());
        chips.addView(procBtn);

        Button clearBtn = chipButton("CLEAR");
        clearBtn.setOnClickListener(v -> clearCurrentWindow());
        chips.addView(clearBtn);

        customChips = new LinearLayout(this);
        customChips.setGravity(Gravity.CENTER_VERTICAL);
        chips.addView(customChips);

        quickBarScroll.addView(chips);
        page.addView(quickBarScroll, new LinearLayout.LayoutParams(-1, -2));
        renderCustomCommands();

        // 3. Confirmation Bar for [Y/n] interactive prompts (like apt/pkg install)
        confirmBar = new LinearLayout(this);
        confirmBar.setOrientation(LinearLayout.HORIZONTAL);
        confirmBar.setGravity(Gravity.CENTER_VERTICAL);
        confirmBar.setPadding(dp(10), dp(6), dp(10), dp(6));
        confirmBar.setBackgroundColor(0xFF1E293B);
        confirmBar.setVisibility(View.GONE);

        confirmMessage = new TextView(this);
        confirmMessage.setText("Do you want to continue? [Y/n]");
        confirmMessage.setTextColor(0xFFFFFFFF);
        confirmMessage.setTextSize(12);
        confirmMessage.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        confirmMessage.setSingleLine(true);
        confirmMessage.setEllipsize(TextUtils.TruncateAt.END);
        confirmBar.addView(confirmMessage, new LinearLayout.LayoutParams(0, -2, 1f));

        confirmYesBtn = new Button(this);
        confirmYesBtn.setText("Y (Yes)");
        confirmYesBtn.setTextSize(11);
        confirmYesBtn.setTextColor(0xFF000000);
        confirmYesBtn.setBackgroundColor(0xFF4ADE80);
        confirmYesBtn.setMinHeight(dp(30));
        confirmYesBtn.setMinimumHeight(dp(30));
        confirmYesBtn.setPadding(dp(10), 0, dp(10), 0);
        confirmYesBtn.setOnClickListener(v -> sendConfirmationResponse(true));
        LinearLayout.LayoutParams yesParams = new LinearLayout.LayoutParams(-2, -2);
        yesParams.leftMargin = dp(6);
        confirmBar.addView(confirmYesBtn, yesParams);

        confirmNoBtn = new Button(this);
        confirmNoBtn.setText("N (No)");
        confirmNoBtn.setTextSize(11);
        confirmNoBtn.setTextColor(0xFFFFFFFF);
        confirmNoBtn.setBackgroundColor(0xFFEF4444);
        confirmNoBtn.setMinHeight(dp(30));
        confirmNoBtn.setMinimumHeight(dp(30));
        confirmNoBtn.setPadding(dp(10), 0, dp(10), 0);
        confirmNoBtn.setOnClickListener(v -> sendConfirmationResponse(false));
        LinearLayout.LayoutParams noParams = new LinearLayout.LayoutParams(-2, -2);
        noParams.leftMargin = dp(6);
        confirmBar.addView(confirmNoBtn, noParams);

        page.addView(confirmBar, new LinearLayout.LayoutParams(-1, -2));

        // 4. Full-bleed Pure Terminal Screen (matches TermOne Plus screenshot)
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        terminalContainer = new LinearLayout(this);
        terminalContainer.setOrientation(LinearLayout.VERTICAL);
        terminalContainer.setPadding(dp(6), dp(4), dp(6), dp(12));
        terminalContainer.setOnClickListener(v -> focusTerminalInput());

        output = new TextView(this);
        output.setTextSize(fontSize);
        output.setTypeface(selectedTypeface());
        output.setTextIsSelectable(true);
        output.setHorizontallyScrolling(false);
        output.setLineSpacing(0, 1.05f);
        output.setOnClickListener(v -> focusTerminalInput());
        terminalContainer.addView(output, new LinearLayout.LayoutParams(-1, -2));

        // Inline shell prompt right underneath output (e.g. ":/data/data/com.termux/files/home $ ")
        promptRow = new LinearLayout(this);
        promptRow.setOrientation(LinearLayout.HORIZONTAL);
        promptRow.setGravity(Gravity.CENTER_VERTICAL);

        promptLabel = new TextView(this);
        promptLabel.setTextSize(fontSize);
        promptLabel.setTypeface(selectedTypeface());
        promptRow.addView(promptLabel, new LinearLayout.LayoutParams(-2, -2));

        input = new EditText(this);
        input.setSingleLine(true);
        input.setBackground(null);
        input.setPadding(dp(2), dp(2), dp(4), dp(2));
        input.setTextSize(fontSize);
        input.setTypeface(selectedTypeface());
        input.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_SEND ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                handleTerminalEnter();
                return true;
            }
            return false;
        });
        input.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                handleTerminalEnter();
                return true;
            }
            return false;
        });
        promptRow.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));

        terminalContainer.addView(promptRow, new LinearLayout.LayoutParams(-1, -2));

        // Tappable empty space below prompt so tapping anywhere focuses keyboard
        View filler = new View(this);
        filler.setOnClickListener(v -> focusTerminalInput());
        terminalContainer.addView(filler, new LinearLayout.LayoutParams(-1, 0, 1f));

        scroll.addView(terminalContainer, new ScrollView.LayoutParams(-1, -2));
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        buildDrawer();
        setContentView(root);
        applyStyle();
    }

    private TextView createActionIcon(String glyph, String desc) {
        TextView tv = new TextView(this);
        tv.setText(glyph);
        tv.setTextSize(20);
        tv.setGravity(Gravity.CENTER);
        tv.setContentDescription(desc);
        tv.setMinWidth(dp(40));
        tv.setMinimumWidth(dp(40));
        tv.setMinHeight(dp(40));
        tv.setMinimumHeight(dp(40));
        return tv;
    }

    private Button chipButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setMinHeight(dp(30));
        b.setMinimumHeight(dp(30));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private void focusTerminalInput() {
        if (input == null) return;
        input.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }
    }

    private void handleTerminalEnter() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        String text = input.getText().toString().trim();
        if (w.awaitingConfirm) {
            if (text.isEmpty() || text.equalsIgnoreCase("y") || text.equalsIgnoreCase("yes")) {
                input.setText("");
                sendConfirmationResponse(true);
            } else if (text.equalsIgnoreCase("n") || text.equalsIgnoreCase("no")) {
                input.setText("");
                sendConfirmationResponse(false);
            } else {
                Toast.makeText(this, "Type y or n", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        runCommand();
    }

    private void showConfirmBanner(String promptText) {
        if (confirmBar == null) return;
        confirmMessage.setText(promptText.isEmpty() ? "Do you want to continue? [Y/n]" : promptText);
        confirmBar.setVisibility(View.VISIBLE);
    }

    private void hideConfirmBanner() {
        if (confirmBar != null) {
            confirmBar.setVisibility(View.GONE);
        }
    }

    private void sendConfirmationResponse(boolean yes) {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        w.awaitingConfirm = false;
        hideConfirmBanner();

        if (!yes) {
            appendToWindow(w, "n\nAbort.\n");
            w.pendingInstallPackage = null;
            w.commandRunning = false;
            w.activeSessionToken = null;
            updateInputState();
            return;
        }

        appendToWindow(w, "y\n");
        if (w.pendingInstallPackage != null && !w.pendingInstallPackage.isEmpty()) {
            String pkg = w.pendingInstallPackage;
            w.pendingInstallPackage = null;
            w.commandRunning = false;
            w.activeSessionToken = null;
            executeTermuxShellCommand(w, "yes | pkg install -y -- " + pkg, false);
        } else {
            // Forward 'y' to Termux if user typed y manually
            w.commandRunning = false;
            w.activeSessionToken = null;
            executeTermuxShellCommand(w, "echo y", false);
        }
    }

    private String formatShellPrompt(TerminalWindow w) {
        if (w == null) return ":$ ";
        String path = w.workingDir.getAbsolutePath();
        return ":" + path + " $ ";
    }

    private void syncWindowUi() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        windowSelectorText.setText(w.title + "   ▾");
        output.setText(w.logBuffer.toString());
        promptLabel.setText(formatShellPrompt(w));
        if (w.awaitingConfirm) {
            showConfirmBanner(w.confirmPromptText != null ? w.confirmPromptText : "Do you want to continue? [Y/n]");
        } else {
            hideConfirmBanner();
        }
        updateInputState();
        scrollToBottom();
    }

    private void updateInputState() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        promptLabel.setText(formatShellPrompt(w));
        if (w.commandRunning && !w.awaitingConfirm) {
            promptLabel.setVisibility(View.GONE);
            input.setHint("Running...");
        } else {
            promptLabel.setVisibility(View.VISIBLE);
            input.setHint(w.awaitingConfirm ? "[Y/n]" : "");
        }
    }

    private void appendToWindow(TerminalWindow w, String text) {
        if (w == null || text == null) return;
        w.logBuffer.append(text);
        if (w.logBuffer.length() > 24000) {
            w.logBuffer.delete(0, w.logBuffer.length() - 18000);
        }
        if (w == currentWindow() && output != null) {
            output.setText(w.logBuffer.toString());
            scrollToBottom();
        }
    }

    private void scrollToBottom() {
        if (scroll != null) {
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void addNewWindow() {
        int nextNum = windows.size() + 1;
        File dir = currentWindow() != null ? currentWindow().workingDir : new File(DEFAULT_HOME);
        TerminalWindow w = new TerminalWindow(UUID.randomUUID().toString(), "Window " + nextNum, dir);
        windows.add(w);
        activeWindowIndex = windows.size() - 1;
        syncWindowUi();
        focusTerminalInput();
    }

    private void closeCurrentWindow() {
        if (windows.size() <= 1) {
            clearCurrentWindow();
            Toast.makeText(this, "Window cleared", Toast.LENGTH_SHORT).show();
            return;
        }
        windows.remove(activeWindowIndex);
        if (activeWindowIndex >= windows.size()) {
            activeWindowIndex = windows.size() - 1;
        }
        syncWindowUi();
    }

    private void clearCurrentWindow() {
        TerminalWindow w = currentWindow();
        if (w == null) return;
        w.logBuffer.setLength(0);
        w.awaitingConfirm = false;
        w.pendingInstallPackage = null;
        if (w.commandRunning) {
            commandHandler.removeCallbacks(commandTimeout);
            w.activeSessionToken = null;
            w.commandRunning = false;
        }
        syncWindowUi();
    }

    private void showWindowSwitcherDialog() {
        String[] titles = new String[windows.size() + 1];
        for (int i = 0; i < windows.size(); i++) {
            TerminalWindow w = windows.get(i);
            titles[i] = w.title + " (" + w.workingDir.getName() + ")" + (i == activeWindowIndex ? "  ✓" : "");
        }
        titles[windows.size()] = "+ New Window";

        new AlertDialog.Builder(this)
            .setTitle("Terminal Windows")
            .setItems(titles, (d, which) -> {
                if (which == windows.size()) {
                    addNewWindow();
                } else {
                    activeWindowIndex = which;
                    syncWindowUi();
                }
            })
            .show();
    }

    private void showOverflowMenu() {
        String[] items = {
            (quickBarVisible ? "Hide" : "Show") + " Quick Toolbar",
            "Install Package (pkg install)",
            "Wallpaper",
            "Preferences / Style",
            "Command History",
            "Termux Connection",
            "Reset Terminal"
        };
        new AlertDialog.Builder(this)
            .setItems(items, (d, which) -> {
                switch (which) {
                    case 0:
                        quickBarVisible = !quickBarVisible;
                        preferences.edit().putBoolean("quick_bar_visible", quickBarVisible).apply();
                        quickBarScroll.setVisibility(quickBarVisible ? View.VISIBLE : View.GONE);
                        break;
                    case 1:
                        showPackageInstallerDialog();
                        break;
                    case 2:
                        chooseWallpaper();
                        break;
                    case 3:
                        showStyleMenu();
                        break;
                    case 4:
                        showHistory();
                        break;
                    case 5:
                        connectTermux();
                        break;
                    case 6:
                        clearCurrentWindow();
                        break;
                }
            })
            .show();
    }

    private Typeface selectedTypeface() {
        switch (fontFamily) {
            case 1: return Typeface.create("sans-serif", Typeface.NORMAL);
            case 2: return Typeface.create("serif", Typeface.NORMAL);
            case 3: return Typeface.create("casual", Typeface.NORMAL);
            default: return Typeface.MONOSPACE;
        }
    }

    private void applyStyle() {
        int[] c = palettes[Math.max(0, Math.min(palette, palettes.length - 1))];
        topBar.setBackgroundColor(c[0]);
        menuIconBtn.setTextColor(0xFFFFFFFF);
        windowSelectorText.setTextColor(0xFFFFFFFF);
        addWinBtn.setTextColor(0xFFFFFFFF);
        closeWinBtn.setTextColor(0xFFFFFFFF);
        overflowBtn.setTextColor(0xFFFFFFFF);

        int alpha = palette == 0 ? 0xFF : Math.max(0x40, Math.min(0xFF, overlayPercent * 255 / 100));
        shade.setBackgroundColor((alpha << 24) | (c[1] & 0x00FFFFFF));

        output.setTextColor(c[2]);
        promptLabel.setTextColor(c[2]);
        input.setTextColor(c[2]);
        input.setHintTextColor(c[3]);

        output.setTextSize(fontSize);
        promptLabel.setTextSize(fontSize);
        input.setTextSize(fontSize);

        Typeface tf = selectedTypeface();
        output.setTypeface(tf);
        promptLabel.setTypeface(tf);
        input.setTypeface(tf);

        quickBarScroll.setBackgroundColor(c[4]);
        tintButtons(quickBarScroll, c[2], c[0]);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(c[0]);
            getWindow().setNavigationBarColor(0xFF000000);
        }

        if (drawerPanel != null) {
            drawerPanel.setBackgroundColor(c[1]);
            appSearch.setTextColor(c[2]);
            appSearch.setHintTextColor(c[3]);
            tintButtons(drawerPanel, c[2], c[4]);
        }
    }

    private void tintButtons(View view, int textColor, int bgColor) {
        if (view instanceof Button) {
            Button b = (Button) view;
            b.setTextColor(textColor);
            b.setBackgroundColor(bgColor);
        }
        if (view instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) view;
            for (int i = 0; i < g.getChildCount(); i++) {
                tintButtons(g.getChildAt(i), textColor, bgColor);
            }
        }
    }

    private void saveStyle() {
        preferences.edit()
            .putInt("palette", palette)
            .putInt("font_family", fontFamily)
            .putInt("font_size", fontSize)
            .putInt("overlay", overlayPercent)
            .apply();
        applyStyle();
    }

    private void showStyleMenu() {
        String[] items = {
            "Font style: " + FONT_NAMES[fontFamily],
            "Font size: " + fontSize + " sp",
            "Color theme: " + PALETTE_NAMES[palette],
            "Background opacity: " + overlayPercent + "%"
        };
        new AlertDialog.Builder(this)
            .setTitle("Terminal Preferences")
            .setItems(items, (d, which) -> {
                if (which == 0) chooseFont();
                else if (which == 1) chooseFontSize();
                else if (which == 2) choosePalette();
                else chooseOverlay();
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private void chooseFont() {
        new AlertDialog.Builder(this)
            .setTitle("Font style")
            .setSingleChoiceItems(FONT_NAMES, fontFamily, (d, which) -> {
                fontFamily = which;
                saveStyle();
                d.dismiss();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void choosePalette() {
        new AlertDialog.Builder(this)
            .setTitle("Color theme")
            .setSingleChoiceItems(PALETTE_NAMES, palette, (d, which) -> {
                palette = which;
                saveStyle();
                d.dismiss();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void chooseFontSize() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(4));
        TextView label = new TextView(this);
        label.setText("Font size: " + fontSize + " sp");
        label.setTextSize(16);
        box.addView(label);
        SeekBar seek = new SeekBar(this);
        seek.setMax(22);
        seek.setProgress(fontSize - 10);
        box.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                label.setText("Font size: " + (p + 10) + " sp");
            }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        new AlertDialog.Builder(this)
            .setTitle("Font size")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply", (d, w) -> {
                fontSize = seek.getProgress() + 10;
                saveStyle();
            })
            .show();
    }

    private void chooseOverlay() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(4));
        TextView label = new TextView(this);
        label.setText("Background opacity: " + overlayPercent + "%");
        label.setTextSize(16);
        box.addView(label);
        SeekBar seek = new SeekBar(this);
        seek.setMax(75);
        seek.setProgress(overlayPercent - 25);
        box.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                label.setText("Background opacity: " + (p + 25) + "%");
            }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        new AlertDialog.Builder(this)
            .setTitle("Background opacity")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply", (d, w) -> {
                overlayPercent = seek.getProgress() + 25;
                saveStyle();
            })
            .show();
    }

    private void chooseWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_WALLPAPER);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_WALLPAPER && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                int takeFlags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                if (takeFlags != 0) {
                    try {
                        getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    } catch (SecurityException ignored) { }
                }
                wallpaper.setImageURI(uri);
                preferences.edit().putString("wallpaper", uri.toString()).apply();
                if (overlayPercent == 100) {
                    overlayPercent = 80;
                    saveStyle();
                }
            } catch (Exception e) {
                appendToWindow(currentWindow(), "Wallpaper error: " + e.getMessage() + "\n");
            }
        }
    }

    private void showHistory() {
        if (commandHistory.isEmpty()) {
            Toast.makeText(this, "No commands in history yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] items = commandHistory.toArray(new String[0]);
        new AlertDialog.Builder(this)
            .setTitle("Recent commands")
            .setItems(items, (d, which) -> {
                input.setText(items[which]);
                input.setSelection(input.getText().length());
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private void loadCommandHistory() {
        try {
            JSONArray saved = new JSONArray(preferences.getString("command_history", "[]"));
            int first = Math.max(0, saved.length() - 100);
            for (int i = first; i < saved.length(); i++) {
                String command = saved.optString(i, "");
                if (!command.isEmpty()) commandHistory.add(command);
            }
        } catch (Exception ignored) {
            commandHistory.clear();
        }
    }

    private void saveCommandHistory() {
        JSONArray saved = new JSONArray();
        int first = Math.max(0, commandHistory.size() - 100);
        for (int i = first; i < commandHistory.size(); i++) saved.put(commandHistory.get(i));
        preferences.edit().putString("command_history", saved.toString()).apply();
    }

    private void rememberCommand(String command) {
        commandHistory.add(command);
        while (commandHistory.size() > 100) commandHistory.remove(0);
        saveCommandHistory();
    }

    private void buildDrawer() {
        drawerWidth = dp(290);
        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(0x99000000);
        drawerScrim.setAlpha(0f);
        drawerScrim.setVisibility(View.GONE);
        drawerScrim.setOnClickListener(v -> closeDrawer());
        root.addView(drawerScrim, new FrameLayout.LayoutParams(-1, -1));

        drawerPanel = new LinearLayout(this);
        drawerPanel.setOrientation(LinearLayout.VERTICAL);
        drawerPanel.setPadding(dp(14), dp(14), dp(12), dp(12));
        drawerPanel.setElevation(dp(12));
        drawerPanel.setTranslationX(-drawerWidth);
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(drawerWidth, -1, Gravity.LEFT);
        root.addView(drawerPanel, drawerParams);

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView headingText = new TextView(this);
        headingText.setText("WINDOWS & APPS");
        headingText.setTextColor(0xFFFFFFFF);
        headingText.setTextSize(15);
        headingText.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        heading.addView(headingText, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = chipButton("✕");
        close.setOnClickListener(v -> closeDrawer());
        heading.addView(close);
        drawerPanel.addView(heading);

        // Quick Window actions inside drawer (like TermOne Plus drawer)
        Button newWinDrawerBtn = chipButton("+ New Window");
        newWinDrawerBtn.setOnClickListener(v -> {
            closeDrawer();
            addNewWindow();
        });
        LinearLayout.LayoutParams nwParams = new LinearLayout.LayoutParams(-1, -2);
        nwParams.topMargin = dp(8);
        drawerPanel.addView(newWinDrawerBtn, nwParams);

        Button pkgDrawerBtn = chipButton("Install Package (pkg)");
        pkgDrawerBtn.setOnClickListener(v -> {
            closeDrawer();
            showPackageInstallerDialog();
        });
        LinearLayout.LayoutParams pkgParams = new LinearLayout.LayoutParams(-1, -2);
        pkgParams.topMargin = dp(6);
        drawerPanel.addView(pkgDrawerBtn, pkgParams);

        appSearch = new EditText(this);
        appSearch.setSingleLine(true);
        appSearch.setTextSize(14);
        appSearch.setHint("Search installed apps...");
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, -2);
        searchParams.topMargin = dp(10);
        drawerPanel.addView(appSearch, searchParams);

        ScrollView appScroll = new ScrollView(this);
        launchableApps = getLaunchableApps();
        appRows = new LinearLayout(this);
        appRows.setOrientation(LinearLayout.VERTICAL);
        appScroll.addView(appRows, new ScrollView.LayoutParams(-1, -2));
        drawerPanel.addView(appScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        appSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderAppRows(s.toString());
            }
            public void afterTextChanged(Editable e) { }
        });

        Button termux = chipButton("TERMUX CONNECTION");
        termux.setOnClickListener(v -> {
            closeDrawer();
            connectTermux();
        });
        drawerPanel.addView(termux, new LinearLayout.LayoutParams(-1, -2));
        renderAppRows("");
    }

    private void listTermuxProcesses() {
        input.setText("ps -u \"$(id -u)\" -o pid=,comm= | sort -n");
        runCommand();
    }

    private void showPackageInstallerDialog() {
        EditText packageInput = new EditText(this);
        packageInput.setSingleLine(true);
        packageInput.setHint("e.g. nano, git, python");
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        box.addView(packageInput, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
            .setTitle("Install Termux package")
            .setMessage("Runs pkg install with interactive [Y/n] confirmation.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Install", (dialog, which) -> {
                String name = packageInput.getText().toString().trim();
                if (!name.matches("[A-Za-z0-9][A-Za-z0-9+._-]*")) {
                    Toast.makeText(this, "Enter a valid package name.", Toast.LENGTH_SHORT).show();
                    return;
                }
                input.setText("pkg install " + name);
                runCommand();
            })
            .show();
    }

    private List<AppEntry> getLaunchableApps() {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(query, 0);
        LinkedHashMap<String, AppEntry> unique = new LinkedHashMap<>();
        for (ResolveInfo info : found) {
            String pkg = info.activityInfo.packageName;
            if (!unique.containsKey(pkg)) {
                String label = info.loadLabel(getPackageManager()).toString();
                unique.put(pkg, new AppEntry(label, pkg, info.loadIcon(getPackageManager())));
            }
        }
        ArrayList<AppEntry> apps = new ArrayList<>(unique.values());
        Collections.sort(apps, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return apps;
    }

    private void renderAppRows(String filter) {
        if (appRows == null || launchableApps == null) return;
        appRows.removeAllViews();
        String needle = filter.trim().toLowerCase();
        for (AppEntry app : launchableApps) {
            if (!app.label.toLowerCase().contains(needle)) continue;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6), dp(6), dp(6), dp(6));

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(app.icon);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(34), dp(34));
            iconParams.rightMargin = dp(10);
            row.addView(icon, iconParams);

            TextView label = new TextView(this);
            label.setText(app.label);
            label.setTextColor(0xFFFFFFFF);
            label.setTextSize(14);
            label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));

            row.setOnClickListener(v -> {
                closeDrawer();
                Intent launch = getPackageManager().getLaunchIntentForPackage(app.packageName);
                if (launch != null) startActivity(launch);
                else Toast.makeText(this, "App cannot be opened.", Toast.LENGTH_SHORT).show();
            });
            appRows.addView(row);
        }
    }

    private void openDrawer() {
        drawerOpen = true;
        drawerScrim.setVisibility(View.VISIBLE);
        drawerScrim.animate().alpha(1f).setDuration(180).start();
        drawerPanel.animate().translationX(0).setDuration(220).start();
        appSearch.setText("");
    }

    private void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        drawerPanel.animate().translationX(-drawerWidth).setDuration(200).start();
        drawerScrim.animate().alpha(0f).setDuration(180).withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
    }

    @Override
    public void onBackPressed() {
        if (drawerOpen) closeDrawer();
        else super.onBackPressed();
    }

    private void loadCustomCommands() {
        try {
            JSONArray data = new JSONArray(preferences.getString("custom_commands", "[]"));
            for (int i = 0; i < data.length(); i++) {
                JSONObject item = data.getJSONObject(i);
                customCommands.add(new CustomCommand(item.getString("name"), item.getString("command")));
            }
        } catch (Exception ignored) {
            customCommands.clear();
        }
    }

    private void saveCustomCommands() {
        JSONArray data = new JSONArray();
        for (CustomCommand item : customCommands) {
            JSONObject row = new JSONObject();
            try {
                row.put("name", item.name);
                row.put("command", item.command);
                data.put(row);
            } catch (Exception ignored) { }
        }
        preferences.edit().putString("custom_commands", data.toString()).apply();
        renderCustomCommands();
    }

    private void renderCustomCommands() {
        if (customChips == null) return;
        customChips.removeAllViews();
        for (CustomCommand item : customCommands) {
            LinearLayout pair = new LinearLayout(this);
            pair.setGravity(Gravity.CENTER_VERTICAL);
            Button run = chipButton(item.name);
            run.setOnClickListener(v -> {
                input.setText(item.command);
                runCommand();
            });
            pair.addView(run);
            Button delete = chipButton("×");
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Delete shortcut?")
                .setMessage(item.name)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    customCommands.remove(item);
                    saveCustomCommands();
                })
                .show());
            pair.addView(delete);
            customChips.addView(pair);
        }
        applyStyle();
    }

    private void showAddCustomDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), dp(2));
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Shortcut name");
        box.addView(name);
        EditText command = new EditText(this);
        command.setSingleLine(true);
        command.setHint("Termux command");
        box.addView(command);
        new AlertDialog.Builder(this)
            .setTitle("Add custom command")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add", (dialog, which) -> {
                String label = name.getText().toString().trim();
                String value = command.getText().toString().trim();
                if (label.isEmpty() || value.isEmpty()) {
                    Toast.makeText(this, "Enter both a name and command.", Toast.LENGTH_SHORT).show();
                    return;
                }
                customCommands.add(new CustomCommand(label, value));
                saveCustomCommands();
            })
            .show();
    }

    private void connectTermux() {
        TerminalWindow w = currentWindow();
        try {
            getPackageManager().getPackageInfo(TERMUX_PACKAGE, 0);
        } catch (PackageManager.NameNotFoundException e) {
            appendToWindow(w, "Termux is not installed. Install Termux first.\n");
            return;
        }
        if (checkSelfPermission(RUN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            appendToWindow(w, "Approve 'Run commands in Termux environment' for termux-vision in Android App info.\n");
            requestPermissions(new String[]{RUN_PERMISSION}, 22);
            return;
        }
        appendToWindow(w, "Termux connection ready.\n");
    }

    @Override
    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        TerminalWindow w = currentWindow();
        if (request == 22 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            appendToWindow(w, "Termux command permission granted.\n");
        } else if (request == 22) {
            appendToWindow(w, "Permission not granted. Open Android Settings > Apps > termux-vision > Permissions.\n");
        }
    }

    /**
     * Checks if command is a `pkg install <pkg>` or `apt install <pkg>` without `-y` / `--yes`.
     * Because Termux RUN_COMMAND runs non-interactively, `pkg install` normally auto-aborts
     * or hides the `[Y/n]` prompt when stdin is closed. We simulate a real interactive `[Y/n]`
     * prompt first so the user always sees and confirms `Do you want to continue? [Y/n]`.
     */
    private String extractInteractiveInstallTarget(String command) {
        String trimmed = command.trim();
        if (trimmed.contains(" -y") || trimmed.contains(" --yes") || trimmed.startsWith("yes ")) {
            return null;
        }
        Pattern p = Pattern.compile("^(?:pkg|apt|apt-get)\\s+install\\s+(.+)$");
        Matcher m = p.matcher(trimmed);
        if (m.matches()) {
            return m.group(1).trim();
        }
        return null;
    }

    private void runCommand() {
        TerminalWindow w = currentWindow();
        if (w == null) return;

        String command = input.getText().toString().trim();
        if (command.isEmpty()) {
            appendToWindow(w, formatShellPrompt(w) + "\n");
            return;
        }
        if (w.commandRunning) {
            Toast.makeText(this, "Command is still running...", Toast.LENGTH_SHORT).show();
            return;
        }

        input.setText("");
        appendToWindow(w, formatShellPrompt(w) + command + "\n");

        if (command.equals("help")) {
            appendToWindow(w,
                "Built-in commands:\n" +
                "  cd <dir>          Change working directory\n" +
                "  clear             Clear terminal screen\n" +
                "  history           Show command history\n" +
                "  pkg install <pkg> Install Termux package with [Y/n] confirmation\n" +
                "Tip: Tap ⋮ (top right) to toggle Quick Toolbar, Wallpaper, or Preferences.\n");
            return;
        }
        if (command.equals("clear")) {
            clearCurrentWindow();
            return;
        }
        if (command.equals("history")) {
            showHistory();
            return;
        }
        if (command.equals("cd") || command.startsWith("cd ")) {
            String path = command.length() == 2 ? DEFAULT_HOME : command.substring(3).trim();
            if ((path.startsWith("\"") && path.endsWith("\"")) || (path.startsWith("'") && path.endsWith("'"))) {
                if (path.length() >= 2) path = path.substring(1, path.length() - 1);
            }
            try {
                String resolved = path;
                if ("~".equals(resolved) || resolved.isEmpty()) resolved = DEFAULT_HOME;
                else if (resolved.startsWith("~/")) resolved = DEFAULT_HOME + "/" + resolved.substring(2);
                File next = new File(resolved);
                if (!next.isAbsolute()) next = new File(w.workingDir, resolved);
                w.workingDir = next.getCanonicalFile();
                preferences.edit().putString("working_directory", w.workingDir.getAbsolutePath()).apply();
                updateInputState();
            } catch (Exception e) {
                appendToWindow(w, "cd: " + e.getMessage() + "\n");
            }
            rememberCommand(command);
            return;
        }

        if (checkSelfPermission(RUN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            appendToWindow(w, "Termux permission required. Tap ⋮ > Termux Connection first.\n");
            return;
        }

        rememberCommand(command);

        // Handle interactive `pkg install <pkg>` [Y/n] confirmation prompt!
        String installTarget = extractInteractiveInstallTarget(command);
        if (installTarget != null) {
            w.pendingInstallPackage = installTarget;
            w.awaitingConfirm = true;
            String promptMsg = "After this operation, additional disk space will be used.\nDo you want to continue? [Y/n] ";
            w.confirmPromptText = "Do you want to continue? [Y/n]";
            appendToWindow(w, "Checking availability of current mirror...\nReading package lists... Done\nBuilding dependency tree... Done\nThe following NEW packages will be installed:\n  " + installTarget + "\n" + promptMsg);
            if (w == currentWindow()) {
                showConfirmBanner(w.confirmPromptText);
                updateInputState();
                focusTerminalInput();
            }
            return;
        }

        executeTermuxShellCommand(w, command, true);
    }

    private void executeTermuxShellCommand(TerminalWindow w, String command, boolean showLiveTag) {
        w.activeSessionToken = UUID.randomUUID().toString().replace("-", "");
        w.activeSessionReceivedLines = false;
        w.commandRunning = true;
        if (w == currentWindow()) {
            updateInputState();
        }
        commandHandler.removeCallbacks(commandTimeout);
        commandHandler.postDelayed(commandTimeout, 180000L);

        try {
            int id = executionIds.incrementAndGet();
            Intent callback = new Intent(this, TermuxResultService.class);
            callback.putExtra("session_token", w.activeSessionToken);
            int piFlags = PendingIntent.FLAG_ONE_SHOT;
            if (Build.VERSION.SDK_INT >= 31) piFlags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent resultIntent = PendingIntent.getService(this, id, callback, piFlags);

            String quote = Character.toString((char) 34);
            // Force unbuffered output + capture prompts even without trailing newline
            String script = "{\n" + command + "\n} </dev/null 2>&1 | while IFS= read -r line || [ -n " + quote + "$line" + quote + " ]; do\n"
                + "safe_line=$(printf '%s' " + quote + "$line" + quote + " | sed \"s/'/'\\\\''/g\")\n"
                + "/data/data/com.termux/files/usr/bin/am broadcast -n com.example.customterminal/.TermuxLogReceiver -a com.example.customterminal.TERMUX_LOG --es session_token '" + w.activeSessionToken + "' --es line \"'$safe_line'\" >/dev/null 2>&1\n"
                + "printf '%s\\n' " + quote + "$line" + quote + "\n"
                + "done\ncommand_status=${PIPESTATUS[0]}\nexit " + quote + "$command_status" + quote;

            Intent intent = new Intent("com.termux.RUN_COMMAND");
            intent.setClassName(TERMUX_PACKAGE, "com.termux.app.RunCommandService");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", script});
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", w.workingDir.getAbsolutePath());
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            intent.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", "termux-vision command");
            intent.putExtra("com.termux.RUN_COMMAND_COMMAND_DESCRIPTION", "Command submitted from termux-vision");
            intent.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", resultIntent);

            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    startService(intent);
                } catch (IllegalStateException fgEx) {
                    startForegroundService(intent);
                }
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            appendToWindow(w, "Could not start Termux command: " + e.getMessage() + "\nCheck permission and allow-external-apps.\n");
            w.activeSessionToken = null;
            w.commandRunning = false;
            commandHandler.removeCallbacks(commandTimeout);
            if (w == currentWindow()) updateInputState();
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        commandHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
