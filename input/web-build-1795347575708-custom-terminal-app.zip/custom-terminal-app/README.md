# termux-vision (v3 — TermOne Plus UI & Interactive Package Confirmation)

Clean classic terminal UI inspired by TermOne Plus with multi-window support, inline shell prompt, and interactive `[Y/n]` confirmation for `pkg install`.

## Build Instructions
- **Android Studio**: Extract the ZIP, click `File > Open`, select `custom-terminal-app`, and build.
- **AIDE (Android IDE)**: Extract to `/storage/emulated/0/AppProjects/custom-terminal-app`, open in AIDE, and tap **Run**.
