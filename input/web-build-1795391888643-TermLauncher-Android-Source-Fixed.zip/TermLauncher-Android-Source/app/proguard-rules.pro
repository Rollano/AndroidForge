# TermLauncher ProGuard rules
# Keep default Android and AndroidX shrinking behavior; minification is disabled.
