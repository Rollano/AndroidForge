#!/data/data/com.termux/files/usr/bin/sh
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SDK_DIR="${ANDROID_SDK_ROOT:-$HOME/android-sdk}"
BUILD="$PROJECT_DIR/build-manual"
ANDROID_JAR="$SDK_DIR/platforms/android-35/android.jar"
[ -f "$ANDROID_JAR" ] || { echo "Missing $ANDROID_JAR" >&2; exit 1; }
rm -rf "$BUILD"
mkdir -p "$BUILD/classes" "$BUILD/dex"
aapt2 compile --dir "$PROJECT_DIR/app/src/main/res" -o "$BUILD/resources.zip"
aapt2 link --manifest "$PROJECT_DIR/app/src/main/AndroidManifest.xml" -R "$BUILD/resources.zip" -I "$ANDROID_JAR" --min-sdk-version 23 --target-sdk-version 28 --version-code 1 --version-name 1.0 -o "$BUILD/app-unsigned.apk"
javac -source 8 -target 8 -classpath "$ANDROID_JAR" -d "$BUILD/classes" "$PROJECT_DIR/app/src/main/java/com/example/customterminal/MainActivity.java" "$PROJECT_DIR/app/src/main/java/com/example/customterminal/TermuxResultService.java" "$PROJECT_DIR/app/src/main/java/com/example/customterminal/TermuxLogReceiver.java"
set -- "$BUILD"/classes/com/example/customterminal/*.class
d8 --lib "$ANDROID_JAR" --min-api 23 --output "$BUILD/dex" "$@"
(cd "$BUILD/dex" && zip -q "$BUILD/app-unsigned.apk" classes.dex)
if [ ! -f "$PROJECT_DIR/debug.keystore" ]; then keytool -genkeypair -keystore "$PROJECT_DIR/debug.keystore" -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Android Debug,O=Android,C=US' >/dev/null 2>&1; fi
apksigner sign --ks "$PROJECT_DIR/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$BUILD/termux-vision-debug.apk" "$BUILD/app-unsigned.apk"
apksigner verify "$BUILD/termux-vision-debug.apk"
ls -lh "$BUILD/termux-vision-debug.apk"
