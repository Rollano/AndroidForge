package com.example.customterminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final String TERMUX_PACKAGE="com.termux";
    private static final AtomicInteger ids=new AtomicInteger(1000);
    private static volatile MainActivity active;
    private String session;
    private boolean receivedLines;
    private TextView terminalOutput;
    private EditText commandInput;
    private Button runBtn;
    private Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable timeout=()->{ if(runBtn!=null){appendTerminal("[Command timed out waiting for callback; it may still be running.]\n");runBtn.setEnabled(true);} session=null;};
    private int bg=Color.rgb(13,17,23), panel=Color.rgb(22,27,34), accent=Color.rgb(61,220,151), fg=Color.rgb(230,237,243), muted=Color.rgb(139,148,158);

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);build();}
    @Override protected void onResume(){super.onResume();active=this;}
    @Override protected void onPause(){if(active==this)active=null;super.onPause();}
    static void receiveTermuxLog(String token,String line){MainActivity a=active;if(a!=null&&token.equals(a.session))a.runOnUiThread(()->{if(token.equals(a.session)){a.receivedLines=true;a.appendTerminal(line+"\n");}});}
    static void receiveTermuxResult(String token,String text,int code){MainActivity a=active;if(a!=null)a.runOnUiThread(()->{if(token==null||!token.equals(a.session))return;if(!a.receivedLines&&text!=null)a.appendTerminal(text);a.appendTerminal("[exit "+code+"]\n");a.session=null;a.handler.removeCallbacks(a.timeout);a.runBtn.setEnabled(true);});}

    private void build(){
        ScrollView outer=new ScrollView(this);outer.setBackgroundColor(bg);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(16),dp(14),dp(16),dp(24));outer.addView(page);
        TextView title=text("ANDROID TOOLKIT",24,fg,true);page.addView(title);
        TextView sub=text("System dashboard • tools • Termux command bridge",12,muted,false);page.addView(sub);
        page.addView(gap(14));
        LinearLayout metrics=new LinearLayout(this);metrics.setOrientation(LinearLayout.VERTICAL);page.addView(metrics);
        metrics.addView(metricCard("DEVICE",Build.MANUFACTURER+" "+Build.MODEL,"Android "+Build.VERSION.RELEASE+" • API "+Build.VERSION.SDK_INT));
        metrics.addView(metricCard("MEMORY",memoryInfo(),"RAM usage estimate"));
        metrics.addView(metricCard("STORAGE",storageInfo(),"Internal storage"));
        metrics.addView(metricCard("ROOT STATUS",rootCheck(),"Local su check (not a guarantee)"));
        page.addView(gap(12));
        page.addView(section("QUICK TOOLS"));
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);page.addView(grid);
        grid.addView(toolRow("System settings","Open Android settings",()->startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS))));
        grid.addView(toolRow("App information","Manage installed apps",()->startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))));
        grid.addView(toolRow("Developer options","Developer settings (if enabled)",()->startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))));
        grid.addView(toolRow("Wi-Fi settings","Manage wireless network",()->startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))));
        grid.addView(toolRow("Installed apps list","View launchable apps",this::showApps));
        page.addView(gap(12));
        page.addView(section("TERMUX COMMAND CONSOLE"));
        TextView note=text("Commands execute through the installed Termux app. This is not an embedded Linux shell. Root commands require a rooted device and appropriate authorization.",12,muted,false);page.addView(note);
        LinearLayout terminal=new LinearLayout(this);terminal.setOrientation(LinearLayout.VERTICAL);terminal.setPadding(dp(12),dp(10),dp(12),dp(10));terminal.setBackground(round(panel,dp(12)));page.addView(terminal);
        terminalOutput=new TextView(this);terminalOutput.setTextColor(accent);terminalOutput.setTypeface(Typeface.MONOSPACE);terminalOutput.setTextSize(12);terminalOutput.setText("toolkit-terminal\nConnects to Termux RUN_COMMAND\n");terminalOutput.setPadding(0,0,0,dp(8));terminal.addView(terminalOutput);
        commandInput=new EditText(this);commandInput.setSingleLine(true);commandInput.setTextColor(fg);commandInput.setHintTextColor(muted);commandInput.setHint("Enter command (e.g. uname -a)");commandInput.setTypeface(Typeface.MONOSPACE);terminal.addView(commandInput);
        runBtn=button("RUN COMMAND");terminal.addView(runBtn);runBtn.setOnClickListener(v->{String cmd=commandInput.getText().toString().trim();if(!cmd.isEmpty())runTermux(cmd);});
        page.addView(gap(8));
        page.addView(toolRow("Refresh dashboard","Update memory and storage",()->build()));
        setContentView(outer);
    }
    private String memoryInfo(){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);long total=mi.totalMem/1048576L,avail=mi.availMem/1048576L;return (total-avail)+" MB used / "+total+" MB total";}
    private String storageInfo(){File p=getFilesDir();long total=p.getTotalSpace()/1073741824L,free=p.getFreeSpace()/1073741824L;return (total-free)+" GB used / "+total+" GB total";}
    private String rootCheck(){return (new File("/system/bin/su").exists()||new File("/system/xbin/su").exists())?"su binary found (verify root authorization)":"No su binary detected";}
    private void showApps(){Intent i=new Intent(Intent.ACTION_MAIN,null);i.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> apps=getPackageManager().queryIntentActivities(i,0);java.util.Collections.sort(apps,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));ArrayList<String> names=new ArrayList<>();for(ResolveInfo r:apps)names.add(r.loadLabel(getPackageManager()).toString());new AlertDialog.Builder(this).setTitle("Launchable apps (tap to open)").setItems(names.toArray(new String[0]),(d,w)->{String pkg=apps.get(w).activityInfo.packageName;Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null)startActivity(launch);}).setPositiveButton("Close",null).show();}
    private boolean termuxInstalled(){try{getPackageManager().getPackageInfo(TERMUX_PACKAGE,0);return true;}catch(Exception e){return false;}}
    private void runTermux(String command){if(!termuxInstalled()){new AlertDialog.Builder(this).setMessage("Termux is not installed. Install Termux, enable allow-external-apps in its settings, then retry.").setPositiveButton("OK",null).show();return;}session="s"+ids.incrementAndGet();receivedLines=false;runBtn.setEnabled(false);terminalOutput.append("\n$ "+command+"\n");handler.removeCallbacks(timeout);handler.postDelayed(timeout,120000);
        try{int id=ids.incrementAndGet();Intent callback=new Intent(this,TermuxResultService.class);callback.putExtra("session_token",session);int flags=PendingIntent.FLAG_ONE_SHOT;if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;PendingIntent pi=PendingIntent.getService(this,id,callback,flags);
            Intent run=new Intent("com.termux.RUN_COMMAND");run.setClassName(TERMUX_PACKAGE,"com.termux.app.RunCommandService");run.putExtra("com.termux.RUN_COMMAND_PATH","/data/data/com.termux/files/usr/bin/bash");run.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",new String[]{"-lc",command});run.putExtra("com.termux.RUN_COMMAND_WORKDIR","/data/data/com.termux/files/home");run.putExtra("com.termux.RUN_COMMAND_BACKGROUND",true);run.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL","Android Toolkit");run.putExtra("com.termux.RUN_COMMAND_COMMAND_DESCRIPTION","Command from Android Toolkit");run.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT",pi);startService(run);
        }catch(Exception e){appendTerminal("Start failed: "+e.getMessage()+"\nCheck Termux external command permissions.\n");session=null;runBtn.setEnabled(true);handler.removeCallbacks(timeout);}}
    private void appendTerminal(String s){terminalOutput.append(s);if(terminalOutput.length()>14000)terminalOutput.setText(terminalOutput.getText().subSequence(terminalOutput.length()-10000,terminalOutput.length()));}
    private LinearLayout metricCard(String label,String value,String detail){LinearLayout c=card();c.addView(text(label,11,accent,true));c.addView(text(value,17,fg,true));c.addView(text(detail,11,muted,false));return c;}
    private LinearLayout toolRow(String name,String detail,Runnable action){LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);left.addView(text(name,15,fg,true));left.addView(text(detail,11,muted,false));c.addView(left,new LinearLayout.LayoutParams(0,-2,1));Button b=button("OPEN");c.addView(b);c.setOnClickListener(v->action.run());b.setOnClickListener(v->action.run());return c;}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(11),dp(12),dp(11));c.setBackground(round(panel,dp(12)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(8);c.setLayoutParams(lp);return c;}
    private TextView section(String s){TextView t=text(s,13,accent,true);t.setPadding(0,0,0,dp(8));return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(accent);return b;}
    private View gap(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
