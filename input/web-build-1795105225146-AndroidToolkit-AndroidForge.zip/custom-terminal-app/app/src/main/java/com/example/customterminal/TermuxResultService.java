package com.example.customterminal;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;

public class TermuxResultService extends IntentService {
    public TermuxResultService() { super("TermuxResultService"); }

    @Override protected void onHandleIntent(Intent intent) {
        if (intent == null) return;
        String token = intent.getStringExtra("session_token");
        Bundle result = intent.getBundleExtra("result");
        if (result == null) {
            MainActivity.receiveTermuxResult(token, "No result received. Check Termux and allow-external-apps.\n", -1);
            return;
        }
        String stdout = result.getString("stdout", "");
        String stderr = result.getString("stderr", "");
        int exit = result.getInt("exitCode", -1);
        String error = result.getString("errmsg", "");
        String text = stdout + (stderr.isEmpty() ? "" : stderr) + (error.isEmpty() ? "" : "Termux: " + error + "\n");
        MainActivity.receiveTermuxResult(token, text, exit);
    }
}
