# Android Toolkit

Dark system dashboard and quick settings launcher with a Termux command bridge.

Features: device model/Android version, RAM and storage estimates, root binary presence check, shortcuts to Android settings/apps/developer settings/Wi-Fi, launchable apps list, and optional Termux RUN_COMMAND console.

Build with AndroidForge or the included GitHub Actions workflow. SDK 35, minimum Android 6 (API 23).

Termux bridge: install Termux, enable `allow-external-apps` in `~/.termux/termux.properties`, restart Termux, and grant RUN_COMMAND permission if prompted. Commands run as Termux user, not automatically as root.
