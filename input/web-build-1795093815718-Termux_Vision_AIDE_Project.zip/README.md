# Termux Vision — AIDE Android Project

A portrait-mode Android shell dashboard with a Kali-inspired black/neon-green UI.

## Included in this starter
- Home dashboard
- App Drawer that lists launchable Android apps and opens them
- Terminal screen with live command output
- Optional `su -c` execution toggle
- Basic shared-storage browser
- Device/RAM information screen
- Package Manager screen with an honest runtime status notice

## Important runtime limitation
This project does **not** bundle a Linux distribution, `proot`, or an APT repository. Android's built-in `/system/bin/sh` is not a Linux distro shell, so commands such as `apt`, `dpkg`, or Kali tools will not exist until a compatible ARM64 rootfs and proot runtime are installed and integrated. The Packages screen intentionally does not pretend APT is already working.

Root mode runs each command as `su -c <command>` and requires a working root manager. Use it carefully.

## Build
Open this folder as an Android Gradle project in a compatible AIDE version or Android Studio.
- Namespace/application ID: `com.termuxvision`
- minSdk: 23
- compileSdk: 35
- AGP: 8.6.1

AIDE versions differ in Gradle/AGP support. If your AIDE cannot sync AGP 8.6.1, tell me the exact sync error and AIDE version so the project can be adjusted to that toolchain.

## Notes
- The app is an in-app dashboard, not yet registered as the Android default Home app.
- App Drawer visibility is subject to Android package visibility and device policy.
- Shared storage browsing may be restricted by Android scoped-storage rules.
- No command is executed automatically at startup.
