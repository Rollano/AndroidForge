package com.termuxvision;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 9, 7);
    private final int PANEL = Color.rgb(13, 23, 17);
    private final int GREEN = Color.rgb(57, 255, 114);
    private final int MUTED = Color.rgb(151, 190, 162);
    private LinearLayout root, content, nav;
    private TextView terminalOutput;
    private EditText commandInput;
    private boolean useRoot = false;
    private final String[] shortcuts = {"Terminal","App Drawer","Packages","Files","Monitor","Settings"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showHome();
    }

    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(14));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); t.setTypeface(Typeface.MONOSPACE, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(dp(3),dp(3),dp(3),dp(3)); return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void init(String title) {
        root = column(); root.setBackgroundColor(BG);
        TextView bar = text("  ◈  TERMUX VISION     /     " + title.toUpperCase(), 15, GREEN, true);
        bar.setPadding(dp(16),dp(18),dp(12),dp(18)); bar.setBackgroundColor(PANEL);
        root.addView(bar, new LinearLayout.LayoutParams(-1,-2));
        ScrollView sc = new ScrollView(this);
        content = column(); content.setPadding(dp(14),dp(14),dp(14),dp(18));
        sc.addView(content); root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));
        nav = row(); nav.setPadding(dp(4),dp(6),dp(4),dp(6)); nav.setBackgroundColor(PANEL);
        addNav("⌂","Home", this::showHome);
        addNav("▦","Apps", this::showDrawer);
        addNav(">_","Terminal", this::showTerminal);
        addNav("⚙","Settings", this::showSettings);
        root.addView(nav); setContentView(root);
    }
    private void addNav(String icon, String label, Runnable action) {
        LinearLayout item = column(); item.setGravity(Gravity.CENTER);
        TextView t = text(icon+"\n"+label,11,GREEN,true); t.setGravity(Gravity.CENTER);
        item.addView(t); item.setPadding(dp(8),dp(3),dp(8),dp(3));
        item.setOnClickListener(v -> action.run());
        nav.addView(item,new LinearLayout.LayoutParams(0,-2,1));
    }
    private void heading(String s) { TextView t=text(s,19,GREEN,true); t.setPadding(0,dp(10),0,dp(8)); content.addView(t); }
    private void paragraph(String s) { TextView t=text(s,12,MUTED,false); content.addView(t); }
    private void card(String title, String sub, Runnable action) {
        LinearLayout c=column(); c.setPadding(dp(14),dp(12),dp(14),dp(12)); c.setBackground(bg(PANEL,GREEN));
        TextView a=text(title,15,GREEN,true); TextView b=text(sub,11,MUTED,false);
        c.addView(a); c.addView(b); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(5),0,dp(5));
        content.addView(c,p); c.setOnClickListener(v->action.run());
    }
    private void showHome() {
        init("Home");
        heading("WELCOME BACK");
        TextView logo=text("TERMUX\nVISION",32,GREEN,true); logo.setGravity(Gravity.CENTER);
        logo.setPadding(0,dp(18),0,dp(18)); content.addView(logo);
        paragraph("LINUX ENVIRONMENT  •  ANDROID COMMAND CENTER");
        heading("SYSTEM OVERVIEW");
        card("DEVICE INFORMATION", "Android "+Build.VERSION.RELEASE+"  |  "+Build.SUPPORTED_ABIS[0], this::showMonitor);
        card("TERMINAL", "Run Android shell commands with live output", this::showTerminal);
        card("APP DRAWER", "Browse and launch installed Android applications", this::showDrawer);
        card("LINUX PACKAGES", "APT requires a configured Linux root filesystem", this::showPackages);
        card("FILE MANAGER", "Browse shared storage", this::showFiles);
        card("SYSTEM MONITOR", "Memory and device information", this::showMonitor);
    }
    private void showDrawer() {
        init("App Drawer"); heading("APPLICATION DRAWER");
        EditText search=new EditText(this); search.setSingleLine(true); search.setHint("Search installed apps...");
        search.setTextColor(GREEN); search.setHintTextColor(MUTED); search.setBackground(bg(PANEL,GREEN));
        content.addView(search);
        LinearLayout list=column(); content.addView(list);
        ArrayList<ApplicationInfo> apps=new ArrayList<>();
        PackageManager pm=getPackageManager();
        for(ApplicationInfo ai:pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
            if(pm.getLaunchIntentForPackage(ai.packageName)!=null) apps.add(ai);
        }
        Collections.sort(apps,(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        Runnable render=()->{
            list.removeAllViews(); String q=search.getText().toString().toLowerCase(Locale.ROOT);
            for(ApplicationInfo ai:apps) {
                String name=pm.getApplicationLabel(ai).toString();
                if(!name.toLowerCase(Locale.ROOT).contains(q)) continue;
                LinearLayout r=row(); r.setPadding(dp(10),dp(9),dp(10),dp(9)); r.setBackground(bg(PANEL,Color.rgb(25,70,42)));
                ImageView icon=new ImageView(this); icon.setImageDrawable(pm.getApplicationIcon(ai));
                r.addView(icon,new LinearLayout.LayoutParams(dp(38),dp(38)));
                TextView label=text(name+"\n"+ai.packageName,12,GREEN,true);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(10),0,0,0); r.addView(label,lp);
                r.setOnClickListener(v->{ Intent in=pm.getLaunchIntentForPackage(ai.packageName); if(in!=null) startActivity(in); });
                LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.setMargins(0,dp(4),0,dp(4)); list.addView(r,rp);
            }
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){render.run();} public void afterTextChanged(android.text.Editable e){}});
        render.run();
    }
    private void showTerminal() {
        init("Terminal"); heading("ANDROID SHELL");
        paragraph("Commands run through /system/bin/sh. Enable root to run through su.");
        Switch sw=new Switch(this); sw.setText(" Run commands as root (su)"); sw.setTextColor(GREEN); sw.setChecked(useRoot);
        sw.setOnCheckedChangeListener((b,c)->useRoot=c); content.addView(sw);
        terminalOutput=text("Termux Vision shell ready.\nType 'help' for examples.\n\n",12,GREEN,false);
        terminalOutput.setBackground(bg(Color.BLACK,GREEN)); terminalOutput.setPadding(dp(10),dp(10),dp(10),dp(10));
        content.addView(terminalOutput,new LinearLayout.LayoutParams(-1,dp(280)));
        LinearLayout inputRow=row();
        commandInput=new EditText(this); commandInput.setSingleLine(true); commandInput.setTextColor(GREEN); commandInput.setHintTextColor(MUTED); commandInput.setHint("command...");
        commandInput.setBackground(bg(PANEL,GREEN)); inputRow.addView(commandInput,new LinearLayout.LayoutParams(0,-2,1));
        Button run=new Button(this); run.setText("RUN"); run.setTextColor(Color.BLACK); run.setBackgroundColor(GREEN);
        inputRow.addView(run); content.addView(inputRow);
        run.setOnClickListener(v->executeCommand());
        commandInput.setOnEditorActionListener((v,a,e)->{executeCommand();return true;});
        card("Clear output","Clear terminal screen",()->terminalOutput.setText(""));
    }
    private void executeCommand() {
        String cmd=commandInput.getText().toString().trim(); if(cmd.isEmpty()) return;
        commandInput.setText(""); terminalOutput.append("$ "+cmd+"\n");
        new Thread(()->{
            Process p=null;
            try {
                if(useRoot) {
                    p=new ProcessBuilder("su","-c",cmd).redirectErrorStream(true).start();
                } else {
                    p=new ProcessBuilder("/system/bin/sh","-c",cmd).redirectErrorStream(true).start();
                }
                BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line; while((line=br.readLine())!=null) {
                    final String out=line+"\n"; runOnUiThread(()->terminalOutput.append(out));
                }
                int code=p.waitFor(); final String end="[exit "+code+"]\n\n";
                runOnUiThread(()->terminalOutput.append(end));
            } catch(Exception ex) {
                final String err="[error] "+ex.getMessage()+"\n\n"; runOnUiThread(()->terminalOutput.append(err));
            } finally { if(p!=null) p.destroy(); }
        }).start();
    }
    private void showPackages() {
        init("Packages"); heading("PACKAGE MANAGER");
        paragraph("APT is not an Android command. It becomes available after installing a Debian/Kali/Ubuntu ARM64 rootfs and a compatible proot runtime.");
        card("Runtime status","No Linux rootfs is bundled in this starter project.",()->{});
        card("Open terminal","Use Android shell commands for now.",this::showTerminal);
        card("Setup notes","See README in the project ZIP for the next integration steps.",()->{});
    }
    private void showFiles() {
        init("Files"); heading("SHARED STORAGE");
        paragraph("Files visible to this app depend on Android storage permissions.");
        File dir=Environment.getExternalStorageDirectory();
        listFiles(dir,0);
    }
    private void listFiles(File dir,int depth) {
        if(depth>2) return;
        File[] fs=dir.listFiles(); if(fs==null){paragraph("Cannot read: "+dir.getAbsolutePath());return;}
        Arrays.sort(fs,(a,b)->Boolean.compare(!a.isDirectory(),!b.isDirectory()));
        for(File f:fs) {
            String name=(f.isDirectory()?"[DIR]  ":"[FILE] ")+f.getName();
            TextView t=text(name,12,f.isDirectory()?GREEN:MUTED,false);
            t.setPadding(dp(8),dp(8),dp(8),dp(8)); content.addView(t);
            if(f.isDirectory()) t.setOnClickListener(v->{content.removeAllViews();heading(f.getAbsolutePath());listFiles(f,depth+1);});
        }
    }
    private void showMonitor() {
        init("Monitor"); heading("SYSTEM MONITOR");
        ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
        paragraph("DEVICE: "+Build.MANUFACTURER+" "+Build.MODEL);
        paragraph("ANDROID: "+Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")");
        paragraph("ABI: "+Arrays.toString(Build.SUPPORTED_ABIS));
        paragraph("RAM TOTAL: "+(mi.totalMem/1024/1024)+" MB");
        paragraph("RAM AVAILABLE: "+(mi.availMem/1024/1024)+" MB");
        paragraph("ROOT STATUS: "+(new File("/system/bin/su").exists()?"su binary detected (not verified)":"su not detected at /system/bin/su"));
    }
    private void showSettings() {
        init("Settings"); heading("SETTINGS");
        Switch rootSwitch=new Switch(this); rootSwitch.setText(" Default root command mode"); rootSwitch.setTextColor(GREEN); rootSwitch.setChecked(useRoot);
        rootSwitch.setOnCheckedChangeListener((b,c)->useRoot=c); content.addView(rootSwitch);
        paragraph("Theme: Kali Dark / Neon Green");
        paragraph("Orientation: Portrait");
        paragraph("Launcher mode: In-app dashboard. Android default-home replacement is not enabled in this starter.");
        paragraph("Safety: Root commands can modify or damage your device. Review commands before running.");
    }
}
