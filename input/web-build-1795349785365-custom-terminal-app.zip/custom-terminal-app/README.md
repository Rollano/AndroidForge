# termux-vision (v13 — Gradle 7.6.3 + AGP 7.4.2 AndroidForge Build Compatibility)

Uses Gradle `7.6.3` and AGP `7.4.2` with `compileSdkVersion 33`, `minSdkVersion 23`, `targetSdkVersion 28`, and guards `startForegroundService` with `Build.VERSION_CODES.O`.
