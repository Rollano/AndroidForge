# Kali Pocket

AIDE-compatible Android Java + XML security toolkit.

## Modules
- Terminal with optional Magisk/Superuser execution
- Authorized local Wi-Fi /24 host discovery
- Read-only security audit
- System monitor
- File metadata and SHA-256 analyzer
- Recent logcat viewer (Android access restrictions apply)
- ADB command reference
- Script runner with execution confirmation

## Build
Open the project root in Android Studio or a compatible AIDE Gradle importer. Compile SDK 35, min SDK 23, target SDK 28. Root features require a rooted device and explicit Superuser approval.

Only test networks and devices you own or are authorized to assess. No exploit or bypass functionality is included.
