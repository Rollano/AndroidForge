package com.kalipocket;

import android.app.*;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;

public class MainActivity extends Activity {
    interface TextAction { void accept(String value); }
    LinearLayout modules; TextView output, status; boolean rootMode=false;

    public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        modules=findViewById(R.id.modulesContainer); output=findViewById(R.id.outputText); status=findViewById(R.id.statusText);
        status.setText("DEVICE • "+Build.MANUFACTURER+" "+Build.MODEL+"\nANDROID • "+Build.VERSION.RELEASE+" | API "+Build.VERSION.SDK_INT);
        add("01  TERMINAL","Shell commands; optional root",()->terminal());
        add("02  NETWORK SCANNER","Discover responsive hosts on your authorized local /24",()->scan());
        add("03  SECURITY AUDIT","Read-only device security checks",()->audit());
        add("04  SYSTEM MONITOR","Memory, CPU snapshot and uptime",()->monitor());
        add("05  FILE ANALYZER","File metadata and SHA-256",()->file());
        add("06  LOG ANALYZER","Recent logcat output; access may be restricted",()->logs());
        add("07  ADB TOOLS","Safe ADB command reference",()->adb());
        add("08  SCRIPT RUNNER","Run a shell script after confirmation",()->script());
        add("ROOT MODE • OFF","Toggle optional su execution",()->{rootMode=!rootMode; append("Root mode: "+(rootMode?"ON":"OFF"));});
        append("Kali Pocket ready. Authorized testing only.");
    }

    void add(String title,String desc,Runnable run) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(1); card.setPadding(16,13,16,13); card.setBackgroundColor(0xFF111B15);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5);
        TextView t=new TextView(this); t.setText(title); t.setTextColor(0xFF39FF14); t.setTextSize(14); t.setTypeface(null,Typeface.BOLD);
        TextView d=new TextView(this); d.setText(desc); d.setTextColor(0xFF91A596); d.setTextSize(11); d.setPadding(0,5,0,0);
        card.addView(t); card.addView(d); card.setOnClickListener(v->run.run()); modules.addView(card,p);
    }
    void append(String s){runOnUiThread(()->output.append("\n"+s));}
    void ask(String title,String hint,boolean multi,TextAction done){
        EditText e=new EditText(this); e.setTextColor(0xFFE8F5E9); e.setHintTextColor(0xFF91A596); e.setHint(hint); e.setSingleLine(!multi);
        if(multi){e.setMinLines(5);e.setGravity(Gravity.TOP);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);}
        new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("Cancel",null).setPositiveButton("Run",(d,w)->done.accept(e.getText().toString())).show();
    }
    void shell(String cmd){new Thread(()->{
        try{Process p=new ProcessBuilder(rootMode?new String[]{"su","-c",cmd}:new String[]{"sh","-c",cmd}).redirectErrorStream(true).start();
            BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));StringBuilder s=new StringBuilder();String l;
            while((l=r.readLine())!=null)s.append(l).append("\n");int code=p.waitFor();append("$ "+cmd+"\n"+s+"Exit: "+code);
        }catch(Exception e){append("Shell error: "+e.getMessage());}
    }).start();}
    void terminal(){ask("Terminal","id | getprop ro.build.version.release",false,c->{if(!c.trim().isEmpty())shell(c);});}
    String cmd(String c)throws Exception{Process p=new ProcessBuilder("sh","-c",c).redirectErrorStream(true).start();BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l).append("\n");p.waitFor();return b.toString().trim();}
    void audit(){new Thread(()->{try{
        append("=== READ-ONLY SECURITY AUDIT ===\nBuild: "+Build.FINGERPRINT+"\nDebug build: "+(!"user".equals(Build.TYPE))+
        "\nADB enabled: "+(Settings.Global.getInt(getContentResolver(),"adb_enabled",0)==1)+
        "\nSELinux: "+cmd("getenforce")+"\nSu path visible: "+(new File("/system/bin/su").exists()||new File("/system/xbin/su").exists()));
    }catch(Exception e){append("Audit error: "+e.getMessage());}}).start();}
    void monitor(){new Thread(()->{try{append("=== SYSTEM MONITOR ===\n"+cmd("head -n 5 /proc/meminfo")+"\nUptime: "+cmd("cat /proc/uptime")+"\nCPU: "+cmd("head -n 5 /proc/stat")+"\nSELinux: "+cmd("getenforce"));}catch(Exception e){append(e.toString());}}).start();}
    void file(){ask("File Analyzer","/sdcard/Download/file.txt",false,path->new Thread(()->{try{
        File f=new File(path);if(!f.isFile()){append("Not a regular file: "+path);return;}
        MessageDigest md=MessageDigest.getInstance("SHA-256");InputStream in=new FileInputStream(f);byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)md.update(buf,0,n);in.close();
        StringBuilder h=new StringBuilder();for(byte x:md.digest())h.append(String.format("%02x",x));
        append("FILE: "+f.getAbsolutePath()+"\nSIZE: "+f.length()+" bytes\nMODIFIED: "+new Date(f.lastModified())+"\nSHA-256: "+h);
    }catch(Exception e){append("File error: "+e.getMessage());}}).start());}
    void logs(){new AlertDialog.Builder(this).setTitle("Log Analyzer").setMessage("System log access may be blocked. Root mode invokes a Superuser prompt.").setNegativeButton("Cancel",null).setPositiveButton("Read",(d,w)->shell("logcat -d -t 200")).show();}
    void adb(){append("ADB QUICK REFERENCE (run on an authorized host):\nadb devices\nadb shell getprop ro.build.version.release\nadb shell pm list packages\nadb logcat -d -t 200\nThis app does not host an external ADB server.");}
    void script(){ask("Script Runner","echo Hello\nid\ngetprop ro.build.version.release",true,s->{if(s.trim().isEmpty())return;
        new AlertDialog.Builder(this).setTitle("Execute script?").setMessage("Only run scripts you understand and trust. Root mode: "+rootMode).setNegativeButton("Cancel",null).setPositiveButton("I understand",(d,w)->shell(s)).show();});}
    void scan(){new AlertDialog.Builder(this).setTitle("Authorized LAN scan").setMessage("Checks responsive hosts on your current local IPv4 /24. Continue only with permission.").setNegativeButton("Cancel",null).setPositiveButton("Scan",(d,w)->new Thread(()->{
        try{String local=null;Enumeration<NetworkInterface> ns=NetworkInterface.getNetworkInterfaces();
            while(ns.hasMoreElements()){NetworkInterface ni=ns.nextElement();if(!ni.isUp()||ni.isLoopback())continue;Enumeration<InetAddress> as=ni.getInetAddresses();
                while(as.hasMoreElements()){InetAddress a=as.nextElement();if(a instanceof Inet4Address&&!a.isLoopbackAddress()){local=a.getHostAddress();break;}}if(local!=null)break;}
            if(local==null){append("No active IPv4 network.");return;}String[] a=local.split("\\.");if(a.length!=4){append("Invalid IPv4: "+local);return;}
            append("Local IP: "+local+"\nScanning local /24...");
            for(int i=1;i<255;i++){String ip=a[0]+"."+a[1]+"."+a[2]+"."+i;try{if(InetAddress.getByName(ip).isReachable(150))append("Responsive: "+ip);}catch(Exception ignored){}}
            append("Done. Firewalls may hide active hosts.");
        }catch(Exception e){append("Scan error: "+e.getMessage());}
    }).start()).show();}
}
