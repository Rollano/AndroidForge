# termux-vision (v11 — Interactive apt/pkg Install Flow & Built-in Nano Editor)

Supports interactive `[Y/n]` prompt on `apt install <pkg>` / `pkg install <pkg>`, fetches/downloads packages from repository/APT mirrors into the standalone app directory, tracks installed packages in `installed_packages.txt`, and includes a built-in `nano <file>` text editor even without Termux.
