# termux-vision (v17 — Custom Prompt Name, Tutorial Command & Typing Padding Fix)

- Shows `<name>@terminal $ ` instead of long full paths, with a startup dialog asking for your name (plus `setname <name>`).
- Adds `tutorial` command explaining how to use terminal, file/editor, and repository commands.
- Adds clean padding around the typing input and terminal container so text is easy to read while typing.
