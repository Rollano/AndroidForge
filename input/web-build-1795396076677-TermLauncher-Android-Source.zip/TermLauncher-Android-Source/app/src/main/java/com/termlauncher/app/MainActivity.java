package com.termlauncher.app;

import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageView ivWallpaper;
    private View vBgOverlay;
    private LinearLayout rootUiContainer;
    private LinearLayout statusTelemetryBar;
    private TextView tvStatusLeft;
    private TextView tvStatusRight;
    private RelativeLayout topBar;
    private LinearLayout macosDotsContainer;
    private LinearLayout windowSelector;
    private TextView tvWindowTitle;
    private TextView tvZoomBadge;
    private HorizontalScrollView sessionTabsScroll;
    private LinearLayout sessionTabsContainer;
    private LinearLayout terminalFrameBox;
    private TextView tvTerminalOutput;
    private LinearLayout inlinePromptRow;
    private TextView tvPromptTop;
    private TextView tvPrompt;
    private EditText etCommandInput;
    private HorizontalScrollView quickChipsScroll;
    private LinearLayout quickChipsContainer;
    private LinearLayout floatingInputBar;
    private TextView tvFloatingPrompt;
    private EditText etFloatingInput;
    private TextView btnFloatingSend;
    private LinearLayout bottomAppDock;

    private EditText etAppFilter;
    private ScrollView terminalScroll;
    private ListView lvInstalledApps;

    private final List<TerminalSession> sessions = new ArrayList<>();
    private int currentSessionIndex = 0;

    private File appHomeDir;
    private TermuxRepoManager repoManager;
    private CustomizationManager customManager;
    private ScaleGestureDetector scaleGestureDetector;
    private float currentZoomFactor = 1.0f;

    private final Map<String, String> customAliases = new LinkedHashMap<>();
    private SharedPreferences aliasPrefs;
    private MediaPlayer mediaPlayer;
    private String currentTrackName = null;
    private static final int REQ_STORAGE_PERM = 701;
    private static final int REQ_NOTIF_POST_PERM = 702;

    private final List<AppItem> allInstalledApps = new ArrayList<>();
    private final List<AppItem> filteredInstalledApps = new ArrayList<>();
    private AppIconAdapter appIconAdapter;

    private ActivityResultLauncher<String[]> pickWallpaperLauncher;
    private final Handler statusHandler = new Handler(Looper.getMainLooper());
    private final Runnable statusUpdater = new Runnable() {
        @Override
        public void run() {
            updateTelemetryStatus();
            statusHandler.postDelayed(this, 15000);
        }
    };

    private static final String[] QUICK_COMMANDS = {
        "ls -la", "cd ..", "cd ~", "fastfetch", "pkg update", "apps", "customize", "clear"
    };

    public static class AppItem {
        public String label;
        public String packageName;
        public Drawable icon;

        public AppItem(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    private class AppIconAdapter extends ArrayAdapter<AppItem> {
        AppIconAdapter(List<AppItem> items) {
            super(MainActivity.this, R.layout.item_app_icon, items);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView;
            if (row == null) {
                row = LayoutInflater.from(getContext()).inflate(R.layout.item_app_icon, parent, false);
            }
            AppItem item = getItem(position);
            ImageView ivIcon = row.findViewById(R.id.iv_app_icon);
            TextView tvName = row.findViewById(R.id.tv_app_name);
            TextView tvPkg = row.findViewById(R.id.tv_app_pkg);

            if (item != null) {
                ivIcon.setImageDrawable(item.icon);
                tvName.setText(item.label);
                tvPkg.setText(item.packageName);
            }
            return row;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customManager = new CustomizationManager(this);
        aliasPrefs = getSharedPreferences("termlauncher_aliases", MODE_PRIVATE);
        loadAliases();

        pickWallpaperLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri != null) {
                    try {
                        getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                    } catch (Exception ignored) {
                    }
                    if (customManager.saveWallpaperFromUri(uri)) {
                        applyCustomization();
                        Toast.makeText(this, "Wallpaper updated!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to load image.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );

        drawerLayout = findViewById(R.id.drawer_layout);
        ivWallpaper = findViewById(R.id.iv_wallpaper);
        vBgOverlay = findViewById(R.id.v_bg_overlay);
        rootUiContainer = findViewById(R.id.root_ui_container);
        statusTelemetryBar = findViewById(R.id.status_telemetry_bar);
        tvStatusLeft = findViewById(R.id.tv_status_left);
        tvStatusRight = findViewById(R.id.tv_status_right);
        topBar = findViewById(R.id.top_bar);
        macosDotsContainer = findViewById(R.id.macos_dots_container);
        windowSelector = findViewById(R.id.window_selector);
        tvWindowTitle = findViewById(R.id.tv_window_title);
        tvZoomBadge = findViewById(R.id.tv_zoom_badge);
        sessionTabsScroll = findViewById(R.id.session_tabs_scroll);
        sessionTabsContainer = findViewById(R.id.session_tabs_container);
        terminalFrameBox = findViewById(R.id.terminal_frame_box);
        tvTerminalOutput = findViewById(R.id.tv_terminal_output);
        inlinePromptRow = findViewById(R.id.inline_prompt_row);
        tvPromptTop = findViewById(R.id.tv_prompt_top);
        tvPrompt = findViewById(R.id.tv_prompt);
        etCommandInput = findViewById(R.id.et_command_input);
        quickChipsScroll = findViewById(R.id.quick_chips_scroll);
        quickChipsContainer = findViewById(R.id.quick_chips_container);
        floatingInputBar = findViewById(R.id.floating_input_bar);
        tvFloatingPrompt = findViewById(R.id.tv_floating_prompt);
        etFloatingInput = findViewById(R.id.et_floating_input);
        btnFloatingSend = findViewById(R.id.btn_floating_send);
        bottomAppDock = findViewById(R.id.bottom_app_dock);

        etAppFilter = findViewById(R.id.et_app_filter);
        terminalScroll = findViewById(R.id.terminal_scroll);
        lvInstalledApps = findViewById(R.id.lv_installed_apps);

        appHomeDir = getDir("HOME", MODE_PRIVATE);
        repoManager = new TermuxRepoManager(getFilesDir());

        sessions.add(new TerminalSession("Window 1", appHomeDir));
        loadSession(0);

        buildQuickCommandChips();
        setupPinchToZoom();
        loadInstalledApps();
        applyCustomization();

        ImageButton btnMenu = findViewById(R.id.btn_menu);
        btnMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        windowSelector.setOnClickListener(v -> showWindowPicker());

        View dotClose = findViewById(R.id.dot_close);
        if (dotClose != null) {
            dotClose.setOnClickListener(v -> closeCurrentSession());
        }
        View dotMinimize = findViewById(R.id.dot_minimize);
        if (dotMinimize != null) {
            dotMinimize.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        }
        View dotMaximize = findViewById(R.id.dot_maximize);
        if (dotMaximize != null) {
            dotMaximize.setOnClickListener(v -> showCustomizeDialog());
        }

        ImageButton btnNewWindow = findViewById(R.id.btn_new_window);
        btnNewWindow.setOnClickListener(v -> {
            int num = sessions.size() + 1;
            sessions.add(new TerminalSession("Window " + num, appHomeDir));
            loadSession(sessions.size() - 1);
        });

        ImageButton btnCustomize = findViewById(R.id.btn_customize);
        btnCustomize.setOnClickListener(v -> showCustomizeDialog());

        ImageButton btnCloseWindow = findViewById(R.id.btn_close_window);
        btnCloseWindow.setOnClickListener(v -> closeCurrentSession());

        ImageButton btnMore = findViewById(R.id.btn_more);
        btnMore.setOnClickListener(v -> showMoreMenu());

        etCommandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                String cmd = etCommandInput.getText().toString().trim();
                etCommandInput.setText("");
                executeCommand(cmd);
                return true;
            }
            return false;
        });

        etFloatingInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                String cmd = etFloatingInput.getText().toString().trim();
                etFloatingInput.setText("");
                executeCommand(cmd);
                return true;
            }
            return false;
        });

        btnFloatingSend.setOnClickListener(v -> {
            String cmd = etFloatingInput.getText().toString().trim();
            etFloatingInput.setText("");
            executeCommand(cmd);
        });

        etAppFilter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterApps(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        statusHandler.post(statusUpdater);
        requestPostNotificationsIfNeeded();
        startBackgroundSessionService();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        statusHandler.removeCallbacks(statusUpdater);
        if (mediaPlayer != null) {
            try {
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
        TerminalBackgroundService svc = TerminalBackgroundService.getInstance();
        if (svc != null) {
            svc.setCallback(null);
        }
    }

    private void closeCurrentSession() {
        if (sessions.size() > 1) {
            sessions.remove(currentSessionIndex);
            currentSessionIndex = Math.max(0, currentSessionIndex - 1);
            loadSession(currentSessionIndex);
        } else {
            sessions.get(0).history = new StringBuilder(":/ $ cd ~\n");
            loadSession(0);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void buildQuickCommandChips() {
        quickChipsContainer.removeAllViews();
        for (String cmd : QUICK_COMMANDS) {
            TextView chip = new TextView(this);
            chip.setText(cmd);
            chip.setTextColor(Color.WHITE);
            chip.setTextSize(11f);
            chip.setTypeface(Typeface.MONOSPACE);
            chip.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_glass_chip));
            chip.setPadding(dp(12), dp(5), dp(12), dp(5));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            );
            lp.setMarginEnd(dp(6));
            chip.setLayoutParams(lp);

            chip.setOnClickListener(v -> executeCommand(cmd));
            quickChipsContainer.addView(chip);
        }
    }

    private void rebuildSessionTabs() {
        sessionTabsContainer.removeAllViews();
        for (int i = 0; i < sessions.size(); i++) {
            final int idx = i;
            TerminalSession s = sessions.get(i);
            TextView tab = new TextView(this);
            tab.setText(s.title);
            tab.setTextSize(11f);
            tab.setTypeface(Typeface.MONOSPACE, i == currentSessionIndex ? Typeface.BOLD : Typeface.NORMAL);
            tab.setPadding(dp(12), dp(4), dp(12), dp(4));

            if (i == currentSessionIndex) {
                tab.setTextColor(customManager.getPromptColor());
                tab.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_glass_chip));
            } else {
                tab.setTextColor(0xFFB0BEC5);
                tab.setBackgroundColor(Color.TRANSPARENT);
            }

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            );
            lp.setMarginEnd(dp(6));
            tab.setLayoutParams(lp);
            tab.setOnClickListener(v -> loadSession(idx));
            sessionTabsContainer.addView(tab);
        }

        // "+ Tab" button
        TextView addTab = new TextView(this);
        addTab.setText("+");
        addTab.setTextColor(Color.WHITE);
        addTab.setTextSize(12f);
        addTab.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        addTab.setPadding(dp(10), dp(4), dp(10), dp(4));
        addTab.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_glass_chip));
        addTab.setOnClickListener(v -> {
            int num = sessions.size() + 1;
            sessions.add(new TerminalSession("Window " + num, appHomeDir));
            loadSession(sessions.size() - 1);
        });
        sessionTabsContainer.addView(addTab);
    }

    private void rebuildBottomAppDock() {
        bottomAppDock.removeAllViews();
        int maxIcons = Math.min(6, allInstalledApps.size());
        for (int i = 0; i < maxIcons; i++) {
            final AppItem item = allInstalledApps.get(i);
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(item.icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setContentDescription(item.label);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            lp.setMarginStart(dp(4));
            lp.setMarginEnd(dp(4));
            iv.setLayoutParams(lp);
            iv.setOnClickListener(v -> launchAppByPackage(item.packageName));
            bottomAppDock.addView(iv);
        }

        // All-apps drawer button at right end of dock
        ImageView allAppsBtn = new ImageView(this);
        allAppsBtn.setImageResource(R.drawable.ic_menu);
        allAppsBtn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
        allAppsBtn.setLayoutParams(lp);
        allAppsBtn.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        bottomAppDock.addView(allAppsBtn);
    }

    private void updateTelemetryStatus() {
        if (statusTelemetryBar.getVisibility() != View.VISIBLE) return;
        int batteryPct = 100;
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) {
                    batteryPct = Math.round((level / (float) scale) * 100f);
                }
            }
        } catch (Exception ignored) {
        }

        String timeStr = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        int style = customManager.getUiStyle();
        if (style == CustomizationManager.UI_STYLE_RETRO_CRT) {
            tvStatusLeft.setText("CRT-OS v2.0 • /dev/tty0");
            tvStatusRight.setText("BAT " + batteryPct + "% • " + timeStr);
        } else if (style == CustomizationManager.UI_STYLE_CYBERPUNK) {
            tvStatusLeft.setText("CYBER-DECK // NET:ONLINE");
            tvStatusRight.setText("PWR:" + batteryPct + "% • " + timeStr);
        } else {
            tvStatusLeft.setText("TERM-LAUNCHER • PREFIX/USR");
            tvStatusRight.setText(batteryPct + "% • " + timeStr);
        }
    }

    private void setupPinchToZoom() {
        currentZoomFactor = customManager.getFontSizeSp() / 13f;
        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                currentZoomFactor = customManager.getFontSizeSp() / 13f;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                currentZoomFactor *= detector.getScaleFactor();
                currentZoomFactor = Math.max(0.62f, Math.min(2.30f, currentZoomFactor));
                float newSizeSp = 13f * currentZoomFactor;
                customManager.setFontSizeSp(newSizeSp);
                applyFontSizeAndZoom();
                return true;
            }
        });

        terminalScroll.setOnTouchListener((v, event) -> {
            scaleGestureDetector.onTouchEvent(event);
            if (event.getPointerCount() >= 2 && scaleGestureDetector.isInProgress()) {
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP && !scaleGestureDetector.isInProgress()) {
                if (floatingInputBar.getVisibility() == View.VISIBLE) {
                    etFloatingInput.requestFocus();
                } else {
                    etCommandInput.requestFocus();
                }
            }
            return false;
        });
    }

    private void applyFontSizeAndZoom() {
        float sizeSp = customManager.getFontSizeSp();
        tvTerminalOutput.setTextSize(sizeSp);
        tvPromptTop.setTextSize(sizeSp);
        tvPrompt.setTextSize(sizeSp);
        etCommandInput.setTextSize(sizeSp);
        etFloatingInput.setTextSize(sizeSp);
        if (tvZoomBadge != null) {
            tvZoomBadge.setText(customManager.getZoomPercent() + "%");
        }
    }

    private void applyCustomization() {
        applyFontSizeAndZoom();

        Typeface tf = customManager.getTypeface();
        tvTerminalOutput.setTypeface(tf);
        tvPromptTop.setTypeface(tf);
        tvPrompt.setTypeface(tf);
        etCommandInput.setTypeface(tf);
        etFloatingInput.setTypeface(tf);

        int textColor = customManager.getTextColor();
        int promptColor = customManager.getPromptColor();
        tvTerminalOutput.setTextColor(textColor);
        tvPromptTop.setTextColor(promptColor);
        tvPrompt.setTextColor(promptColor);
        etCommandInput.setTextColor(textColor);
        etFloatingInput.setTextColor(textColor);
        tvFloatingPrompt.setTextColor(promptColor);

        // Background Wallpaper + Tint Overlay
        if (customManager.hasWallpaper()) {
            Bitmap bmp = customManager.loadWallpaperBitmap();
            if (bmp != null) {
                ivWallpaper.setImageBitmap(bmp);
                ivWallpaper.setVisibility(View.VISIBLE);
            } else {
                ivWallpaper.setVisibility(View.GONE);
            }
        } else {
            ivWallpaper.setImageDrawable(null);
            ivWallpaper.setVisibility(View.GONE);
        }
        vBgOverlay.setBackgroundColor(customManager.getEffectiveOverlayColor());

        int style = customManager.getUiStyle();
        boolean showHud = customManager.isShowHudBorder();
        boolean showCrt = customManager.isShowCrtScanlines();
        boolean showTabs = customManager.isShowSessionTabs();
        boolean showChips = customManager.isShowQuickChips();
        boolean showDock = customManager.isShowAppDock();

        // Telemetry / CRT Status Header
        statusTelemetryBar.setVisibility((showCrt || style == CustomizationManager.UI_STYLE_CYBERPUNK || style == CustomizationManager.UI_STYLE_DESKTOP_DOCK) ? View.VISIBLE : View.GONE);
        tvStatusLeft.setTextColor(promptColor);
        tvStatusRight.setTextColor(promptColor);
        updateTelemetryStatus();

        // macOS Dots (Desktop Tiling style)
        macosDotsContainer.setVisibility(style == CustomizationManager.UI_STYLE_DESKTOP_DOCK ? View.VISIBLE : View.GONE);

        // Top Bar & Window Frame styling per theme
        LinearLayout.LayoutParams topLp = (LinearLayout.LayoutParams) topBar.getLayoutParams();
        LinearLayout.LayoutParams frameLp = (LinearLayout.LayoutParams) terminalFrameBox.getLayoutParams();

        if (style == CustomizationManager.UI_STYLE_CYBERPUNK) {
            topLp.setMargins(dp(8), dp(6), dp(8), dp(4));
            topBar.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_hud_topbar));
            windowSelector.setBackground(null);

            frameLp.setMargins(dp(8), dp(2), dp(8), dp(8));
            terminalFrameBox.setBackground(showHud ? ContextCompat.getDrawable(this, R.drawable.bg_hud_cyberpunk) : null);
            useFloatingInputMode(true);
        } else if (style == CustomizationManager.UI_STYLE_GLASS) {
            topLp.setMargins(dp(8), dp(6), dp(8), dp(4));
            topBar.setBackgroundColor(Color.TRANSPARENT);
            windowSelector.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_glass_pill));

            frameLp.setMargins(dp(4), 0, dp(4), dp(4));
            terminalFrameBox.setBackground(showHud ? ContextCompat.getDrawable(this, R.drawable.bg_desktop_window) : null);
            useFloatingInputMode(true);
        } else if (style == CustomizationManager.UI_STYLE_RETRO_CRT) {
            topLp.setMargins(dp(8), dp(4), dp(8), dp(4));
            topBar.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_crt_frame));
            windowSelector.setBackground(null);

            frameLp.setMargins(dp(8), dp(2), dp(8), dp(8));
            terminalFrameBox.setBackground(showHud ? ContextCompat.getDrawable(this, R.drawable.bg_crt_frame) : null);
            useFloatingInputMode(false);
        } else if (style == CustomizationManager.UI_STYLE_DESKTOP_DOCK) {
            topLp.setMargins(dp(10), dp(4), dp(10), 0);
            topBar.setBackgroundColor(0xDD1A2026);
            windowSelector.setBackground(null);

            frameLp.setMargins(dp(10), 0, dp(10), dp(6));
            terminalFrameBox.setBackground(showHud ? ContextCompat.getDrawable(this, R.drawable.bg_desktop_window) : null);
            useFloatingInputMode(false);
        } else {
            // Classic Slate
            topLp.setMargins(0, 0, 0, 0);
            topBar.setBackgroundColor(ContextCompat.getColor(this, R.color.toolbar_bg));
            windowSelector.setBackground(null);

            frameLp.setMargins(0, 0, 0, 0);
            terminalFrameBox.setBackground(showHud ? ContextCompat.getDrawable(this, R.drawable.bg_hud_cyberpunk) : null);
            useFloatingInputMode(false);
        }
        topBar.setLayoutParams(topLp);
        terminalFrameBox.setLayoutParams(frameLp);

        // Phosphor shadow glow for CRT mode
        if (showCrt) {
            tvTerminalOutput.setShadowLayer(6f, 0f, 0f, textColor);
            tvPrompt.setShadowLayer(6f, 0f, 0f, promptColor);
        } else {
            tvTerminalOutput.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT);
            tvPrompt.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT);
        }

        // Session Tabs
        sessionTabsScroll.setVisibility(showTabs ? View.VISIBLE : View.GONE);
        if (showTabs) rebuildSessionTabs();

        // Quick Command Chips
        quickChipsScroll.setVisibility(showChips ? View.VISIBLE : View.GONE);

        // Bottom App Dock
        bottomAppDock.setVisibility(showDock ? View.VISIBLE : View.GONE);
        if (showDock) rebuildBottomAppDock();

        updatePrompt();
    }

    private void useFloatingInputMode(boolean floating) {
        if (floating) {
            inlinePromptRow.setVisibility(View.GONE);
            floatingInputBar.setVisibility(View.VISIBLE);
        } else {
            floatingInputBar.setVisibility(View.GONE);
            inlinePromptRow.setVisibility(View.VISIBLE);
        }
    }

    private void showCustomizeDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_customize, null);

        Spinner spUiStyle = dialogView.findViewById(R.id.sp_ui_style);
        Spinner spPromptStyle = dialogView.findViewById(R.id.sp_prompt_style);
        CheckBox cbSessionTabs = dialogView.findViewById(R.id.cb_session_tabs);
        CheckBox cbQuickChips = dialogView.findViewById(R.id.cb_quick_chips);
        CheckBox cbAppDock = dialogView.findViewById(R.id.cb_app_dock);
        CheckBox cbHudBorder = dialogView.findViewById(R.id.cb_hud_border);
        CheckBox cbCrtScanlines = dialogView.findViewById(R.id.cb_crt_scanlines);

        Spinner spFont = dialogView.findViewById(R.id.sp_font_style);
        SeekBar sbFontSize = dialogView.findViewById(R.id.sb_font_size);
        TextView tvZoomLabel = dialogView.findViewById(R.id.tv_zoom_label);
        Spinner spTextColor = dialogView.findViewById(R.id.sp_text_color);
        Spinner spPromptColor = dialogView.findViewById(R.id.sp_prompt_color);
        Spinner spBgTheme = dialogView.findViewById(R.id.sp_bg_theme);
        SeekBar sbDim = dialogView.findViewById(R.id.sb_bg_dim);
        TextView tvDimLabel = dialogView.findViewById(R.id.tv_dim_label);
        Button btnPickWp = dialogView.findViewById(R.id.btn_pick_wallpaper);
        Button btnClearWp = dialogView.findViewById(R.id.btn_clear_wallpaper);

        ArrayAdapter<String> uiStyleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.UI_STYLE_NAMES);
        spUiStyle.setAdapter(uiStyleAdapter);
        spUiStyle.setSelection(customManager.getUiStyle());

        ArrayAdapter<String> promptStyleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.PROMPT_STYLE_NAMES);
        spPromptStyle.setAdapter(promptStyleAdapter);
        spPromptStyle.setSelection(customManager.getPromptStyle());

        cbSessionTabs.setChecked(customManager.isShowSessionTabs());
        cbQuickChips.setChecked(customManager.isShowQuickChips());
        cbAppDock.setChecked(customManager.isShowAppDock());
        cbHudBorder.setChecked(customManager.isShowHudBorder());
        cbCrtScanlines.setChecked(customManager.isShowCrtScanlines());

        ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.FONT_LABELS);
        spFont.setAdapter(fontAdapter);
        spFont.setSelection(customManager.getFontStyleIndex());

        int initialSize = Math.round(customManager.getFontSizeSp());
        int progressVal = Math.max(0, Math.min(22, initialSize - 8));
        sbFontSize.setProgress(progressVal);
        int initZoom = Math.round(((progressVal + 8) / 13f) * 100f);
        tvZoomLabel.setText("TERMINAL ZOOM / FONT SIZE: " + (progressVal + 8) + "sp (" + initZoom + "%)");

        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.COLOR_PRESET_NAMES);
        spTextColor.setAdapter(colorAdapter);
        spPromptColor.setAdapter(colorAdapter);

        spTextColor.setSelection(findColorIndex(customManager.getTextColor(), 0));
        spPromptColor.setSelection(findColorIndex(customManager.getPromptColor(), 1));

        ArrayAdapter<String> bgAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.BG_THEME_NAMES);
        spBgTheme.setAdapter(bgAdapter);
        spBgTheme.setSelection(findBgIndex(customManager.getBgTintColor()));

        int dimVal = customManager.getBgDimPercent();
        sbDim.setProgress(dimVal);
        tvDimLabel.setText("BACKGROUND DIM / OVERLAY: " + dimVal + "%");

        final boolean[] initialized = {false};
        spUiStyle.post(() -> initialized[0] = true);

        spUiStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (!initialized[0]) return;
                customManager.applyUiStylePreset(pos);
                // Sync dialog controls with newly chosen preset
                spPromptStyle.setSelection(customManager.getPromptStyle());
                cbSessionTabs.setChecked(customManager.isShowSessionTabs());
                cbQuickChips.setChecked(customManager.isShowQuickChips());
                cbAppDock.setChecked(customManager.isShowAppDock());
                cbHudBorder.setChecked(customManager.isShowHudBorder());
                cbCrtScanlines.setChecked(customManager.isShowCrtScanlines());
                spTextColor.setSelection(findColorIndex(customManager.getTextColor(), 0));
                spPromptColor.setSelection(findColorIndex(customManager.getPromptColor(), 1));
                spBgTheme.setSelection(findBgIndex(customManager.getBgTintColor()));
                sbDim.setProgress(customManager.getBgDimPercent());
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spPromptStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setPromptStyle(pos);
                updatePrompt();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        cbSessionTabs.setOnCheckedChangeListener((buttonView, isChecked) -> {
            customManager.setShowSessionTabs(isChecked);
            applyCustomization();
        });
        cbQuickChips.setOnCheckedChangeListener((buttonView, isChecked) -> {
            customManager.setShowQuickChips(isChecked);
            applyCustomization();
        });
        cbAppDock.setOnCheckedChangeListener((buttonView, isChecked) -> {
            customManager.setShowAppDock(isChecked);
            applyCustomization();
        });
        cbHudBorder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            customManager.setShowHudBorder(isChecked);
            applyCustomization();
        });
        cbCrtScanlines.setOnCheckedChangeListener((buttonView, isChecked) -> {
            customManager.setShowCrtScanlines(isChecked);
            applyCustomization();
        });

        spFont.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setFontStyleIndex(pos);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        sbFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int sp = progress + 8;
                int zoomPct = Math.round((sp / 13f) * 100f);
                tvZoomLabel.setText("TERMINAL ZOOM / FONT SIZE: " + sp + "sp (" + zoomPct + "%)");
                customManager.setFontSizeSp(sp);
                applyFontSizeAndZoom();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        spTextColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setTextColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spPromptColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setPromptColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spBgTheme.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                customManager.setBgTintColor(CustomizationManager.BG_THEME_COLORS[pos]);
                applyCustomization();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        sbDim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvDimLabel.setText("BACKGROUND DIM / OVERLAY: " + progress + "%");
                customManager.setBgDimPercent(progress);
                applyCustomization();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnPickWp.setOnClickListener(v -> pickWallpaperLauncher.launch(new String[]{"image/*"}));
        btnClearWp.setOnClickListener(v -> {
            customManager.clearWallpaper();
            sbDim.setProgress(customManager.getBgDimPercent());
            applyCustomization();
            Toast.makeText(this, "Wallpaper cleared.", Toast.LENGTH_SHORT).show();
        });

        TextView tvNowPlaying = dialogView.findViewById(R.id.tv_music_now_playing);
        Button btnScanSongs = dialogView.findViewById(R.id.btn_music_scan);
        Button btnToggleMusic = dialogView.findViewById(R.id.btn_music_toggle);
        Button btnStopMusic = dialogView.findViewById(R.id.btn_music_stop);
        LinearLayout songListContainer = dialogView.findViewById(R.id.container_storage_songs);

        Runnable refreshSongUI = new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && currentTrackName != null) {
                    tvNowPlaying.setText("Now Playing: " + currentTrackName + (mediaPlayer.isPlaying() ? " [Playing]" : " [Paused]"));
                } else {
                    tvNowPlaying.setText("Now Playing: None");
                }
                songListContainer.removeAllViews();
                List<File> songs = findAudioFiles("");
                if (songs.isEmpty()) {
                    TextView emptyTv = new TextView(MainActivity.this);
                    emptyTv.setText("No audio files found. Tap 'Scan Storage' or run 'storage-access'.");
                    emptyTv.setTextColor(Color.parseColor("#90A4AE"));
                    emptyTv.setTextSize(11f);
                    emptyTv.setPadding(6, 8, 6, 8);
                    songListContainer.addView(emptyTv);
                } else {
                    int maxShow = Math.min(songs.size(), 25);
                    for (int i = 0; i < maxShow; i++) {
                        final File audioFile = songs.get(i);
                        Button songBtn = new Button(MainActivity.this);
                        songBtn.setText((i + 1) + ". " + audioFile.getName() + " (" + formatShortSize(audioFile.length()) + ")");
                        songBtn.setAllCaps(false);
                        songBtn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                        songBtn.setTextColor(Color.parseColor("#ECEFF1"));
                        songBtn.setTextSize(11.5f);
                        songBtn.setBackgroundColor(Color.parseColor("#243138"));
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        );
                        lp.setMargins(0, 0, 0, 4);
                        songBtn.setLayoutParams(lp);
                        songBtn.setOnClickListener(v -> {
                            if (playAudioFile(audioFile)) {
                                appendOutput("Playing: " + audioFile.getName() + "\n");
                                tvNowPlaying.setText("Now Playing: " + audioFile.getName() + " [Playing]");
                            }
                        });
                        songListContainer.addView(songBtn);
                    }
                }
            }
        };

        btnScanSongs.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_MEDIA_AUDIO}, 102);
                }
            } else {
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
                }
            }
            refreshSongUI.run();
        });

        btnToggleMusic.setOnClickListener(v -> {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    appendOutput("Paused: " + currentTrackName + "\n");
                } else {
                    mediaPlayer.start();
                    appendOutput("Resumed: " + currentTrackName + "\n");
                }
                refreshSongUI.run();
            }
        });

        btnStopMusic.setOnClickListener(v -> {
            stopPlayback();
            appendOutput("Playback stopped.\n");
            refreshSongUI.run();
        });

        refreshSongUI.run();

        new AlertDialog.Builder(this)
            .setTitle("Settings & Customization")
            .setView(dialogView)
            .setPositiveButton("Done", (d, w) -> applyCustomization())
            .show();
    }

    private int findColorIndex(int color, int fallback) {
        for (int i = 0; i < CustomizationManager.COLOR_PRESET_VALUES.length; i++) {
            if (CustomizationManager.COLOR_PRESET_VALUES[i] == color) return i;
        }
        return fallback;
    }

    private int findBgIndex(int color) {
        for (int i = 0; i < CustomizationManager.BG_THEME_COLORS.length; i++) {
            if (CustomizationManager.BG_THEME_COLORS[i] == color) return i;
        }
        return 0;
    }

    private void loadSession(int index) {
        currentSessionIndex = index;
        TerminalSession s = sessions.get(index);
        tvWindowTitle.setText(s.title);
        tvTerminalOutput.setText(s.history.toString());
        if (sessionTabsScroll.getVisibility() == View.VISIBLE) {
            rebuildSessionTabs();
        }
        updatePrompt();
        scrollToBottom();
    }

    private String formatShortPath(File dir) {
        String abs = dir.getAbsolutePath();
        String homeAbs = appHomeDir.getAbsolutePath();
        if (abs.equals(homeAbs)) return "~";
        if (abs.startsWith(homeAbs + "/")) return "~" + abs.substring(homeAbs.length());
        return abs;
    }

    private void updatePrompt() {
        TerminalSession s = sessions.get(currentSessionIndex);
        int pStyle = customManager.getPromptStyle();
        String shortPath = formatShortPath(s.currentDir);

        if (pStyle == 1) {
            // Powerline Two-Line
            tvPromptTop.setVisibility(View.VISIBLE);
            tvPromptTop.setText("┌─[termlauncher@android]─[" + shortPath + "]");
            tvPrompt.setText("└─▶ $ ");
            tvFloatingPrompt.setText("└─▶ ");
        } else if (pStyle == 2) {
            // Retro Host
            tvPromptTop.setVisibility(View.GONE);
            tvPrompt.setText("guest@android:" + shortPath + "$ ");
            tvFloatingPrompt.setText(shortPath + "$ ");
        } else if (pStyle == 3) {
            // Minimalist
            tvPromptTop.setVisibility(View.GONE);
            tvPrompt.setText("❯ ");
            tvFloatingPrompt.setText("❯ ");
        } else {
            // Classic Path
            tvPromptTop.setVisibility(View.GONE);
            tvPrompt.setText(":" + s.currentDir.getAbsolutePath() + " $ ");
            tvFloatingPrompt.setText(shortPath + " $ ");
        }
    }

    private String cleanTerminalText(String raw) {
        if (raw == null) return "";
        // Strip ANSI escape sequences and carriage returns so terminal output stays clean
        String noAnsi = raw.replaceAll("\u001B\[[;\d]*[ -/]*[@-~]", "");
        return noAnsi.replace("\r\n", "\n").replace("\r", "\n");
    }

    private String formatShortSize(long bytes) {
        if (bytes < 1024L) return bytes + "B";
        double kb = bytes / 1024.0;
        if (kb < 1024.0) return String.format(Locale.US, "%.1fK", kb);
        double mb = kb / 1024.0;
        if (mb < 1024.0) return String.format(Locale.US, "%.1fM", mb);
        return String.format(Locale.US, "%.1fG", mb / 1024.0);
    }

    private void appendOutput(String text) {
        TerminalSession s = sessions.get(currentSessionIndex);
        s.history.append(cleanTerminalText(text));
        tvTerminalOutput.setText(s.history.toString());
        scrollToBottom();
    }

    private void scrollToBottom() {
        terminalScroll.post(() -> terminalScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void loadAliases() {
        customAliases.clear();
        Map<String, ?> all = aliasPrefs.getAll();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            if (entry.getValue() instanceof String) {
                customAliases.put(entry.getKey(), (String) entry.getValue());
            }
        }
        if (customAliases.isEmpty()) {
            customAliases.put("ff", "fastfetch");
            customAliases.put("up", "pkg update");
            customAliases.put("ll", "ls -la");
            customAliases.put("cls", "clear");
            saveAliases();
        }
    }

    private void saveAliases() {
        SharedPreferences.Editor ed = aliasPrefs.edit();
        ed.clear();
        for (Map.Entry<String, String> e : customAliases.entrySet()) {
            ed.putString(e.getKey(), e.getValue());
        }
        ed.apply();
    }

    private int getBatteryPercent() {
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) {
                    return Math.round((level / (float) scale) * 100f);
                }
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb);
        double gb = mb / 1024.0;
        return String.format(Locale.US, "%.2f GB", gb);
    }

    private String buildSysInfoText(File currentDir) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== TERMLAUNCHER SYSTEM INFO ===\n");
        sb.append("Device   : ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        sb.append("Android  : ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        StringBuilder abis = new StringBuilder();
        if (Build.SUPPORTED_ABIS != null) {
            for (int i = 0; i < Build.SUPPORTED_ABIS.length; i++) {
                if (i > 0) abis.append(", ");
                abis.append(Build.SUPPORTED_ABIS[i]);
            }
        }
        sb.append("Arch/ABI : ").append(abis.toString()).append("\n");
        int bat = getBatteryPercent();
        if (bat >= 0) {
            sb.append("Battery  : ").append(bat).append("%\n");
        }
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            if (am != null) {
                am.getMemoryInfo(mi);
                long usedRam = mi.totalMem - mi.availMem;
                sb.append("RAM      : ").append(formatBytes(usedRam)).append(" / ").append(formatBytes(mi.totalMem))
                  .append(" (").append(formatBytes(mi.availMem)).append(" free)\n");
            }
        } catch (Exception ignored) {
        }
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            long totalData = sf.getTotalBytes();
            long availData = sf.getAvailableBytes();
            sb.append("Storage  : ").append(formatBytes(totalData - availData)).append(" / ").append(formatBytes(totalData))
              .append(" (").append(formatBytes(availData)).append(" free)\n");
        } catch (Exception ignored) {
        }
        sb.append("PWD      : ").append(currentDir.getAbsolutePath()).append("\n");
        sb.append("PREFIX   : ").append(repoManager.getPrefixDir().getAbsolutePath()).append("\n");
        return sb.toString();
    }

    private String buildNetInfoText() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== NETWORK INTERFACES ===\n");
        try {
            Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
            while (nis != null && nis.hasMoreElements()) {
                NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                sb.append("Interface: ").append(ni.getName()).append(" (").append(ni.getDisplayName()).append(")\n");
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    String host = addr.getHostAddress();
                    if (host != null && !host.startsWith("fe80")) {
                        sb.append("  IP : ").append(host).append("\n");
                    }
                }
            }
        } catch (Exception e) {
            sb.append("Error reading network interfaces: ").append(e.getMessage()).append("\n");
        }
        return sb.toString();
    }

    private String buildMatrixBurst() {
        String chars = "01アイウエオカキクケコサシスセソ#$%@*+-/\\<>";
        StringBuilder sb = new StringBuilder();
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 36; col++) {
                int idx = (row * 13 + col * 7 + (int) (System.nanoTime() % 97)) % chars.length();
                if (idx < 0) idx += chars.length();
                sb.append(chars.charAt(idx)).append(col % 2 == 0 ? " " : "");
            }
            sb.append("\n");
        }
        sb.append("[WAKE UP, TERMLAUNCHER...]\n");
        return sb.toString();
    }

    private void executeCommand(String rawCmd) {
        TerminalSession s = sessions.get(currentSessionIndex);
        String shortPath = formatShortPath(s.currentDir);
        int pStyle = customManager.getPromptStyle();
        String promptEcho;
        if (pStyle == 1) {
            promptEcho = "┌─[termlauncher@android]─[" + shortPath + "]\n└─▶ $ ";
        } else if (pStyle == 2) {
            promptEcho = "guest@android:" + shortPath + "$ ";
        } else if (pStyle == 3) {
            promptEcho = "❯ ";
        } else {
            promptEcho = ":" + s.currentDir.getAbsolutePath() + " $ ";
        }
        appendOutput(promptEcho + rawCmd + "\n");

        if (rawCmd.isEmpty()) return;

        s.historyCommands.add(rawCmd);

        // Resolve custom alias if exact or prefix match exists
        String cmd = rawCmd;
        String[] firstSplit = rawCmd.trim().split("\\s+", 2);
        String firstWord = firstSplit[0];
        if (!firstWord.equals("alias") && !firstWord.equals("unalias") && customAliases.containsKey(firstWord)) {
            String targetCmd = customAliases.get(firstWord);
            cmd = firstSplit.length > 1 ? (targetCmd + " " + firstSplit[1]) : targetCmd;
        }

        String[] parts = cmd.split("\\s+");
        String base = parts[0].toLowerCase(Locale.ROOT);

        if (base.equals("storage-access")) {
            triggerStorageAccessFromTerminal(s);
            return;
        }

        if (base.equals("play")) {
            handlePlayCommand(cmd, parts, s);
            return;
        }

        if (base.equals("music")) {
            handleMusicCommand(parts);
            return;
        }

        if (base.equals("notif")) {
            if (parts.length >= 2 && parts[1].equalsIgnoreCase("access")) {
                try {
                    startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
                    appendOutput("Opening Notification Listener access settings...\n");
                } catch (Exception e) {
                    appendOutput("Could not open notification settings: " + e.getMessage() + "\n");
                }
            } else {
                appendOutput("Incoming notifications appear automatically with [NOTIF] in terminal.\n" +
                             "To enable listener permission on Android: run 'notif access'\n");
            }
            return;
        }

                if (base.equals("clear")) {
            s.history = new StringBuilder();
            tvTerminalOutput.setText("");
            return;
        }

        if (base.equals("customize") || base.equals("theme") || base.equals("wallpaper") || base.equals("ui")) {
            runOnUiThread(this::showCustomizeDialog);
            appendOutput("Opening UI & Terminal Customization settings...\n");
            return;
        }

        if (base.equals("style")) {
            if (parts.length >= 2) {
                try {
                    int styleIdx = Integer.parseInt(parts[1]);
                    if (styleIdx >= 0 && styleIdx < CustomizationManager.UI_STYLE_NAMES.length) {
                        customManager.applyUiStylePreset(styleIdx);
                        applyCustomization();
                        appendOutput("Switched UI style to [" + styleIdx + "] " + CustomizationManager.UI_STYLE_NAMES[styleIdx] + "\n");
                        return;
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            appendOutput("Usage: style <0-4>\n");
            for (int i = 0; i < CustomizationManager.UI_STYLE_NAMES.length; i++) {
                appendOutput("  " + i + " = " + CustomizationManager.UI_STYLE_NAMES[i] + "\n");
            }
            return;
        }

        if (base.equals("newtab")) {
            int num = sessions.size() + 1;
            sessions.add(new TerminalSession("Window " + num, appHomeDir));
            loadSession(sessions.size() - 1);
            appendOutput("Opened Window " + num + "\n");
            return;
        }

        if (base.equals("tab")) {
            if (parts.length >= 2) {
                try {
                    int tabIdx = Integer.parseInt(parts[1]) - 1;
                    if (tabIdx >= 0 && tabIdx < sessions.size()) {
                        loadSession(tabIdx);
                        return;
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            appendOutput("Active tabs (" + sessions.size() + "): use 'tab <1-" + sessions.size() + ">' or 'newtab'\n");
            for (int i = 0; i < sessions.size(); i++) {
                appendOutput("  [" + (i + 1) + "] " + sessions.get(i).title + (i == currentSessionIndex ? " (active)" : "") + "\n");
            }
            return;
        }

        if (base.equals("history")) {
            if (s.historyCommands.isEmpty()) {
                appendOutput("(no commands in history)\n");
            } else {
                for (int i = 0; i < s.historyCommands.size(); i++) {
                    appendOutput(String.format(Locale.US, "%3d  %s\n", i + 1, s.historyCommands.get(i)));
                }
            }
            return;
        }

        if (base.equals("alias")) {
            if (parts.length == 1) {
                if (customAliases.isEmpty()) {
                    appendOutput("(no aliases defined)\n");
                } else {
                    for (Map.Entry<String, String> entry : customAliases.entrySet()) {
                        appendOutput("alias " + entry.getKey() + "='" + entry.getValue() + "'\n");
                    }
                }
                return;
            }
            String rest = cmd.substring(5).trim();
            int eq = rest.indexOf('=');
            if (eq <= 0) {
                appendOutput("Usage: alias <name>=<command>  (e.g. alias ff=fastfetch)\n");
                return;
            }
            String aName = rest.substring(0, eq).trim();
            String aVal = rest.substring(eq + 1).trim();
            if ((aVal.startsWith("'") && aVal.endsWith("'") && aVal.length() >= 2) ||
                (aVal.startsWith("\"") && aVal.endsWith("\"") && aVal.length() >= 2)) {
                aVal = aVal.substring(1, aVal.length() - 1);
            }
            customAliases.put(aName, aVal);
            saveAliases();
            appendOutput("Saved alias: " + aName + " -> " + aVal + "\n");
            return;
        }

        if (base.equals("unalias") && parts.length >= 2) {
            if (customAliases.remove(parts[1]) != null) {
                saveAliases();
                appendOutput("Removed alias: " + parts[1] + "\n");
            } else {
                appendOutput("Alias not found: " + parts[1] + "\n");
            }
            return;
        }

        if (base.equals("sysinfo")) {
            appendOutput(buildSysInfoText(s.currentDir));
            return;
        }

        if (base.equals("netinfo")) {
            appendOutput(buildNetInfoText());
            return;
        }

        if (base.equals("matrix")) {
            appendOutput(buildMatrixBurst());
            return;
        }

        if (base.equals("pwd")) {
            appendOutput(s.currentDir.getAbsolutePath() + "\n");
            return;
        }

        if (base.equals("ls")) {
            boolean showHidden = cmd.contains("-a") || cmd.contains("-la") || cmd.contains("-al");
            File[] files = s.currentDir.listFiles();
            if (files == null || files.length == 0) {
                appendOutput("  (empty directory)\n");
                return;
            }
            StringBuilder out = new StringBuilder();
            int count = 0;
            for (File f : files) {
                String fname = f.getName();
                if (!showHidden && fname.startsWith(".")) continue;
                if (f.isDirectory()) {
                    out.append(String.format(Locale.US, "  [DIR]   %-28s %6s\n", fname + "/", "-"));
                } else {
                    out.append(String.format(Locale.US, "  [FILE]  %-28s %6s\n", fname, formatShortSize(f.length())));
                }
                count++;
            }
            if (count == 0) {
                appendOutput("  (no matching entries)\n");
            } else {
                appendOutput(out.toString());
            }
            return;
        }

        if (base.equals("tail")) {
            int nLines = 20;
            if (parts.length >= 2) {
                try {
                    nLines = Math.max(1, Math.min(200, Integer.parseInt(parts[1])));
                } catch (NumberFormatException ignored) {
                }
            }
            String[] allLines = s.history.toString().split("\n");
            int startIdx = Math.max(0, allLines.length - nLines);
            StringBuilder out = new StringBuilder();
            for (int i = startIdx; i < allLines.length; i++) {
                out.append(allLines[i]).append("\n");
            }
            appendOutput(out.toString());
            return;
        }

        if (base.equals("mkdir") && parts.length >= 2) {
            File target = parts[1].startsWith("/") ? new File(parts[1]) : new File(s.currentDir, parts[1]);
            if (target.exists() || target.mkdirs()) {
                appendOutput("Created directory: " + target.getAbsolutePath() + "\n");
            } else {
                appendOutput("mkdir: cannot create directory '" + parts[1] + "'\n");
            }
            return;
        }

        if (base.equals("touch") && parts.length >= 2) {
            File target = parts[1].startsWith("/") ? new File(parts[1]) : new File(s.currentDir, parts[1]);
            try {
                if (!target.exists()) {
                    File parent = target.getParentFile();
                    if (parent != null && !parent.exists()) parent.mkdirs();
                    target.createNewFile();
                }
                target.setLastModified(System.currentTimeMillis());
                appendOutput("Touched: " + target.getName() + "\n");
            } catch (Exception e) {
                appendOutput("touch: error: " + e.getMessage() + "\n");
            }
            return;
        }

        if (base.equals("cat") && parts.length >= 2) {
            File target = parts[1].startsWith("/") ? new File(parts[1]) : new File(s.currentDir, parts[1]);
            if (!target.exists() || target.isDirectory()) {
                appendOutput("cat: " + parts[1] + ": No such file or directory\n");
                return;
            }
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(target)))) {
                String line;
                int lines = 0;
                while ((line = br.readLine()) != null && lines < 200) {
                    appendOutput(line + "\n");
                    lines++;
                }
                if (lines >= 200) {
                    appendOutput("... (truncated at 200 lines)\n");
                }
            } catch (Exception e) {
                appendOutput("cat: error reading file: " + e.getMessage() + "\n");
            }
            return;
        }

        if (base.equals("zoom")) {
            if (parts.length >= 2) {
                String action = parts[1].toLowerCase(Locale.ROOT);
                if (action.equals("in") || action.equals("+")) {
                    customManager.setFontSizeSp(customManager.getFontSizeSp() + 2f);
                    applyFontSizeAndZoom();
                    appendOutput("Zoomed in -> " + customManager.getZoomPercent() + "% (" + Math.round(customManager.getFontSizeSp()) + "sp)\n");
                    return;
                } else if (action.equals("out") || action.equals("-")) {
                    customManager.setFontSizeSp(customManager.getFontSizeSp() - 2f);
                    applyFontSizeAndZoom();
                    appendOutput("Zoomed out -> " + customManager.getZoomPercent() + "% (" + Math.round(customManager.getFontSizeSp()) + "sp)\n");
                    return;
                } else if (action.equals("reset") || action.equals("100")) {
                    customManager.setFontSizeSp(13f);
                    applyFontSizeAndZoom();
                    appendOutput("Zoom reset -> 100% (13sp)\n");
                    return;
                } else {
                    try {
                        int pct = Integer.parseInt(action.replace("%", ""));
                        float sp = (pct / 100f) * 13f;
                        customManager.setFontSizeSp(sp);
                        applyFontSizeAndZoom();
                        appendOutput("Zoom set -> " + customManager.getZoomPercent() + "% (" + Math.round(customManager.getFontSizeSp()) + "sp)\n");
                        return;
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
            appendOutput("Usage: zoom [in|out|reset|<percent>]  (Or pinch with 2 fingers on terminal)\n");
            return;
        }

        if (base.equals("bin")) {
            File bDir = repoManager.getBinDir();
            File[] bFiles = bDir.listFiles();
            appendOutput("Bin: " + bDir.getAbsolutePath() + "\n");
            if (bFiles == null || bFiles.length == 0) {
                appendOutput("  (empty - install packages with 'pkg install <name>')\n");
            } else {
                StringBuilder out = new StringBuilder();
                for (File bf : bFiles) {
                    out.append(String.format(Locale.US, "  %-24s %s\n", bf.getName(), bf.canExecute() ? "[EXEC]" : "[BIN]"));
                }
                appendOutput(out.toString());
            }
            return;
        }

        if (base.equals("help")) {
            appendOutput(
                "TermLauncher Built-in Commands:\n" +
                "  pkg update              - Sync online Termux package repository\n" +
                "  pkg search <query>      - Search Termux packages online\n" +
                "  pkg install <package>   - Download & install Termux .deb package\n" +
                "  sysinfo / netinfo       - Show Android device, RAM, storage & network IPs\n" +
                "  style <0-4>             - Switch UI theme (Classic, Cyberpunk, Glass, CRT, Dock)\n" +
                "  tab <n> / newtab        - Switch or open terminal window tabs\n" +
                "  alias <k>=<v> / unalias - Create or remove persistent custom command shortcuts\n" +
                "  history / matrix        - View command history or Matrix rain burst\n" +
                "  ls / pwd / cat / mkdir  - Quick built-in file & folder helpers\n" +
                "  apps / launch <name>    - List or launch installed Android apps\n" +
                "  zoom [in|out|reset]     - Zoom terminal text in/out (or pinch 2 fingers)\n" +
                "  customize / theme       - Open UI & Terminal customization settings\n" +
                "  bin                     - List binaries connected in $PREFIX/bin\n" +
                "  su / adb                - Execute su (root) or adb commands via bin\n" +
                "  cd <dir>                - Change directory (~ for app_HOME)\n" +
                "  clear                   - Clear terminal output\n"
            );
            return;
        }

        if (base.equals("cd")) {
            if (parts.length == 1 || parts[1].equals("~")) {
                s.currentDir = appHomeDir;
            } else {
                File target = parts[1].startsWith("/") ? new File(parts[1]) : new File(s.currentDir, parts[1]);
                if (target.exists() && target.isDirectory()) {
                    try {
                        s.currentDir = target.getCanonicalFile();
                    } catch (Exception e) {
                        s.currentDir = target;
                    }
                } else {
                    appendOutput("sh: cd: " + parts[1] + ": No such file or directory\n");
                }
            }
            updatePrompt();
            return;
        }

        if (base.equals("apps")) {
            StringBuilder out = new StringBuilder();
            int idx = 1;
            for (AppItem item : allInstalledApps) {
                out.append(String.format(Locale.US, "  %2d. %-26s %s\n", idx++, item.label, item.packageName));
            }
            appendOutput(out.toString());
            return;
        }

        if (base.equals("launch") && parts.length > 1) {
            String query = cmd.substring(7).trim().toLowerCase(Locale.ROOT);
            for (AppItem item : allInstalledApps) {
                if (item.label.toLowerCase(Locale.ROOT).contains(query) || item.packageName.toLowerCase(Locale.ROOT).contains(query)) {
                    launchAppByPackage(item.packageName);
                    appendOutput("Launching " + item.label + "...\n");
                    return;
                }
            }
            appendOutput("App not found: " + query + "\n");
            return;
        }

        if (base.equals("pkg") || base.equals("apt")) {
            if (parts.length < 2) {
                appendOutput("Usage: pkg [update|search|install] <package>\n");
                return;
            }
            String sub = parts[1];
            if (sub.equals("update")) {
                repoManager.updateRepo(new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            } else if (sub.equals("search") && parts.length >= 3) {
                repoManager.searchPackage(parts[2], new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            } else if ((sub.equals("install") || sub.equals("reinstall")) && parts.length >= 3) {
                repoManager.installPackage(parts[2], new TermuxRepoManager.OutputCallback() {
                    @Override public void onLog(String text) { appendOutput(text); }
                    @Override public void onComplete(boolean success) {}
                });
                return;
            }
        }

        final String execCmd = cmd;
        final String execBase = base;
        final String[] execParts = parts;
        final TerminalSession execSession = s;

        new Thread(() -> {
            try {
                String termuxBin = repoManager.getBinDir().getAbsolutePath();
                String prefixPath = repoManager.getPrefixDir().getAbsolutePath();
                String libPath = new File(repoManager.getPrefixDir(), "lib").getAbsolutePath();
                String terminfoPath = new File(repoManager.getPrefixDir(), "share/terminfo").getAbsolutePath();

                String finalCmd = execCmd;
                File candidateBin = new File(termuxBin, execParts[0]);
                if (execBase.equals("su")) {
                    String extraArgs = execCmd.length() > 2 ? execCmd.substring(2).trim() : "";
                    finalCmd = "for s in /sbin/su /system/bin/su /system/xbin/su /vendor/bin/su /data/adb/ksu/bin/su /data/adb/ap/bin/su; do " +
                               "if [ -x \"$s\" ]; then exec \"$s\" " + extraArgs + "; fi; done; " +
                               "exec '" + termuxBin + "/su' " + extraArgs;
                } else if (execBase.equals("adb")) {
                    String extraArgs = execCmd.length() > 3 ? execCmd.substring(3).trim() : "";
                    finalCmd = "if [ -x '" + termuxBin + "/adb.bin' ]; then exec '" + termuxBin + "/adb.bin' " + extraArgs + "; " +
                               "elif [ -x /system/bin/adb ]; then exec /system/bin/adb " + extraArgs + "; " +
                               "else exec '" + termuxBin + "/adb' " + extraArgs + "; fi";
                } else if (candidateBin.exists() && candidateBin.isFile()) {
                    String extraArgs = execCmd.length() > execParts[0].length() ? execCmd.substring(execParts[0].length()).trim() : "";
                    String binAbs = candidateBin.getAbsolutePath();
                    finalCmd = "'" + binAbs + "' " + extraArgs + " 2>/dev/null; " +
                               "rc=$?; " +
                               "if [ $rc -eq 126 ]; then " +
                               "  if [ -x /system/bin/linker64 ]; then exec /system/bin/linker64 '" + binAbs + "' " + extraArgs + "; " +
                               "  elif [ -x /system/bin/linker ]; then exec /system/bin/linker '" + binAbs + "' " + extraArgs + "; fi; " +
                               "elif [ $rc -ne 0 ]; then " +
                               "  exec '" + binAbs + "' " + extraArgs + "; " +
                               "fi";
                }

                ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", finalCmd);
                pb.directory(execSession.currentDir);
                pb.redirectErrorStream(true);

                Map<String, String> env = pb.environment();
                String existingPath = env.get("PATH");
                String sysPaths = "/system/bin:/system/xbin:/sbin:/vendor/bin";
                env.put("PATH", termuxBin + ":" + (existingPath != null ? existingPath : sysPaths) + ":" + sysPaths);
                env.put("HOME", appHomeDir.getAbsolutePath());
                env.put("PREFIX", prefixPath);
                env.put("LD_LIBRARY_PATH", libPath);
                env.put("TERMINFO", terminfoPath);
                env.put("TERM", "xterm-256color");
                env.put("COLUMNS", "80");
                env.put("LINES", "24");
                env.put("TMPDIR", new File(repoManager.getRootDir(), "cache").getAbsolutePath());

                Process process = pb.start();
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    final String outLine = line + "\n";
                    runOnUiThread(() -> appendOutput(outLine));
                }
                int exitCode = process.waitFor();
                if (exitCode != 0 && (execBase.equals("su") || execBase.equals("adb"))) {
                    final String hint = "[exit " + exitCode + "]\n";
                    runOnUiThread(() -> appendOutput(hint));
                }
            } catch (Exception e) {
                final String err = "sh: " + e.getMessage() + "\n";
                runOnUiThread(() -> appendOutput(err));
            }
        }).start();
    }

    private void requestPostNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIF_POST_PERM
                );
            }
        }
    }

    private void startBackgroundSessionService() {
        try {
            Intent intent = new Intent(this, TerminalBackgroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(this, intent);
            } else {
                startService(intent);
            }
            mainHandlerAttachCallback();
        } catch (Exception ignored) {
        }
    }

    private void mainHandlerAttachCallback() {
        statusHandler.postDelayed(() -> {
            TerminalBackgroundService svc = TerminalBackgroundService.getInstance();
            if (svc != null) {
                svc.setCallback(new TerminalBackgroundService.NotificationCallback() {
                    @Override
                    public void onNotificationReceived(String pkg, String title, String text) {
                        runOnUiThread(() -> appendOutput(
                            "[NOTIF] " + (pkg != null ? pkg : "system") + " -> " +
                            (title != null && !title.isEmpty() ? title + ": " : "") +
                            (text != null ? text : "") + "\n"
                        ));
                    }

                    @Override
                    public void onStopSessionRequested() {
                        runOnUiThread(() -> {
                            appendOutput("[SESSION STOPPED FROM NOTIFICATION]\n");
                            stopPlayback();
                            finishAffinity();
                        });
                    }
                });
            }
        }, 300);
    }

    private void triggerStorageAccessFromTerminal(TerminalSession s) {
        List<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                needed.add(android.Manifest.permission.READ_MEDIA_AUDIO);
            }
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_IMAGES)
                != PackageManager.PERMISSION_GRANTED) {
                needed.add(android.Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                needed.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                needed.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        }

        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), REQ_STORAGE_PERM);
            appendOutput("Requesting storage permission... Approve the dialog on screen.\n");
        }

        setupStorageLinksInHome();
        appendOutput("Storage shortcut folder ready at: " + new File(appHomeDir, "storage").getAbsolutePath() + "\n");
        appendOutput("  ~/storage/shared    -> " + Environment.getExternalStorageDirectory().getAbsolutePath() + "\n");
        appendOutput("  ~/storage/music     -> " + Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).getAbsolutePath() + "\n");
        appendOutput("  ~/storage/downloads -> " + Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + "\n");
    }

    private void setupStorageLinksInHome() {
        try {
            File storageRoot = new File(appHomeDir, "storage");
            if (!storageRoot.exists()) storageRoot.mkdirs();

            linkOrRefDir(new File(storageRoot, "shared"), Environment.getExternalStorageDirectory());
            linkOrRefDir(new File(storageRoot, "music"), Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC));
            linkOrRefDir(new File(storageRoot, "downloads"), Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
            linkOrRefDir(new File(storageRoot, "dcim"), Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM));
            linkOrRefDir(new File(storageRoot, "pictures"), Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
        } catch (Exception ignored) {
        }
    }

    private void linkOrRefDir(File linkFile, File targetDir) {
        if (targetDir == null) return;
        try {
            if (linkFile.exists()) {
                if (Files.isSymbolicLink(linkFile.toPath())) {
                    linkFile.delete();
                } else {
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Files.createSymbolicLink(linkFile.toPath(), Paths.get(targetDir.getAbsolutePath()));
            }
        } catch (Exception ignored) {
        }
    }

    private List<File> findAudioFiles(String query) {
        List<File> results = new ArrayList<>();
        List<File> searchRoots = new ArrayList<>();
        searchRoots.add(appHomeDir);
        File extStorage = Environment.getExternalStorageDirectory();
        if (extStorage != null && extStorage.exists()) {
            searchRoots.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC));
            searchRoots.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
            searchRoots.add(extStorage);
        }

        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        for (File root : searchRoots) {
            if (root == null || !root.exists()) continue;
            scanAudioRecursive(root, q, results, 0);
            if (results.size() >= 30) break;
        }
        return results;
    }

    private void scanAudioRecursive(File dir, String q, List<File> out, int depth) {
        if (depth > 3 || out.size() >= 30) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (out.size() >= 30) return;
            if (f.isDirectory()) {
                if (!f.getName().startsWith(".")) {
                    scanAudioRecursive(f, q, out, depth + 1);
                }
            } else {
                String lower = f.getName().toLowerCase(Locale.ROOT);
                if (lower.endsWith(".mp3") || lower.endsWith(".m4a") || lower.endsWith(".wav") ||
                    lower.endsWith(".ogg") || lower.endsWith(".flac") || lower.endsWith(".aac")) {
                    if (q.isEmpty() || lower.contains(q)) {
                        out.add(f);
                    }
                }
            }
        }
    }

    private boolean playAudioFile(File audioFile) {
        try {
            stopPlayback();
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(audioFile.getAbsolutePath());
            mediaPlayer.prepare();
            mediaPlayer.start();
            currentTrackName = audioFile.getName();
            TerminalBackgroundService svc = TerminalBackgroundService.getInstance();
            if (svc != null) {
                svc.updateNotificationText("Playing: " + currentTrackName);
            }
            mediaPlayer.setOnCompletionListener(mp -> {
                runOnUiThread(() -> appendOutput("[MUSIC] Finished: " + currentTrackName + "\n"));
                currentTrackName = null;
                if (svc != null) {
                    svc.updateNotificationText("Session active in background");
                }
            });
            return true;
        } catch (Exception e) {
            appendOutput("play: error playing '" + audioFile.getName() + "': " + e.getMessage() + "\n");
            return false;
        }
    }

    private void stopPlayback() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
        currentTrackName = null;
        TerminalBackgroundService svc = TerminalBackgroundService.getInstance();
        if (svc != null) {
            svc.updateNotificationText("Session active in background");
        }
    }

    private void handlePlayCommand(String cmd, String[] parts, TerminalSession s) {
        if (parts.length < 2) {
            appendOutput("Usage: play <filename or song keyword>  |  music [list|stop|pause|resume|vol <0-100>]\n");
            return;
        }
        String arg = cmd.substring(parts[0].length()).trim();
        File direct = arg.startsWith("/") ? new File(arg) : new File(s.currentDir, arg);
        if (direct.exists() && direct.isFile()) {
            if (playAudioFile(direct)) {
                appendOutput("Playing: " + direct.getAbsolutePath() + "\n");
            }
            return;
        }

        List<File> matches = findAudioFiles(arg);
        if (matches.isEmpty()) {
            appendOutput("No audio file matching '" + arg + "'. Run 'storage-access' first if needed.\n");
            return;
        }
        File chosen = matches.get(0);
        if (playAudioFile(chosen)) {
            appendOutput("Playing: " + chosen.getName() + " (" + chosen.getParentFile().getAbsolutePath() + ")\n");
        }
    }

    private void handleMusicCommand(String[] parts) {
        if (parts.length < 2) {
            if (mediaPlayer != null) {
                appendOutput("Current track: " + (currentTrackName != null ? currentTrackName : "unknown") +
                             " (" + (mediaPlayer.isPlaying() ? "Playing" : "Paused") + ")\n");
            } else {
                appendOutput("No track playing. Use 'play <song>' or 'music list'.\n");
            }
            return;
        }
        String sub = parts[1].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            String q = parts.length >= 3 ? parts[2] : "";
            List<File> found = findAudioFiles(q);
            if (found.isEmpty()) {
                appendOutput("No songs found. Run 'storage-access' first to grant media access.\n");
            } else {
                appendOutput("Found " + found.size() + " audio file(s):\n");
                for (int i = 0; i < found.size(); i++) {
                    appendOutput("  [" + (i + 1) + "] " + found.get(i).getName() + "\n");
                }
            }
        } else if (sub.equals("stop")) {
            stopPlayback();
            appendOutput("Playback stopped.\n");
        } else if (sub.equals("pause")) {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                appendOutput("Paused: " + currentTrackName + "\n");
            }
        } else if (sub.equals("resume")) {
            if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
                mediaPlayer.start();
                appendOutput("Resumed: " + currentTrackName + "\n");
            }
        } else if (sub.equals("vol") && parts.length >= 3) {
            try {
                int pct = Math.max(0, Math.min(100, Integer.parseInt(parts[2])));
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                if (am != null) {
                    int maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    int targetVol = Math.round((pct / 100f) * maxVol);
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0);
                    appendOutput("Media volume set to " + pct + "%\n");
                }
            } catch (NumberFormatException ignored) {
                appendOutput("Usage: music vol <0-100>\n");
            }
        }
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> pkgAppsList = pm.queryIntentActivities(mainIntent, 0);
        allInstalledApps.clear();
        for (ResolveInfo ri : pkgAppsList) {
            String label = ri.loadLabel(pm).toString();
            String pkg = ri.activityInfo.packageName;
            Drawable icon = ri.loadIcon(pm);
            if (!pkg.equals(getPackageName())) {
                allInstalledApps.add(new AppItem(label, pkg, icon));
            }
        }
        Collections.sort(allInstalledApps, (a, b) -> a.label.compareToIgnoreCase(b.label));

        filteredInstalledApps.clear();
        filteredInstalledApps.addAll(allInstalledApps);

        appIconAdapter = new AppIconAdapter(filteredInstalledApps);
        lvInstalledApps.setAdapter(appIconAdapter);
        lvInstalledApps.setOnItemClickListener((parent, view, position, id) -> {
            AppItem selected = filteredInstalledApps.get(position);
            drawerLayout.closeDrawer(GravityCompat.START);
            launchAppByPackage(selected.packageName);
        });

        if (customManager.isShowAppDock()) {
            rebuildBottomAppDock();
        }
    }

    private void filterApps(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();
        filteredInstalledApps.clear();
        if (q.isEmpty()) {
            filteredInstalledApps.addAll(allInstalledApps);
        } else {
            for (AppItem item : allInstalledApps) {
                if (item.label.toLowerCase().contains(q) || item.packageName.toLowerCase().contains(q)) {
                    filteredInstalledApps.add(item);
                }
            }
        }
        if (appIconAdapter != null) {
            appIconAdapter.notifyDataSetChanged();
        }
    }

    private void launchAppByPackage(String packageName) {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            startActivity(launchIntent);
        } else {
            Toast.makeText(this, "Cannot launch " + packageName, Toast.LENGTH_SHORT).show();
        }
    }

    private void showWindowPicker() {
        String[] titles = new String[sessions.size()];
        for (int i = 0; i < sessions.size(); i++) {
            titles[i] = sessions.get(i).title;
        }
        new AlertDialog.Builder(this)
            .setTitle("Select Window")
            .setItems(titles, (dialog, which) -> loadSession(which))
            .show();
    }

    private void showMoreMenu() {
        String[] options = {
            "UI Theme & Customize Settings",
            "Zoom In (+)",
            "Zoom Out (-)",
            "Reset Zoom (100%)",
            "Sync Termux Repo (pkg update)",
            "Android Settings",
            "Clear Terminal"
        };
        new AlertDialog.Builder(this)
            .setTitle("TermLauncher Options")
            .setItems(options, (dialog, which) -> {
                if (which == 0) showCustomizeDialog();
                else if (which == 1) executeCommand("zoom in");
                else if (which == 2) executeCommand("zoom out");
                else if (which == 3) executeCommand("zoom reset");
                else if (which == 4) executeCommand("pkg update");
                else if (which == 5) startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                else if (which == 6) executeCommand("clear");
            })
            .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE_PERM) {
            boolean anyGranted = false;
            if (grantResults != null) {
                for (int r : grantResults) {
                    if (r == PackageManager.PERMISSION_GRANTED) {
                        anyGranted = true;
                        break;
                    }
                }
            }
            if (anyGranted) {
                setupStorageLinksInHome();
                appendOutput("[storage-access] Storage/media permission granted! Links ready in ~/storage/\n");
            } else {
                appendOutput("[storage-access] Permission denied or still needed. Check App Info -> Permissions if required.\n");
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }
}
