package com.kalipocket;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;

public class MainActivity extends Activity {
    interface TextAction { void accept(String value); }

    private GridLayout modules;
    private TextView output;
    private TextView status;
    private TextView metricCpu;
    private TextView metricRam;
    private TextView metricBattery;
    private TextView rootModeStatus;
    private TextView rootModeAction;
    private ScrollView mainScroll;
    private LinearLayout rootModeCard;
    private boolean rootMode = false;

    private final Handler metricsHandler = new Handler(Looper.getMainLooper());
    private final Runnable metricsTicker = new Runnable() {
        @Override public void run() {
            updateMetrics();
            metricsHandler.postDelayed(this, 5000);
        }
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        modules = findViewById(R.id.modulesContainer);
        output = findViewById(R.id.outputText);
        status = findViewById(R.id.statusText);
        metricCpu = findViewById(R.id.metricCpu);
        metricRam = findViewById(R.id.metricRam);
        metricBattery = findViewById(R.id.metricBattery);
        rootModeStatus = findViewById(R.id.rootModeStatus);
        rootModeAction = findViewById(R.id.rootModeAction);
        rootModeCard = findViewById(R.id.rootModeCard);
        mainScroll = findViewById(R.id.mainScroll);

        status.setText("DEVICE  •  " + Build.MANUFACTURER + " " + Build.MODEL
                + "\nANDROID  •  " + Build.VERSION.RELEASE + "  |  API " + Build.VERSION.SDK_INT);

        addTool("⌘", "Terminal", "Execute shell commands", () -> terminal());
        addTool("⌁", "Network Scanner", "Discover hosts on your authorized local network", () -> scan());
        addTool("⬡", "Security Audit", "Read-only device security checks", () -> audit());
        addTool("▥", "System Monitor", "Memory, CPU and uptime snapshot", () -> monitor());
        addTool("▧", "File Analyzer", "File metadata and SHA-256 hash", () -> file());
        addTool("≋", "Log Analyzer", "Read recent system log output", () -> logs());
        addTool("⌘", "ADB Tools", "Safe ADB command reference", () -> adb());
        addTool("▶", "Script Runner", "Run a script after confirmation", () -> script());

        rootModeCard.setOnClickListener(v -> toggleRootMode());
        rootModeAction.setOnClickListener(v -> toggleRootMode());

        findViewById(R.id.clearOutput).setOnClickListener(v -> {
            output.setText("Console cleared.\n");
        });

        findViewById(R.id.navHome).setOnClickListener(v -> mainScroll.smoothScrollTo(0, 0));
        findViewById(R.id.navTools).setOnClickListener(v -> {
            mainScroll.smoothScrollTo(0, modules.getTop());
        });
        findViewById(R.id.navTerminal).setOnClickListener(v -> terminal());
        findViewById(R.id.navRoot).setOnClickListener(v -> toggleRootMode());

        updateRootUi();
        updateMetrics();
        append("Kali Pocket initialized. Authorized testing only.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        metricsHandler.removeCallbacks(metricsTicker);
        metricsHandler.post(metricsTicker);
    }

    @Override
    protected void onPause() {
        metricsHandler.removeCallbacks(metricsTicker);
        super.onPause();
    }

    private void updateMetrics() {
        metricCpu.setText(String.valueOf(Runtime.getRuntime().availableProcessors()));

        try {
            ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            long used = Math.max(0L, info.totalMem - info.availMem);
            metricRam.setText(formatBytes(used));
        } catch (Exception e) {
            metricRam.setText("N/A");
        }

        try {
            Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery != null) {
                int level = battery.getIntExtra("level", -1);
                int scale = battery.getIntExtra("scale", -1);
                if (level >= 0 && scale > 0) {
                    metricBattery.setText((level * 100 / scale) + "%");
                } else {
                    metricBattery.setText("N/A");
                }
            } else {
                metricBattery.setText("N/A");
            }
        } catch (Exception e) {
            metricBattery.setText("N/A");
        }
    }

    private String formatBytes(long bytes) {
        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
        if (gb >= 1.0) return String.format(Locale.US, "%.1f GB", gb);
        return String.format(Locale.US, "%.0f MB", bytes / (1024.0 * 1024.0));
    }

    private void addTool(String glyph, String title, String description, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(13), dp(12), dp(13));
        card.setMinimumHeight(dp(132));
        card.setBackground(rounded(0xFF121E16, 0xFF293B30, 17));

        TextView icon = new TextView(this);
        icon.setText(glyph);
        icon.setTextColor(0xFFB7FF4A);
        icon.setTextSize(23);
        icon.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(rounded(0xFF1B2C20, 0xFF304834, 11));
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(38), dp(38));
        card.addView(icon, iconParams);

        TextView name = new TextView(this);
        name.setText(title);
        name.setTextColor(0xFFF1F8F2);
        name.setTextSize(13);
        name.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        name.setMaxLines(1);
        name.setPadding(0, dp(10), 0, 0);
        card.addView(name);

        TextView detail = new TextView(this);
        detail.setText(description);
        detail.setTextColor(0xFF91A99A);
        detail.setTextSize(10);
        detail.setMaxLines(2);
        detail.setPadding(0, dp(4), 0, 0);
        card.addView(detail);

        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> action.run());

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = dp(132);
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f);
        params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED);
        params.setMargins(dp(5), dp(5), dp(5), dp(5));
        modules.addView(card, params);
    }

    private GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toggleRootMode() {
        rootMode = !rootMode;
        updateRootUi();
        append("Root mode " + (rootMode ? "enabled" : "disabled")
                + ". Superuser access is requested only when a command is run.");
    }

    private void updateRootUi() {
        String state = rootMode ? "ON" : "OFF";
        rootModeStatus.setText("ROOT MODE  /  " + state);
        rootModeAction.setText(state);
        int color = rootMode ? 0xFFB7FF4A : 0xFF91A99A;
        rootModeStatus.setTextColor(color);
        rootModeAction.setTextColor(color);
    }

    private void append(String message) {
        runOnUiThread(() -> {
            output.append("\n" + message);
            if (output.length() > 24000) {
                output.setText(output.getText().subSequence(output.length() - 18000, output.length()));
            }
        });
    }

    private void ask(String title, String hint, boolean multiLine, TextAction done) {
        EditText edit = new EditText(this);
        edit.setTextColor(0xFFF1F8F2);
        edit.setHintTextColor(0xFF91A99A);
        edit.setHint(hint);
        edit.setSingleLine(!multiLine);
        if (multiLine) {
            edit.setMinLines(5);
            edit.setGravity(Gravity.TOP);
            edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        }
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(edit)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Run", (dialog, which) -> done.accept(edit.getText().toString()))
                .show();
    }

    private void shell(String command) {
        new Thread(() -> {
            try {
                java.lang.Process process = new ProcessBuilder(
                        rootMode
                                ? new String[]{"su", "-c", command}
                                : new String[]{"sh", "-c", command}
                ).redirectErrorStream(true).start();

                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) result.append(line).append("\n");
                int exitCode = process.waitFor();
                append("$ " + command + "\n" + result + "Exit: " + exitCode);
            } catch (Exception e) {
                append("Shell error: " + e.getMessage());
            }
        }).start();
    }

    private void terminal() {
        ask("Terminal", "id | getprop ro.build.version.release", false, command -> {
            if (!command.trim().isEmpty()) shell(command);
        });
    }

    private String runCommand(String command) throws Exception {
        java.lang.Process process = new ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true).start();
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) result.append(line).append("\n");
        process.waitFor();
        return result.toString().trim();
    }

    private void audit() {
        new Thread(() -> {
            try {
                append("=== READ-ONLY SECURITY AUDIT ===\nBuild: " + Build.FINGERPRINT
                        + "\nDebug build: " + (!"user".equals(Build.TYPE))
                        + "\nADB enabled: " + (Settings.Global.getInt(getContentResolver(), "adb_enabled", 0) == 1)
                        + "\nSELinux: " + runCommand("getenforce")
                        + "\nSu path visible: " + (new File("/system/bin/su").exists()
                        || new File("/system/xbin/su").exists()));
            } catch (Exception e) {
                append("Audit error: " + e.getMessage());
            }
        }).start();
    }

    private void monitor() {
        new Thread(() -> {
            try {
                append("=== SYSTEM MONITOR ===\n" + runCommand("head -n 5 /proc/meminfo")
                        + "\nUptime: " + runCommand("cat /proc/uptime")
                        + "\nCPU: " + runCommand("head -n 5 /proc/stat")
                        + "\nSELinux: " + runCommand("getenforce"));
            } catch (Exception e) {
                append("Monitor error: " + e.getMessage());
            }
        }).start();
    }

    private void file() {
        ask("File Analyzer", "/sdcard/Download/file.txt", false, path -> new Thread(() -> {
            try {
                File file = new File(path);
                if (!file.isFile()) {
                    append("Not a regular file: " + path);
                    return;
                }
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                InputStream input = new FileInputStream(file);
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) > 0) digest.update(buffer, 0, count);
                input.close();

                StringBuilder hash = new StringBuilder();
                for (byte value : digest.digest()) hash.append(String.format(Locale.US, "%02x", value));
                append("FILE: " + file.getAbsolutePath()
                        + "\nSIZE: " + file.length() + " bytes"
                        + "\nMODIFIED: " + new Date(file.lastModified())
                        + "\nSHA-256: " + hash);
            } catch (Exception e) {
                append("File error: " + e.getMessage());
            }
        }).start());
    }

    private void logs() {
        new AlertDialog.Builder(this)
                .setTitle("Log Analyzer")
                .setMessage("System log access may be restricted. Root mode may show a Superuser prompt.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Read", (dialog, which) -> shell("logcat -d -t 200"))
                .show();
    }

    private void adb() {
        append("ADB QUICK REFERENCE (run on an authorized host):"
                + "\nadb devices"
                + "\nadb shell getprop ro.build.version.release"
                + "\nadb shell pm list packages"
                + "\nadb logcat -d -t 200"
                + "\nThis app does not host an external ADB server.");
    }

    private void script() {
        ask("Script Runner", "echo Hello\nid\ngetprop ro.build.version.release", true, script -> {
            if (script.trim().isEmpty()) return;
            new AlertDialog.Builder(this)
                    .setTitle("Execute script?")
                    .setMessage("Only run scripts you understand and trust. Root mode: " + rootMode)
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("I understand", (dialog, which) -> shell(script))
                    .show();
        });
    }

    private void scan() {
        new AlertDialog.Builder(this)
                .setTitle("Authorized LAN scan")
                .setMessage("Checks responsive hosts on your current local IPv4 /24. Continue only with permission.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Scan", (dialog, which) -> new Thread(() -> {
                    try {
                        String localIp = null;
                        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
                        while (interfaces.hasMoreElements()) {
                            NetworkInterface network = interfaces.nextElement();
                            if (!network.isUp() || network.isLoopback()) continue;
                            Enumeration<InetAddress> addresses = network.getInetAddresses();
                            while (addresses.hasMoreElements()) {
                                InetAddress address = addresses.nextElement();
                                if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
                                    localIp = address.getHostAddress();
                                    break;
                                }
                            }
                            if (localIp != null) break;
                        }

                        if (localIp == null) {
                            append("No active IPv4 network.");
                            return;
                        }
                        String[] octets = localIp.split("\\.");
                        if (octets.length != 4) {
                            append("Invalid IPv4: " + localIp);
                            return;
                        }

                        append("Local IP: " + localIp + "\nScanning local /24...");
                        for (int i = 1; i < 255; i++) {
                            String ip = octets[0] + "." + octets[1] + "." + octets[2] + "." + i;
                            try {
                                if (InetAddress.getByName(ip).isReachable(150)) append("Responsive: " + ip);
                            } catch (Exception ignored) { }
                        }
                        append("Scan complete. Firewalls may hide active hosts.");
                    } catch (Exception e) {
                        append("Scan error: " + e.getMessage());
                    }
                }).start())
                .show();
    }
}
