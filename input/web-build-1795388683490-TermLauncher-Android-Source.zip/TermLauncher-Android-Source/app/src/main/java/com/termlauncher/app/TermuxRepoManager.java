package com.termlauncher.app;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;

public class TermuxRepoManager {

    public interface OutputCallback {
        void onLog(String text);
        void onComplete(boolean success);
    }

    private static final String[] REPO_MIRRORS = {
        "https://packages-cf.termux.dev/apt/termux-main/",
        "https://packages.termux.dev/apt/termux-main/"
    };

    private final File rootDir;
    private final File prefixDir;
    private final File binDir;
    private final File cacheDir;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final Map<String, PackageMeta> packageIndex = new HashMap<>();
    private final Set<String> installedSet = new HashSet<>();

    public static class PackageMeta {
        public String name;
        public String version;
        public String filename;
        public String size;
        public String description;
        public List<String> depends = new ArrayList<>();
    }

    public TermuxRepoManager(File appFilesDir) {
        this.rootDir = appFilesDir;
        this.prefixDir = new File(rootDir, "usr");
        this.binDir = new File(prefixDir, "bin");
        this.cacheDir = new File(rootDir, "cache");
        if (!binDir.exists()) binDir.mkdirs();
        if (!cacheDir.exists()) cacheDir.mkdirs();
        setupBinHelpers();
    }

    public File getBinDir() {
        return binDir;
    }

    public File getPrefixDir() {
        return prefixDir;
    }

    public File getRootDir() {
        return rootDir;
    }

    /**
     * Creates convenience wrapper scripts inside $PREFIX/bin for su and adb
     * so commands like `su` or `adb` resolve reliably from the bin directory.
     */
    public void setupBinHelpers() {
        try {
            if (!binDir.exists()) binDir.mkdirs();

            // Wrapper script for `su`
            File suWrapper = new File(binDir, "su");
            String suScript = "#!/system/bin/sh\n" +
                "for p in /sbin/su /system/bin/su /system/xbin/su /vendor/bin/su /debug_ramdisk/su /data/adb/ksu/bin/su /data/adb/ap/bin/su; do\n" +
                "  if [ -x \"$p\" ]; then\n" +
                "    exec \"$p\" \"$@\"\n" +
                "  fi\n" +
                "done\n" +
                "echo 'su: root binary (su) not found or device is not rooted.' >&2\n" +
                "exit 127\n";
            try (FileOutputStream fos = new FileOutputStream(suWrapper)) {
                fos.write(suScript.getBytes("UTF-8"));
            }
            suWrapper.setExecutable(true, false);

            // Wrapper script for `adb`
            File adbWrapper = new File(binDir, "adb");
            String adbScript = "#!/system/bin/sh\n" +
                "for p in /data/data/com.termlauncher.app/files/usr/bin/adb.bin /system/bin/adb /vendor/bin/adb; do\n" +
                "  if [ -x \"$p\" ]; then\n" +
                "    exec \"$p\" \"$@\"\n" +
                "  fi\n" +
                "done\n" +
                "echo 'adb: standalone adb binary not installed yet.' >&2\n" +
                "echo 'Tip: For local shell commands on Android, use shell commands directly or enable Wireless Debugging / Shizuku / ADB TCP.' >&2\n" +
                "exit 127\n";
            try (FileOutputStream fos = new FileOutputStream(adbWrapper)) {
                fos.write(adbScript.getBytes("UTF-8"));
            }
            adbWrapper.setExecutable(true, false);
        } catch (Exception ignored) {
        }
    }

    private String getDeviceArch() {
        String[] abis = Build.SUPPORTED_ABIS;
        if (abis != null && abis.length > 0) {
            String primary = abis[0];
            if (primary.contains("arm64")) return "aarch64";
            if (primary.contains("armeabi")) return "arm";
            if (primary.contains("x86_64")) return "x86_64";
            if (primary.contains("x86")) return "i686";
        }
        return "aarch64";
    }

    private void postLog(OutputCallback cb, String msg) {
        mainHandler.post(() -> cb.onLog(msg + "\n"));
    }

    public void updateRepo(OutputCallback cb) {
        new Thread(() -> {
            String arch = getDeviceArch();
            String indexPath = "dists/stable/main/binary-" + arch + "/Packages.gz";
            postLog(cb, "Get:1 https://packages-cf.termux.dev/apt/termux-main stable InRelease");
            postLog(cb, "Get:2 https://packages-cf.termux.dev/apt/termux-main stable/main " + arch + " Packages");

            boolean fetched = false;
            for (String mirror : REPO_MIRRORS) {
                try {
                    URL url = new URL(mirror + indexPath);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestProperty("User-Agent", "Termux-APT/2.6 (Android)");

                    if (conn.getResponseCode() == 200) {
                        File outGz = new File(cacheDir, "Packages.gz");
                        try (InputStream in = conn.getInputStream();
                             FileOutputStream fos = new FileOutputStream(outGz)) {
                            byte[] buf = new byte[8192];
                            int len;
                            while ((len = in.read(buf)) != -1) {
                                fos.write(buf, 0, len);
                            }
                        }
                        parsePackagesGz(outGz);
                        fetched = true;
                        break;
                    }
                } catch (Exception e) {
                    postLog(cb, "Mirror warning (" + mirror + "): " + e.getMessage());
                }
            }

            if (fetched) {
                postLog(cb, "Fetched Termux " + arch + " index (" + packageIndex.size() + " packages available).");
                postLog(cb, "Reading package lists... Done");
                mainHandler.post(() -> cb.onComplete(true));
            } else {
                postLog(cb, "E: Failed to fetch Termux repository. Check internet connection.");
                mainHandler.post(() -> cb.onComplete(false));
            }
        }).start();
    }

    private void parsePackagesGz(File gzFile) throws Exception {
        packageIndex.clear();
        try (GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(gzFile));
             BufferedReader br = new BufferedReader(new InputStreamReader(gzis))) {
            String line;
            PackageMeta current = new PackageMeta();
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    if (current.name != null && current.filename != null) {
                        packageIndex.put(current.name, current);
                    }
                    current = new PackageMeta();
                } else if (line.startsWith("Package: ")) {
                    current.name = line.substring(9).trim();
                } else if (line.startsWith("Version: ")) {
                    current.version = line.substring(9).trim();
                } else if (line.startsWith("Filename: ")) {
                    current.filename = line.substring(10).trim();
                } else if (line.startsWith("Size: ")) {
                    current.size = line.substring(6).trim();
                } else if (line.startsWith("Description: ")) {
                    current.description = line.substring(13).trim();
                } else if (line.startsWith("Depends: ")) {
                    String depsRaw = line.substring(9).trim();
                    for (String token : depsRaw.split(",")) {
                        // Take first alternative if 'pkgA | pkgB', strip version constraints '(>= ...)'
                        String alt = token.split("\\|")[0].trim();
                        int paren = alt.indexOf('(');
                        if (paren > 0) alt = alt.substring(0, paren).trim();
                        if (!alt.isEmpty()) {
                            current.depends.add(alt);
                        }
                    }
                }
            }
            if (current.name != null && current.filename != null) {
                packageIndex.put(current.name, current);
            }
        }
    }

    public void searchPackage(String query, OutputCallback cb) {
        if (packageIndex.isEmpty()) {
            postLog(cb, "Package index empty. Run 'pkg update' first.");
            cb.onComplete(false);
            return;
        }
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (PackageMeta meta : packageIndex.values()) {
            if (meta.name.contains(query) || (meta.description != null && meta.description.toLowerCase().contains(query.toLowerCase()))) {
                sb.append(meta.name).append("/stable ").append(meta.version).append("\n");
                if (meta.description != null) {
                    sb.append("  ").append(meta.description).append("\n");
                }
                count++;
                if (count >= 25) {
                    sb.append("... (showing first 25 matches)\n");
                    break;
                }
            }
        }
        if (count == 0) {
            postLog(cb, "No packages found matching '" + query + "'.");
        } else {
            postLog(cb, sb.toString());
        }
        cb.onComplete(true);
    }

    public void installPackage(String pkgName, OutputCallback cb) {
        new Thread(() -> {
            if (packageIndex.isEmpty()) {
                postLog(cb, "Updating Termux package index first...");
                try {
                    String arch = getDeviceArch();
                    URL url = new URL(REPO_MIRRORS[0] + "dists/stable/main/binary-" + arch + "/Packages.gz");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    File outGz = new File(cacheDir, "Packages.gz");
                    try (InputStream in = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(outGz)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                    }
                    parsePackagesGz(outGz);
                } catch (Exception e) {
                    postLog(cb, "E: Unable to reach Termux repo: " + e.getMessage());
                    mainHandler.post(() -> cb.onComplete(false));
                    return;
                }
            }

            Set<String> visited = new HashSet<>();
            boolean ok = installPackageRecursive(pkgName, cb, visited);
            setupBinHelpers();
            mainHandler.post(() -> cb.onComplete(ok));
        }).start();
    }

    private boolean installPackageRecursive(String pkgName, OutputCallback cb, Set<String> visited) {
        if (visited.contains(pkgName) || installedSet.contains(pkgName)) {
            return true;
        }
        visited.add(pkgName);

        PackageMeta meta = packageIndex.get(pkgName);
        if (meta == null) {
            postLog(cb, "E: Unable to locate package " + pkgName);
            return false;
        }

        // Install dependencies first (e.g. ncurses for cmatrix)
        for (String dep : meta.depends) {
            if (!installedSet.contains(dep) && packageIndex.containsKey(dep)) {
                postLog(cb, "Installing dependency: " + dep);
                installPackageRecursive(dep, cb, visited);
            }
        }

        postLog(cb, "The following NEW packages will be installed:\n  " + meta.name + " (" + meta.version + ")");
        postLog(cb, "Get:1 " + REPO_MIRRORS[0] + meta.filename + " [" + meta.size + " B]");

        try {
            URL debUrl = new URL(REPO_MIRRORS[0] + meta.filename);
            HttpURLConnection conn = (HttpURLConnection) debUrl.openConnection();
            conn.setRequestProperty("User-Agent", "Termux-APT/2.6");
            File debFile = new File(cacheDir, meta.name + ".deb");

            try (InputStream in = new BufferedInputStream(conn.getInputStream());
                 FileOutputStream fos = new FileOutputStream(debFile)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = in.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                }
            }

            postLog(cb, "Unpacking " + meta.name + " (" + meta.version + ") ...");
            extractDebPackage(debFile, cb);
            installedSet.add(meta.name);
            postLog(cb, "Setting up " + meta.name + " (" + meta.version + ") ... Done.");
            return true;
        } catch (Exception e) {
            postLog(cb, "E: Error installing " + pkgName + ": " + e.getMessage());
            return false;
        }
    }

    private void extractDebPackage(File debFile, OutputCallback cb) throws Exception {
        try (FileInputStream fis = new FileInputStream(debFile)) {
            byte[] magic = new byte[8];
            if (fis.read(magic) != 8) throw new Exception("Invalid .deb archive");

            while (true) {
                byte[] header = new byte[60];
                int read = fis.read(header);
                if (read < 60) break;

                String name = new String(header, 0, 16).trim();
                String sizeStr = new String(header, 48, 10).trim();
                long size = Long.parseLong(sizeStr);

                if (name.startsWith("data.tar")) {
                    File tarOut = new File(cacheDir, name);
                    try (FileOutputStream fos = new FileOutputStream(tarOut)) {
                        long remaining = size;
                        byte[] buf = new byte[8192];
                        while (remaining > 0) {
                            int toRead = (int) Math.min(buf.length, remaining);
                            int r = fis.read(buf, 0, toRead);
                            if (r <= 0) break;
                            fos.write(buf, 0, r);
                            remaining -= r;
                        }
                    }

                    // Termux .deb archives use data.tar.xz (or .gz/.zst).
                    // Try tar -xf directly; if xz is needed and tar fails, try unxz/xzcat
                    String cmdStr;
                    if (name.endsWith(".xz")) {
                        cmdStr = "tar -xf '" + tarOut.getAbsolutePath() + "' -C '" + rootDir.getAbsolutePath() + "' || " +
                                 "(xz -dc '" + tarOut.getAbsolutePath() + "' | tar -xf - -C '" + rootDir.getAbsolutePath() + "')";
                    } else if (name.endsWith(".gz")) {
                        cmdStr = "tar -xzf '" + tarOut.getAbsolutePath() + "' -C '" + rootDir.getAbsolutePath() + "'";
                    } else {
                        cmdStr = "tar -xf '" + tarOut.getAbsolutePath() + "' -C '" + rootDir.getAbsolutePath() + "'";
                    }

                    ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", cmdStr);
                    Process p = pb.start();
                    int exitCode = p.waitFor();
                    if (exitCode != 0) {
                        postLog(cb, "Warning: tar exited with code " + exitCode + " on " + name);
                    }

                    // Make all extracted binaries & libraries executable
                    makeExecutableRecursive(binDir);
                    File libDir = new File(prefixDir, "lib");
                    if (libDir.exists()) {
                        makeExecutableRecursive(libDir);
                    }
                    break;
                } else {
                    long skipBytes = size + (size % 2);
                    long skipped = 0;
                    while (skipped < skipBytes) {
                        long s = fis.skip(skipBytes - skipped);
                        if (s <= 0) break;
                        skipped += s;
                    }
                }
            }
        }
    }

    private void makeExecutableRecursive(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                makeExecutableRecursive(f);
            } else {
                f.setExecutable(true, false);
            }
        }
    }
}
