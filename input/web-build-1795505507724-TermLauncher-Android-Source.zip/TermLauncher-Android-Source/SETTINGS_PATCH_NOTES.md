# TermLauncher Settings Patch (AndroidForge Safe)

This patch updates `SettingsActivity.java` and `activity_settings.xml` to prevent UI listener cascade loops, null-pointer crashes on missing views, stale labels on wallpaper clear/resume, and AndroidX `app:tint` compatibility during AndroidForge builds.

## Included Files
- `app/src/main/java/com/termlauncher/app/SettingsActivity.java`
- `app/src/main/res/layout/activity_settings.xml`
