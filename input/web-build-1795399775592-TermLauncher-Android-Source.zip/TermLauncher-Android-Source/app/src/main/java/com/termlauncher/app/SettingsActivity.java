package com.termlauncher.app;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class SettingsActivity extends AppCompatActivity {

    private CustomizationManager customManager;
    private ActivityResultLauncher<String[]> pickWallpaperLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        customManager = new CustomizationManager(this);

        pickWallpaperLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri != null) {
                    try {
                        getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                    } catch (Exception ignored) {
                    }
                    if (customManager.saveWallpaperFromUri(uri)) {
                        Toast.makeText(this, "Wallpaper updated!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to load image.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );

        ImageButton btnBack = findViewById(R.id.btn_settings_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        ScrollView scrollView = findViewById(R.id.settings_scroll_view);
        TextView tvAboutHeader = findViewById(R.id.tv_about_section_header);
        Button btnTabAbout = findViewById(R.id.btn_tab_about);
        if (btnTabAbout != null) {
            btnTabAbout.setOnClickListener(v -> {
                if (scrollView != null && tvAboutHeader != null) {
                    scrollView.smoothScrollTo(0, tvAboutHeader.getTop());
                }
            });
        }

        Spinner spUiStyle = findViewById(R.id.sp_ui_style);
        Spinner spPromptStyle = findViewById(R.id.sp_prompt_style);
        CheckBox cbSessionTabs = findViewById(R.id.cb_session_tabs);
        CheckBox cbQuickChips = findViewById(R.id.cb_quick_chips);
        CheckBox cbAppDock = findViewById(R.id.cb_app_dock);
        CheckBox cbHudBorder = findViewById(R.id.cb_hud_border);
        CheckBox cbCrtScanlines = findViewById(R.id.cb_crt_scanlines);

        Spinner spFont = findViewById(R.id.sp_font_style);
        SeekBar sbFontSize = findViewById(R.id.sb_font_size);
        TextView tvZoomLabel = findViewById(R.id.tv_zoom_label);
        Spinner spTextColor = findViewById(R.id.sp_text_color);
        Spinner spPromptColor = findViewById(R.id.sp_prompt_color);
        Spinner spBgTheme = findViewById(R.id.sp_bg_theme);
        SeekBar sbDim = findViewById(R.id.sb_bg_dim);
        TextView tvDimLabel = findViewById(R.id.tv_dim_label);
        Button btnPickWp = findViewById(R.id.btn_pick_wallpaper);
        Button btnClearWp = findViewById(R.id.btn_clear_wallpaper);

        ArrayAdapter<String> uiStyleAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.UI_STYLE_NAMES
        );
        spUiStyle.setAdapter(uiStyleAdapter);
        spUiStyle.setSelection(customManager.getUiStyle());

        ArrayAdapter<String> promptStyleAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.PROMPT_STYLE_NAMES
        );
        spPromptStyle.setAdapter(promptStyleAdapter);
        spPromptStyle.setSelection(customManager.getPromptStyle());

        cbSessionTabs.setChecked(customManager.isShowSessionTabs());
        cbQuickChips.setChecked(customManager.isShowQuickChips());
        cbAppDock.setChecked(customManager.isShowAppDock());
        cbHudBorder.setChecked(customManager.isShowHudBorder());
        cbCrtScanlines.setChecked(customManager.isShowCrtScanlines());

        ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.FONT_LABELS
        );
        spFont.setAdapter(fontAdapter);
        spFont.setSelection(customManager.getFontStyleIndex());

        int initialSize = Math.round(customManager.getFontSizeSp());
        int progressVal = Math.max(0, Math.min(22, initialSize - 8));
        sbFontSize.setProgress(progressVal);
        int initZoom = Math.round(((progressVal + 8) / 13f) * 100f);
        tvZoomLabel.setText("Terminal Font Size / Zoom: " + (progressVal + 8) + "sp (" + initZoom + "%)");

        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.COLOR_PRESET_NAMES
        );
        spTextColor.setAdapter(colorAdapter);
        spPromptColor.setAdapter(colorAdapter);
        spTextColor.setSelection(findColorIndex(customManager.getTextColor(), 0));
        spPromptColor.setSelection(findColorIndex(customManager.getPromptColor(), 1));

        ArrayAdapter<String> bgAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, CustomizationManager.BG_THEME_NAMES
        );
        spBgTheme.setAdapter(bgAdapter);
        spBgTheme.setSelection(findBgIndex(customManager.getBgTintColor()));

        int dimVal = customManager.getBgDimPercent();
        sbDim.setProgress(dimVal);
        tvDimLabel.setText("Background Dim / Overlay: " + dimVal + "%");

        final boolean[] initialized = {false};
        spUiStyle.post(() -> initialized[0] = true);

        spUiStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                if (!initialized[0]) return;
                customManager.applyUiStylePreset(pos);
                spPromptStyle.setSelection(customManager.getPromptStyle());
                cbSessionTabs.setChecked(customManager.isShowSessionTabs());
                cbQuickChips.setChecked(customManager.isShowQuickChips());
                cbAppDock.setChecked(customManager.isShowAppDock());
                cbHudBorder.setChecked(customManager.isShowHudBorder());
                cbCrtScanlines.setChecked(customManager.isShowCrtScanlines());
                spTextColor.setSelection(findColorIndex(customManager.getTextColor(), 0));
                spPromptColor.setSelection(findColorIndex(customManager.getPromptColor(), 1));
                spBgTheme.setSelection(findBgIndex(customManager.getBgTintColor()));
                sbDim.setProgress(customManager.getBgDimPercent());
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spPromptStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                customManager.setPromptStyle(pos);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        cbSessionTabs.setOnCheckedChangeListener((b, isChecked) -> customManager.setShowSessionTabs(isChecked));
        cbQuickChips.setOnCheckedChangeListener((b, isChecked) -> customManager.setShowQuickChips(isChecked));
        cbAppDock.setOnCheckedChangeListener((b, isChecked) -> customManager.setShowAppDock(isChecked));
        cbHudBorder.setOnCheckedChangeListener((b, isChecked) -> customManager.setShowHudBorder(isChecked));
        cbCrtScanlines.setOnCheckedChangeListener((b, isChecked) -> customManager.setShowCrtScanlines(isChecked));

        spFont.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                customManager.setFontStyleIndex(pos);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        sbFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int sp = progress + 8;
                int zoomPct = Math.round((sp / 13f) * 100f);
                tvZoomLabel.setText("Terminal Font Size / Zoom: " + sp + "sp (" + zoomPct + "%)");
                customManager.setFontSizeSp(sp);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        spTextColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                customManager.setTextColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spPromptColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                customManager.setPromptColor(CustomizationManager.COLOR_PRESET_VALUES[pos]);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spBgTheme.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                customManager.setBgTintColor(CustomizationManager.BG_THEME_COLORS[pos]);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        sbDim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvDimLabel.setText("Background Dim / Overlay: " + progress + "%");
                customManager.setBgDimPercent(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnPickWp.setOnClickListener(v -> pickWallpaperLauncher.launch(new String[]{"image/*"}));
        btnClearWp.setOnClickListener(v -> {
            customManager.clearWallpaper();
            sbDim.setProgress(customManager.getBgDimPercent());
            Toast.makeText(this, "Wallpaper cleared.", Toast.LENGTH_SHORT).show();
        });

        populateAboutSection(scrollView, tvAboutHeader, getIntent().getBooleanExtra("scroll_to_about", false));
    }

    private void populateAboutSection(ScrollView scrollView, TextView tvAboutHeader, boolean scrollToAbout) {
        TextView tvVersion = findViewById(R.id.tv_about_version);
        TextView tvDetails = findViewById(R.id.tv_about_details);

        String versionName = "2.5";
        long versionCode = 10;
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (pi.versionName != null) versionName = pi.versionName;
            versionCode = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception ignored) {
        }

        if (tvVersion != null) {
            tvVersion.setText("Version " + versionName + " (Build " + versionCode + ")");
        }

        boolean termuxInstalled = false;
        try {
            getPackageManager().getPackageInfo("com.termux", 0);
            termuxInstalled = true;
        } catch (Exception ignored) {
            termuxInstalled = new File("/data/data/com.termux/files/usr").exists();
        }

        if (tvDetails != null) {
            String info =
                "Package: " + getPackageName() + "\n" +
                "Device / Android: " + Build.MANUFACTURER + " " + Build.MODEL + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "Termux Installed: " + (termuxInstalled ? "Yes (auto-connected when accessible)" : "Not detected") + "\n" +
                "Prefix Path: " + new File(getFilesDir(), "usr").getAbsolutePath() + "\n\n" +
                "TermLauncher is a terminal-first launcher with multi-window sessions, " +
                "package management, local audio playback, storage shortcuts, and customizable themes.";
            tvDetails.setText(info);
        }

        if (scrollToAbout && scrollView != null && tvAboutHeader != null) {
            scrollView.post(() -> scrollView.smoothScrollTo(0, tvAboutHeader.getTop()));
        }
    }

    private int findColorIndex(int color, int fallback) {
        for (int i = 0; i < CustomizationManager.COLOR_PRESET_VALUES.length; i++) {
            if (CustomizationManager.COLOR_PRESET_VALUES[i] == color) return i;
        }
        return fallback;
    }

    private int findBgIndex(int color) {
        for (int i = 0; i < CustomizationManager.BG_THEME_COLORS.length; i++) {
            if (CustomizationManager.BG_THEME_COLORS[i] == color) return i;
        }
        return 0;
    }
}
