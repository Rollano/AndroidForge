package com.novalabs.linuxdesktop;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Nova Linux Desktop - a lightweight Android home launcher with an explicit
 * root shell. Commands are executed only after the user taps Run.
 */
public class MainActivity extends Activity {

    private static final int BG = Color.rgb(8, 17, 29);
    private static final int PANEL = Color.rgb(15, 28, 44);
    private static final int PANEL_LIGHT = Color.rgb(20, 37, 55);
    private static final int MINT = Color.rgb(103, 232, 181);
    private static final int TEXT = Color.rgb(231, 240, 247);
    private static final int MUTED = Color.rgb(145, 164, 181);

    private final Handler handler = new Handler();
    private TextView timeView;
    private TextView dateView;
    private TextView rootBadge;
    private boolean rootGranted = false;
    private String currentDirectory = "/sdcard";
    private Dialog terminalDialog;
    private TextView terminalOutput;
    private TextView terminalRootStatus;
    private ScrollView terminalScroll;
    private EditText commandInput;

    private final Runnable clockRunnable = new Runnable() {
        @Override
        public void run() {
            if (timeView != null) {
                java.text.SimpleDateFormat timeFormat =
                    new java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault());
                java.text.SimpleDateFormat dateFormat =
                    new java.text.SimpleDateFormat("EEEE, MMMM d", java.util.Locale.getDefault());
                java.util.Date now = new java.util.Date();
                timeView.setText(timeFormat.format(now));
                dateView.setText(dateFormat.format(now));
            }
            handler.postDelayed(this, 30000L);
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 17, 29));
        getWindow().setNavigationBarColor(Color.rgb(8, 17, 29));
        getWindow().getDecorView().setSystemUiVisibility(0);
        currentDirectory = getSharedPreferences("nova_terminal", MODE_PRIVATE)
            .getString("cwd", "/sdcard");
        buildHomeScreen();
        handler.post(clockRunnable);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(clockRunnable);
        super.onDestroy();
    }

    private void buildHomeScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(10));
        root.setBackground(new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(8, 17, 29), Color.rgb(12, 27, 42), Color.rgb(7, 18, 31)}));

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(-1, dp(76)));

        ScrollView mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(false);
        mainScroll.setClipToPadding(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(10), 0, dp(16));

        content.addView(buildWelcomePanel(), new LinearLayout.LayoutParams(-1, dp(166)));

        TextView section = label("WORKSPACE", 11, MINT, true);
        section.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, -2);
        sectionLp.topMargin = dp(22);
        sectionLp.bottomMargin = dp(10);
        content.addView(section, sectionLp);

        LinearLayout rowOne = new LinearLayout(this);
        rowOne.setOrientation(LinearLayout.HORIZONTAL);
        rowOne.addView(makeTile("▣", "Applications", "Browse installed apps", new View.OnClickListener() {
            @Override public void onClick(View v) { showAppDrawer(); }
        }), weightedTileParams());
        rowOne.addView(makeTile(">_", "Root Terminal", "Run commands with su", new View.OnClickListener() {
            @Override public void onClick(View v) { openTerminal(""); }
        }), weightedTileParams());
        content.addView(rowOne);

        LinearLayout rowTwo = new LinearLayout(this);
        rowTwo.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowTwoLp = new LinearLayout.LayoutParams(-1, -2);
        rowTwoLp.topMargin = dp(10);
        rowTwo.addView(makeTile("⌂", "File Manager", "Open device storage", new View.OnClickListener() {
            @Override public void onClick(View v) { openFiles(); }
        }), weightedTileParams());
        rowTwo.addView(makeTile("⚙", "System Settings", "Android settings", new View.OnClickListener() {
            @Override public void onClick(View v) { openSettings(); }
        }), weightedTileParams());
        content.addView(rowTwo, rowTwoLp);

        TextView note = label("QUICK COMMANDS", 11, MINT, true);
        note.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(22);
        noteLp.bottomMargin = dp(10);
        content.addView(note, noteLp);
        content.addView(buildQuickCommandPanel());

        mainScroll.addView(content);
        root.addView(mainScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(buildDock(), new LinearLayout.LayoutParams(-1, dp(62)));
        setContentView(root);
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView name = label("NOVA  /  LINUX DESKTOP", 13, TEXT, true);
        name.setLetterSpacing(0.06f);
        TextView subtitle = label("ANDROID WORKSPACE", 9, MUTED, false);
        subtitle.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(5);
        brand.addView(name);
        brand.addView(subtitle, subtitleLp);
        bar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));

        rootBadge = label("ROOT: NOT CHECKED", 9, MINT, true);
        rootBadge.setGravity(Gravity.CENTER);
        rootBadge.setPadding(dp(10), dp(8), dp(10), dp(8));
        rootBadge.setBackground(rounded(Color.rgb(17, 52, 48), Color.rgb(37, 105, 86), 30));
        bar.addView(rootBadge);
        return bar;
    }

    private View buildWelcomePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(15), dp(18), dp(14));
        panel.setBackground(roundedGradient(new int[]{Color.rgb(21, 50, 62), Color.rgb(15, 34, 52)}, 20));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout clockBox = new LinearLayout(this);
        clockBox.setOrientation(LinearLayout.VERTICAL);
        timeView = label("--:--", 27, TEXT, true);
        timeView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        dateView = label("Loading date...", 11, MUTED, false);
        LinearLayout.LayoutParams dateLp = new LinearLayout.LayoutParams(-1, -2);
        dateLp.topMargin = dp(2);
        clockBox.addView(timeView);
        clockBox.addView(dateView, dateLp);
        top.addView(clockBox, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView linuxMark = label("LINUX\nMODE", 10, MINT, true);
        linuxMark.setGravity(Gravity.CENTER);
        linuxMark.setPadding(dp(12), dp(8), dp(12), dp(8));
        linuxMark.setBackground(rounded(Color.rgb(10, 31, 38), Color.rgb(39, 100, 88), 13));
        top.addView(linuxMark);
        panel.addView(top);

        TextView prompt = label("root@android  :  ~  #", 14, MINT, true);
        prompt.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        LinearLayout.LayoutParams promptLp = new LinearLayout.LayoutParams(-1, -2);
        promptLp.topMargin = dp(15);
        panel.addView(prompt, promptLp);

        TextView action = label("OPEN ROOT TERMINAL     →", 10, TEXT, true);
        action.setGravity(Gravity.CENTER_VERTICAL);
        action.setPadding(dp(12), 0, dp(12), 0);
        action.setBackground(rounded(Color.rgb(28, 68, 66), Color.rgb(43, 125, 99), 10));
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, dp(34));
        actionLp.topMargin = dp(8);
        panel.addView(action, actionLp);
        action.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openTerminal(""); }
        });
        panel.setElevation(dp(2));
        return panel;
    }

    private View makeTile(String glyph, String title, String description, View.OnClickListener listener) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(14), dp(14), dp(12), dp(13));
        tile.setMinimumHeight(dp(112));
        tile.setBackground(rounded(PANEL, Color.rgb(34, 55, 72), 16));
        tile.setElevation(dp(1));

        TextView icon = label(glyph, 23, MINT, true);
        TextView name = label(title, 13, TEXT, true);
        TextView detail = label(description, 10, MUTED, false);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-1, -2);
        nameLp.topMargin = dp(7);
        LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(-1, -2);
        detailLp.topMargin = dp(4);
        tile.addView(icon);
        tile.addView(name, nameLp);
        tile.addView(detail, detailLp);
        tile.setOnClickListener(listener);
        return tile;
    }

    private LinearLayout.LayoutParams weightedTileParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(0, 0, dp(6), 0);
        return lp;
    }

    private View buildQuickCommandPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        panel.setBackground(rounded(PANEL, Color.rgb(31, 51, 68), 15));
        addQuickCommand(panel, "id", "Check root identity");
        addQuickCommand(panel, "getprop ro.build.version.release", "Android version");
        addQuickCommand(panel, "df -h", "Storage overview");
        addQuickCommand(panel, "ls /sdcard", "List shared storage");
        return panel;
    }

    private void addQuickCommand(LinearLayout parent, final String command, String description) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(5), 0, dp(5));
        TextView cmd = label("$ " + command, 11, MINT, true);
        cmd.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        row.addView(cmd, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView run = label("RUN  ›", 9, TEXT, true);
        run.setPadding(dp(10), dp(7), dp(10), dp(7));
        run.setBackground(rounded(PANEL_LIGHT, Color.rgb(43, 69, 84), 9));
        row.addView(run);
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openTerminal(command); }
        });
        parent.addView(row);
        TextView desc = label(description, 9, MUTED, false);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(-1, -2);
        descLp.bottomMargin = dp(3);
        parent.addView(desc, descLp);
    }

    private View buildDock() {
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(5), dp(5), dp(5), dp(5));
        dock.setBackground(rounded(Color.rgb(14, 27, 42), Color.rgb(35, 54, 69), 18));
        dock.addView(dockItem("▦", "APPS", new View.OnClickListener() {
            @Override public void onClick(View v) { showAppDrawer(); }
        }), dockParams());
        dock.addView(dockItem(">_", "TERMINAL", new View.OnClickListener() {
            @Override public void onClick(View v) { openTerminal(""); }
        }), dockParams());
        dock.addView(dockItem("▤", "FILES", new View.OnClickListener() {
            @Override public void onClick(View v) { openFiles(); }
        }), dockParams());
        dock.addView(dockItem("⚙", "SETTINGS", new View.OnClickListener() {
            @Override public void onClick(View v) { openSettings(); }
        }), dockParams());
        return dock;
    }

    private LinearLayout.LayoutParams dockParams() {
        return new LinearLayout.LayoutParams(0, -1, 1f);
    }

    private View dockItem(String iconText, String title, View.OnClickListener click) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView icon = label(iconText, 18, MINT, true);
        TextView name = label(title, 8, MUTED, true);
        item.addView(icon);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-2, -2);
        nameLp.topMargin = dp(2);
        item.addView(name, nameLp);
        item.setOnClickListener(click);
        return item;
    }

    private void openTerminal(String presetCommand) {
        terminalDialog = new Dialog(this);
        terminalDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(16), dp(14), dp(16), dp(14));
        shell.setBackground(rounded(Color.rgb(7, 15, 25), Color.rgb(37, 67, 79), 18));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("ROOT TERMINAL", 14, TEXT, true);
        title.setLetterSpacing(0.08f);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        terminalRootStatus = label("CHECKING...", 9, MINT, true);
        header.addView(terminalRootStatus);
        shell.addView(header);

        TextView warning = label("Commands run as root through su. Only execute commands you understand.", 10, MUTED, false);
        LinearLayout.LayoutParams warningLp = new LinearLayout.LayoutParams(-1, -2);
        warningLp.topMargin = dp(7);
        warningLp.bottomMargin = dp(10);
        shell.addView(warning, warningLp);

        terminalScroll = new ScrollView(this);
        terminalScroll.setFillViewport(false);
        terminalScroll.setBackground(rounded(Color.rgb(3, 10, 18), Color.rgb(25, 43, 57), 10));
        terminalOutput = label("Nova shell ready.\nTap Run to execute a command with root privileges.\n", 11, MINT, false);
        terminalOutput.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        terminalOutput.setPadding(dp(11), dp(10), dp(11), dp(10));
        terminalOutput.setGravity(Gravity.TOP | Gravity.LEFT);
        terminalScroll.addView(terminalOutput);
        LinearLayout.LayoutParams outputLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        outputLp.bottomMargin = dp(10);
        shell.addView(terminalScroll, outputLp);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        addMiniCommand(quick, "id");
        addMiniCommand(quick, "df -h");
        addMiniCommand(quick, "getprop");
        LinearLayout.LayoutParams quickLp = new LinearLayout.LayoutParams(-1, -2);
        quickLp.bottomMargin = dp(8);
        shell.addView(quick, quickLp);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        commandInput = new EditText(this);
        commandInput.setSingleLine(true);
        commandInput.setTextColor(TEXT);
        commandInput.setHintTextColor(MUTED);
        commandInput.setHint("root@android: command");
        commandInput.setTextSize(12);
        commandInput.setTypeface(Typeface.MONOSPACE);
        commandInput.setPadding(dp(10), 0, dp(10), 0);
        commandInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        commandInput.setBackground(rounded(Color.rgb(17, 30, 43), Color.rgb(44, 68, 81), 10));
        if (presetCommand != null && presetCommand.length() > 0) {
            commandInput.setText(presetCommand);
            commandInput.setSelection(commandInput.getText().length());
        }
        inputRow.addView(commandInput, new LinearLayout.LayoutParams(0, dp(46), 1f));
        Button run = actionButton("RUN", true);
        LinearLayout.LayoutParams runLp = new LinearLayout.LayoutParams(dp(66), dp(46));
        runLp.leftMargin = dp(7);
        inputRow.addView(run, runLp);
        shell.addView(inputRow);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        Button history = actionButton("HISTORY", false);
        Button clear = actionButton("CLEAR", false);
        LinearLayout.LayoutParams controlLp = new LinearLayout.LayoutParams(dp(88), dp(38));
        controlLp.topMargin = dp(7);
        controls.addView(history, controlLp);
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(dp(75), dp(38));
        clearLp.leftMargin = dp(7);
        clearLp.topMargin = dp(7);
        controls.addView(clear, clearLp);
        shell.addView(controls);

        run.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { executeFromTerminal(); }
        });
        commandInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    executeFromTerminal();
                    return true;
                }
                return false;
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { terminalOutput.setText("Terminal cleared.\n"); }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showCommandHistory(); }
        });

        terminalDialog.setContentView(shell);
        Window window = terminalDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, (int)(getResources().getDisplayMetrics().heightPixels * 0.82f));
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        terminalDialog.show();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, (int)(getResources().getDisplayMetrics().heightPixels * 0.82f));
        }
        checkRootStatus();
    }

    private void addMiniCommand(LinearLayout parent, final String command) {
        TextView chip = label(command, 9, MINT, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(8), dp(7), dp(8), dp(7));
        chip.setBackground(rounded(Color.rgb(14, 34, 42), Color.rgb(34, 76, 70), 9));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(0, 0, dp(5), 0);
        parent.addView(chip, lp);
        chip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                commandInput.setText(command);
                commandInput.setSelection(commandInput.getText().length());
            }
        });
    }

    private void executeFromTerminal() {
        final String command = commandInput.getText().toString().trim();
        if (command.length() == 0) {
            Toast.makeText(this, "Enter a command first", Toast.LENGTH_SHORT).show();
            return;
        }
        saveCommandHistory(command);
        terminalOutput.append("\nroot@android:" + currentDirectory + " # " + command + "\n");
        terminalScroll.post(new Runnable() {
            @Override public void run() { terminalScroll.fullScroll(View.FOCUS_DOWN); }
        });
        terminalRootStatus.setText("RUNNING...");
        final TextView output = terminalOutput;
        final ScrollView scroller = terminalScroll;
        final TextView status = terminalRootStatus;
        new Thread(new Runnable() {
            @Override public void run() {
                final String result = executeRootCommand(command);
                final boolean hasRoot = result.contains("uid=0(") || result.contains("uid=0 ");
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        appendTerminalOutput(output, scroller, result + "\n");
                        if (result.contains("Root execution error:") || result.contains("not allowed")) {
                            rootGranted = false;
                        } else if (hasRoot) {
                            rootGranted = true;
                        }
                        updateRootBadge(rootGranted);
                        status.setText(rootGranted ? "ROOT GRANTED" : "ROOT DENIED / ERROR");
                    }
                });
            }
        }, "NovaRootCommand").start();
    }

    private void checkRootStatus() {
        terminalRootStatus.setText("REQUESTING ROOT...");
        new Thread(new Runnable() {
            @Override public void run() {
                final String result = executeRootCommand("id");
                final boolean granted = result.contains("uid=0(") || result.contains("uid=0 ");
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        rootGranted = granted;
                        updateRootBadge(granted);
                        if (terminalRootStatus != null) {
                            terminalRootStatus.setText(granted ? "ROOT GRANTED" : "ROOT NOT GRANTED");
                        }
                        if (!granted && terminalOutput != null) {
                            appendTerminalOutput(terminalOutput, terminalScroll,
                                "Root access was not granted. Approve the request in Magisk/SuperSU, then tap Run.\n");
                        }
                    }
                });
            }
        }, "NovaRootCheck").start();
    }

    /** Executes one user-entered shell line with su -c. */
    private String executeRootCommand(String command) {
        StringBuilder output = new StringBuilder();
        Process process = null;
        try {
            String shellLine = "cd " + shellQuote(currentDirectory)
                + " 2>/dev/null || cd /sdcard 2>/dev/null || cd /; "
                + "export PATH=/system/bin:/system/xbin:/vendor/bin:/product/bin:$PATH; "
                + command
                + "; __nova_pwd=$(pwd); printf \"\\n__NOVA_PWD__:%s\\n\" \"$__nova_pwd\"";
            process = new ProcessBuilder("su", "-c", shellLine)
                .redirectErrorStream(true)
                .start();
            process.getOutputStream().close();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("__NOVA_PWD__:")) {
                    String dir = line.substring("__NOVA_PWD__:".length()).trim();
                    if (dir.startsWith("/")) {
                        currentDirectory = dir;
                        getSharedPreferences("nova_terminal", MODE_PRIVATE).edit()
                            .putString("cwd", dir).apply();
                    }
                    continue;
                }
                output.append(line).append('\n');
                if (output.length() > 18000) {
                    output.delete(0, output.length() - 16000);
                    output.insert(0, "[Earlier output trimmed]\n");
                }
            }
            reader.close();
            int exitCode = process.waitFor();
            output.append("[exit code: ").append(exitCode).append("]");
        } catch (Exception e) {
            output.append("Root execution error: ").append(e.getClass().getSimpleName())
                .append(": ").append(e.getMessage() == null ? "unknown error" : e.getMessage());
        } finally {
            if (process != null) {
                try { process.destroy(); } catch (Exception ignored) { }
            }
        }
        return output.toString();
    }

    private void appendTerminalOutput(final TextView output, final ScrollView scroller, final String text) {
        if (output == null) return;
        output.append(text);
        if (output.length() > 22000) {
            output.setText(output.getText().toString().substring(output.length() - 18000));
        }
        if (scroller != null) {
            scroller.post(new Runnable() {
                @Override public void run() { scroller.fullScroll(View.FOCUS_DOWN); }
            });
        }
    }

    private void updateRootBadge(boolean granted) {
        if (rootBadge != null) {
            rootBadge.setText(granted ? "ROOT: ONLINE" : "ROOT: NOT GRANTED");
            rootBadge.setTextColor(granted ? MINT : Color.rgb(255, 184, 112));
            rootBadge.setBackground(rounded(granted ? Color.rgb(17, 52, 48) : Color.rgb(59, 39, 28),
                granted ? Color.rgb(37, 105, 86) : Color.rgb(117, 77, 45), 30));
        }
    }

    private String shellQuote(String value) {
        return "\'" + value.replace("\'", "\'\\\'\'") + "\'";
    }

    private void saveCommandHistory(String command) {
        SharedPreferences prefs = getSharedPreferences("nova_terminal", MODE_PRIVATE);
        String saved = prefs.getString("history", "");
        String[] lines = saved.split("\\n");
        StringBuilder next = new StringBuilder(command);
        int count = 1;
        for (int i = 0; i < lines.length && count < 20; i++) {
            String item = lines[i].trim();
            if (item.length() > 0 && !item.equals(command)) {
                next.append('\n').append(item);
                count++;
            }
        }
        prefs.edit().putString("history", next.toString()).apply();
    }

    private void showCommandHistory() {
        SharedPreferences prefs = getSharedPreferences("nova_terminal", MODE_PRIVATE);
        String saved = prefs.getString("history", "");
        final String[] items = saved.length() == 0 ? new String[0] : saved.split("\\n");
        if (items.length == 0) {
            Toast.makeText(this, "No saved commands yet", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("Command history")
            .setItems(items, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface dialog, int which) {
                    commandInput.setText(items[which]);
                    commandInput.setSelection(commandInput.getText().length());
                }
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private void showAppDrawer() {
        final PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        final List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(14), dp(18), dp(10));
        panel.setBackgroundColor(Color.rgb(12, 23, 36));
        TextView heading = label("APPLICATIONS", 14, TEXT, true);
        panel.addView(heading);
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search apps...");
        search.setTextColor(TEXT);
        search.setHintTextColor(MUTED);
        search.setBackground(rounded(PANEL_LIGHT, Color.rgb(43, 67, 82), 10));
        search.setPadding(dp(10), 0, dp(10), 0);
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(44));
        searchLp.topMargin = dp(10);
        panel.addView(search, searchLp);

        final ArrayList<ResolveInfo> filtered = new ArrayList<ResolveInfo>(apps);
        final ArrayList<String> labels = new ArrayList<String>();
        for (ResolveInfo info : filtered) labels.add(info.loadLabel(pm).toString());
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView item = (TextView) super.getView(position, convertView, parent);
                item.setTextColor(TEXT);
                item.setTextSize(14);
                item.setPadding(dp(12), dp(12), dp(12), dp(12));
                item.setBackgroundColor(Color.rgb(12, 23, 36));
                return item;
            }
        };
        ListView list = new ListView(this);
        list.setDividerHeight(dp(1));
        list.setAdapter(adapter);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        listLp.topMargin = dp(8);
        panel.addView(list, listLp);

        final AlertDialog drawer = new AlertDialog.Builder(this).create();
        drawer.setView(panel);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < filtered.size()) {
                    ResolveInfo info = filtered.get(position);
                    Intent launch = new Intent(Intent.ACTION_MAIN);
                    launch.addCategory(Intent.CATEGORY_LAUNCHER);
                    launch.setClassName(info.activityInfo.packageName, info.activityInfo.name);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { startActivity(launch); } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Unable to open app", Toast.LENGTH_SHORT).show();
                    }
                    drawer.dismiss();
                }
            }
        });
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String term = s.toString().toLowerCase(java.util.Locale.getDefault());
                filtered.clear();
                labels.clear();
                for (ResolveInfo info : apps) {
                    String name = info.loadLabel(pm).toString();
                    if (name.toLowerCase(java.util.Locale.getDefault()).contains(term)) {
                        filtered.add(info);
                        labels.add(name);
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });
        drawer.show();
        drawer.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,
            (int)(getResources().getDisplayMetrics().heightPixels * 0.82f));
    }

    private void openFiles() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_VIEW);
                fallback.setData(Uri.parse("content://com.android.externalstorage.documents/root/primary"));
                startActivity(fallback);
            } catch (Exception ignored) {
                Toast.makeText(this, "No file picker is installed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open Settings", Toast.LENGTH_SHORT).show();
        }
    }

    private Button actionButton(String text, boolean primary) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(10);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(primary ? Color.rgb(5, 22, 24) : TEXT);
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setBackground(rounded(primary ? MINT : PANEL_LIGHT,
            primary ? MINT : Color.rgb(49, 72, 88), 10));
        return button;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    private GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill);
        shape.setCornerRadius(dp(radiusDp));
        shape.setStroke(dp(1), stroke);
        return shape;
    }

    private GradientDrawable roundedGradient(int[] colors, int radiusDp) {
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        shape.setCornerRadius(dp(radiusDp));
        shape.setStroke(dp(1), Color.rgb(42, 82, 83));
        return shape;
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
