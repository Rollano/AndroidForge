# Nova Linux Desktop (Gradle build edition)

Converted from the classic AIDE project into a standard Android Gradle project.

## Build
- Android Gradle Plugin: 8.6.1
- Gradle compatible version: 8.7
- Compile SDK: 35
- Min SDK: 23 (Android 6.0)
- Target SDK: 28 (legacy target chosen to retain app visibility behavior and avoid additional runtime changes)
- Java: 8 language compatibility

Build using a host with JDK 17, Android SDK Platform 35 and Gradle 8.7:

```bash
gradle assembleDebug
```

APK output when successfully built: `app/build/outputs/apk/debug/app-debug.apk`

If AndroidForge uses a different installed AGP/Gradle/JDK combination, adjust versions in root `build.gradle` and the Gradle distribution accordingly.

## Root terminal
The launcher requests root command execution via `su`. Root must already be available (e.g. Magisk). Commands are user-entered; root commands can damage or alter the device. No root is bundled or installed by this app.

## Notes
This project was converted to Gradle, but it has not been compiled in this environment because Android SDK/JDK build tools are not installed here. The build result must be confirmed by AndroidForge or another Android build environment.
