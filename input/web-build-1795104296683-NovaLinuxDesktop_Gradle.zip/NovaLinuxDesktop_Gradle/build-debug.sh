#!/usr/bin/env sh
set -eu
gradle assembleDebug
