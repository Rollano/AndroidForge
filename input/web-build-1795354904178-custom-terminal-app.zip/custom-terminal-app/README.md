# termux-vision (v24 — Clean Compilation + Root `su` Shell & ADB Commands)

- Fixes duplicate `onDestroy()`, `page` scope in `onCreate`, and uses `w.workingDir` in `formatShellPrompt`.
- Adds persistent `su` root shell state (`root@kali` with `└─#` prompt and `exit` to return) plus root ADB command execution (`adb shell ...`, `adb install ...`, `adb uninstall ...`, `adb pull ...`, `adb push ...`, `adb tcpip ...`, `adb root`, `adb reboot`).
