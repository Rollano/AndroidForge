package com.example.customterminal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TermuxLogReceiver extends BroadcastReceiver {
    public static final String ACTION = "com.example.customterminal.TERMUX_LOG";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION.equals(intent.getAction())) return;
        String token = intent.getStringExtra("session_token");
        String line = intent.getStringExtra("line");
        if (token != null && !token.isEmpty() && line != null) {
            MainActivity.receiveTermuxLog(token, line);
        }
    }
}
