# termux-vision (v30 — Tap-Anywhere Keyboard Trigger in dispatchTouchEvent)

- Detects clean single-finger taps (`ACTION_UP` without scroll/drag/pinch) in `dispatchTouchEvent` and requests focus + opens the soft keyboard (`InputMethodManager.showSoftInput`) on the terminal `input` `EditText` even when tapping over selectable `output` text or scrollable area.
