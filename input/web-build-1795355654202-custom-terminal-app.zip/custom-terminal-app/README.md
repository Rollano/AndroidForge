# termux-vision (v26 — Fix Typing / Keyboard Focus on Terminal Input)

- Explicitly enables `focusable`, `focusableInTouchMode`, `clickable`, `enabled`, and `cursorVisible` on the terminal `EditText` (`input`) and adds a visible `"Type command here..."` hint.
- Strengthens `focusTerminalInput()` and calls it on `onResume()` and on `input` click so tapping the prompt/terminal reliably focuses the input box and shows the soft keyboard.
