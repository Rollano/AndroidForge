# termux-vision (AndroidForge-ready)

Termux-style terminal UI that sends commands to Termux using its documented `RUN_COMMAND` service.
Commands run as the Termux app user (not root). Requires Termux installed, external command access enabled in Termux, and the Android permission `com.termux.permission.RUN_COMMAND` granted to this app.


## Build with AndroidForge / GitHub Actions

1. Upload this project to a GitHub repository.
2. Open **Actions** and run **AndroidForge Build** (or push to `main`/`master`).
3. Download the `termux-vision-debug-apk` artifact.

## Local Gradle build

```sh
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Notes

- Android SDK platform 35 and Build Tools 35.0.0.
- Java 17 for Gradle; Java 8 source compatibility for app.
- Minimum Android 6.0 (API 23).
- Target API 28 is intentional for compatibility with Termux external command integration.
- No root or Shizuku support is implemented; commands run under Termux's own user context.
