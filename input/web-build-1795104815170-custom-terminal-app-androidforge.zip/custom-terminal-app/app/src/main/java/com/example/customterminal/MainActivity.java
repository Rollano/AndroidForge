package com.example.customterminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.ResolveInfo;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 101;
    private static final String TERMUX_PACKAGE = "com.termux";
    private static final String RUN_PERMISSION = "com.termux.permission.RUN_COMMAND";
    private static final AtomicInteger executionIds = new AtomicInteger(1000);
    private static volatile MainActivity activeActivity;
    private static final String[] PALETTE_NAMES = {"Matrix", "Neon", "Mint", "Ice", "Pure Black + Green"};
    private static final String[] FONT_NAMES = {"Monospace", "Sans Serif", "Serif", "Casual"};
    private final int[][] palettes = {
        {0xFF07111D, 0xFF73FBD3, 0xFFFFFFFF, 0xFF112A3A},
        {0xFF171020, 0xFFFF78C8, 0xFFFFF3FA, 0xFF38203A},
        {0xFF111510, 0xFFA6F28A, 0xFFF0F7EA, 0xFF263421},
        {0xFF101318, 0xFF8DC7FF, 0xFFF1F5FA, 0xFF252C35},
        {0xFF000000, 0xFF39FF14, 0xFF39FF14, 0xFF101F10}
    };
    private final ArrayList<String> commandHistory = new ArrayList<>();
    private final ArrayList<CustomCommand> customCommands = new ArrayList<>();
    private int palette = 0;
    private int fontFamily = 0;
    private int fontSize = 14;
    private int overlayPercent = 82;
    private SharedPreferences preferences;
    private FrameLayout root;
    private TextView subtitle;
    private View shade;
    private ImageView wallpaper;
    private TextView output;
    private EditText input;
    private ScrollView scroll;
    private LinearLayout customChips;
    private LinearLayout drawerPanel;
    private List<AppEntry> launchableApps;
    private LinearLayout appRows;
    private EditText appSearch;
    private View drawerScrim;
    private boolean drawerOpen = false;
    private int drawerWidth;
    private Button runButton;
    private String activeSessionToken;
    private boolean activeSessionReceivedLines;
    private boolean commandRunning;
    private final Handler commandHandler = new Handler(Looper.getMainLooper());
    private final Runnable commandTimeout = () -> {
        if (!commandRunning) return;
        append("[No response from Termux. The command may still be running; reconnect or restart the app to continue.]\n");
        activeSessionToken = null;
        commandRunning = false;
        runButton.setEnabled(true);
    };

    private static class CustomCommand {
        final String name;
        final String command;
        CustomCommand(String name, String command) { this.name = name; this.command = command; }
    }
    private File currentDir;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("custom-terminal", MODE_PRIVATE);
        palette = preferences.getInt("palette", 0);
        fontFamily = preferences.getInt("font_family", 0);
        fontSize = preferences.getInt("font_size", 14);
        overlayPercent = preferences.getInt("overlay", 82);
        loadCustomCommands();
        currentDir = new File(preferences.getString("working_directory", "/data/data/com.termux/files/home"));
        loadCommandHistory();
        buildUi();
        String savedWallpaper = preferences.getString("wallpaper", null);
        if (savedWallpaper != null) {
            try { wallpaper.setImageURI(Uri.parse(savedWallpaper)); }
            catch (Exception ignored) { }
        }
        append("termux-vision · Termux bridge\nType help for commands and settings.\n\n");
        playIntroPreview();
    }

    private void playIntroPreview() {
        final String preview = "[animated preview only]\n$ echo \"Termux ready\"\nTermux ready\n\n";
        final int[] position = {0};
        final Runnable[] ticker = new Runnable[1];
        ticker[0] = () -> {
            if (position[0] >= preview.length()) return;
            output.append(preview.substring(position[0], position[0] + 1));
            position[0]++;
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
            commandHandler.postDelayed(ticker[0], 28L);
        };
        commandHandler.postDelayed(ticker[0], 350L);
    }

    @Override protected void onResume() { super.onResume(); activeActivity = this; }
    @Override protected void onPause() { if (activeActivity == this) activeActivity = null; super.onPause(); }

    static void receiveTermuxLog(String token, String line) {
        MainActivity a = activeActivity;
        if (a != null && token.equals(a.activeSessionToken)) a.runOnUiThread(() -> {
            if (token.equals(a.activeSessionToken)) {
                a.activeSessionReceivedLines = true;
                a.append(line + "\n");
            }
        });
    }

    static void receiveTermuxResult(String token, String text, int exitCode) {
        MainActivity a = activeActivity;
        if (a != null) a.runOnUiThread(() -> {
            if (token == null || !token.equals(a.activeSessionToken)) return;
            if (!a.activeSessionReceivedLines && text != null && !text.isEmpty()) a.append(text);
            a.append("[Termux exit " + exitCode + "]\n");
            a.activeSessionToken = null;
            a.commandRunning = false;
            a.runButton.setEnabled(true);
        });
    }

    private void buildUi() {
        root = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));
        shade = new View(this);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(10), dp(10), dp(10), dp(6));
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        Button menuBtn = smallButton("☰");
        menuBtn.setContentDescription("Open app drawer");
        menuBtn.setOnClickListener(v -> openDrawer());
        top.addView(menuBtn);
        TextView title = new TextView(this);
        title.setText("TERMUX VISION");
        title.setTextSize(14);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -2, 1);
        titleParams.leftMargin = dp(4);
        top.addView(title, titleParams);
        Button wallpaperBtn = smallButton("WALL");
        wallpaperBtn.setOnClickListener(v -> chooseWallpaper());
        top.addView(wallpaperBtn);
        Button styleBtn = smallButton("STYLE");
        styleBtn.setOnClickListener(v -> showStyleMenu());
        top.addView(styleBtn);
        page.addView(top);

        subtitle = new TextView(this);
        updateDirectoryLabel();
        subtitle.setTextSize(11);
        subtitle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        subtitle.setPadding(dp(4), dp(3), 0, dp(1));
        subtitle.setOnClickListener(v -> connectTermux());
        page.addView(subtitle);

        HorizontalScrollView shortcuts = new HorizontalScrollView(this);
        shortcuts.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER_VERTICAL);
        Button addCustom = smallButton("+ CUSTOM");
        addCustom.setOnClickListener(v -> showAddCustomDialog());
        chips.addView(addCustom);
        String[] quick = {"pwd", "ls", "fastfetch", "pkg list-installed"};
        for (String command : quick) {
            Button chip = smallButton(command);
            chip.setOnClickListener(v -> { input.setText(command); runCommand(); });
            chips.addView(chip);
        }
        Button processes = smallButton("PROCESSES");
        processes.setOnClickListener(v -> listTermuxProcesses());
        chips.addView(processes);
        Button stopProcess = smallButton("STOP PID");
        stopProcess.setOnClickListener(v -> showStopProcessDialog());
        chips.addView(stopProcess);
        Button stopAll = smallButton("STOP ALL");
        stopAll.setOnClickListener(v -> showStopAllProcessesDialog());
        chips.addView(stopAll);
        Button installPackage = smallButton("PKG INSTALL");
        installPackage.setOnClickListener(v -> showPackageInstallerDialog());
        chips.addView(installPackage);
        Button history = smallButton("HISTORY");
        history.setOnClickListener(v -> showHistory());
        chips.addView(history);
        customChips = new LinearLayout(this);
        customChips.setGravity(Gravity.CENTER_VERTICAL);
        chips.addView(customChips);
        shortcuts.addView(chips);
        page.addView(shortcuts);
        renderCustomCommands();

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        output = new TextView(this);
        output.setTextSize(fontSize);
        output.setTypeface(selectedTypeface());
        output.setTextIsSelectable(true);
        output.setHorizontallyScrolling(false);
        output.setLineSpacing(0, 1f);
        output.setPadding(dp(5), dp(4), dp(5), dp(4));
        scroll.addView(output, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1);
        scrollParams.topMargin = dp(3);
        page.addView(scroll, scrollParams);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(fontSize);
        input.setTypeface(selectedTypeface());
        input.setHint("Type a Termux command…");
        input.setImeOptions(EditorInfo.IME_ACTION_GO);
        input.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_GO) { runCommand(); return true; }
            return false;
        });
        row.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        runButton = smallButton("RUN  ›");
        runButton.setOnClickListener(v -> runCommand());
        row.addView(runButton);
        page.addView(row);
        buildDrawer();
        setContentView(root);
        applyStyle();
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setMinHeight(dp(34));
        b.setMinimumHeight(dp(34));
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    private Typeface selectedTypeface() {
        switch (fontFamily) {
            case 1: return Typeface.create("sans-serif", Typeface.NORMAL);
            case 2: return Typeface.create("serif", Typeface.NORMAL);
            case 3: return Typeface.create("casual", Typeface.NORMAL);
            default: return Typeface.MONOSPACE;
        }
    }

    private void applyStyle() {
        int[] c = palettes[Math.max(0, Math.min(palette, palettes.length - 1))];
        int alpha = palette == 4 ? 0xFF : Math.max(0x40, Math.min(0xF2, overlayPercent * 255 / 100));
        shade.setBackgroundColor((alpha << 24) | (c[0] & 0x00FFFFFF));
        output.setTextColor(c[2]);
        input.setTextColor(c[2]);
        input.setHintTextColor(c[1]);
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c[1]));
        output.setTextSize(fontSize);
        input.setTextSize(fontSize);
        output.setTypeface(selectedTypeface());
        input.setTypeface(selectedTypeface());
        tintViews(root, c[1], c[3]);
        getWindow().setStatusBarColor(c[0]);
        getWindow().setNavigationBarColor(0xFF05080D);
        if (drawerPanel != null) {
            drawerPanel.setBackgroundColor(c[0]);
            appSearch.setTextColor(c[2]);
            appSearch.setHintTextColor(c[1]);
            appSearch.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c[1]));
            tintViews(drawerPanel, c[1], c[3]);
        }
    }

    private void tintViews(View view, int accent, int buttonBg) {
        if (view instanceof Button) {
            Button b = (Button) view;
            b.setTextColor(accent);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(buttonBg));
        } else if (view instanceof TextView && view != input && view != output) {
            ((TextView) view).setTextColor(accent);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) tintViews(group.getChildAt(i), accent, buttonBg);
        }
    }

    private void saveStyle() {
        preferences.edit().putInt("palette", palette).putInt("font_family", fontFamily)
            .putInt("font_size", fontSize).putInt("overlay", overlayPercent).apply();
        applyStyle();
    }

    private void showStyleMenu() {
        String[] items = {"Font style: " + FONT_NAMES[fontFamily], "Font size: " + fontSize + " sp",
            "Color palette: " + PALETTE_NAMES[palette], "Wallpaper dim: " + overlayPercent + "%"};
        new AlertDialog.Builder(this).setTitle("Terminal appearance").setItems(items, (d, which) -> {
            if (which == 0) chooseFont();
            else if (which == 1) chooseFontSize();
            else if (which == 2) choosePalette();
            else chooseOverlay();
        }).setNegativeButton("Close", null).show();
    }

    private void chooseFont() {
        new AlertDialog.Builder(this).setTitle("Font style").setSingleChoiceItems(FONT_NAMES, fontFamily, (d, which) -> {
            fontFamily = which; saveStyle(); d.dismiss();
        }).setNegativeButton("Cancel", null).show();
    }

    private void choosePalette() {
        new AlertDialog.Builder(this).setTitle("Color palette").setSingleChoiceItems(PALETTE_NAMES, palette, (d, which) -> {
            palette = which; saveStyle(); d.dismiss();
        }).setNegativeButton("Cancel", null).show();
    }

    private void chooseFontSize() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(4));
        TextView label = new TextView(this);
        label.setText("Font size: " + fontSize + " sp");
        label.setTextSize(16);
        box.addView(label);
        SeekBar seek = new SeekBar(this);
        seek.setMax(22);
        seek.setProgress(fontSize - 10);
        box.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) { label.setText("Font size: " + (p + 10) + " sp"); }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        new AlertDialog.Builder(this).setTitle("Font size").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Apply", (d, w) -> { fontSize = seek.getProgress() + 10; saveStyle(); }).show();
    }

    private void chooseOverlay() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(4));
        TextView label = new TextView(this);
        label.setText("Wallpaper dim: " + overlayPercent + "%");
        label.setTextSize(16);
        box.addView(label);
        SeekBar seek = new SeekBar(this);
        seek.setMax(70);
        seek.setProgress(overlayPercent - 25);
        box.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) { label.setText("Wallpaper dim: " + (p + 25) + "%"); }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        new AlertDialog.Builder(this).setTitle("Wallpaper dim").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Apply", (d, w) -> { overlayPercent = seek.getProgress() + 25; saveStyle(); }).show();
    }

    private void chooseWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_WALLPAPER);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_WALLPAPER && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION);
                wallpaper.setImageURI(uri);
                preferences.edit().putString("wallpaper", uri.toString()).apply();
            } catch (Exception e) { append("Wallpaper error: " + e.getMessage() + "\n"); }
        }
    }

    private void showHistory() {
        if (commandHistory.isEmpty()) { Toast.makeText(this, "No commands in this session yet.", Toast.LENGTH_SHORT).show(); return; }
        String[] items = commandHistory.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Recent commands").setItems(items, (d, which) -> input.setText(items[which]))
            .setNegativeButton("Close", null).show();
    }

    private void loadCommandHistory() {
        try {
            JSONArray saved = new JSONArray(preferences.getString("command_history", "[]"));
            int first = Math.max(0, saved.length() - 100);
            for (int i = first; i < saved.length(); i++) {
                String command = saved.optString(i, "");
                if (!command.isEmpty()) commandHistory.add(command);
            }
        } catch (Exception ignored) {
            commandHistory.clear();
        }
    }

    private void saveCommandHistory() {
        JSONArray saved = new JSONArray();
        int first = Math.max(0, commandHistory.size() - 100);
        for (int i = first; i < commandHistory.size(); i++) saved.put(commandHistory.get(i));
        preferences.edit().putString("command_history", saved.toString()).apply();
    }

    private void rememberCommand(String command) {
        commandHistory.add(command);
        while (commandHistory.size() > 100) commandHistory.remove(0);
        saveCommandHistory();
    }

    private void updateDirectoryLabel() {
        if (subtitle != null) subtitle.setText("●  TERMUX SHELL  ·  " + currentDir.getAbsolutePath());
    }

    private static class AppEntry {
        final String label;
        final String packageName;
        final Drawable icon;
        AppEntry(String label, String packageName, Drawable icon) {
            this.label = label; this.packageName = packageName; this.icon = icon;
        }
    }

    private void buildDrawer() {
        drawerWidth = dp(300);
        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(0x99000000);
        drawerScrim.setAlpha(0f);
        drawerScrim.setVisibility(View.GONE);
        drawerScrim.setOnClickListener(v -> closeDrawer());
        root.addView(drawerScrim, new FrameLayout.LayoutParams(-1, -1));

        drawerPanel = new LinearLayout(this);
        drawerPanel.setOrientation(LinearLayout.VERTICAL);
        drawerPanel.setPadding(dp(14), dp(12), dp(10), dp(10));
        drawerPanel.setElevation(dp(12));
        drawerPanel.setTranslationX(-drawerWidth);
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(drawerWidth, -1, Gravity.LEFT);
        root.addView(drawerPanel, drawerParams);

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView headingText = new TextView(this);
        headingText.setText("NATIVE APPS");
        headingText.setTextSize(16);
        headingText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        heading.addView(headingText, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = smallButton("×");
        close.setContentDescription("Close app drawer");
        close.setOnClickListener(v -> closeDrawer());
        heading.addView(close);
        drawerPanel.addView(heading);

        appSearch = new EditText(this);
        appSearch.setSingleLine(true);
        appSearch.setTextSize(14);
        appSearch.setHint("Search apps");
        drawerPanel.addView(appSearch);
        ScrollView appScroll = new ScrollView(this);
        launchableApps = getLaunchableApps();
        appRows = new LinearLayout(this);
        appRows.setOrientation(LinearLayout.VERTICAL);
        appScroll.addView(appRows, new ScrollView.LayoutParams(-1, -2));
        drawerPanel.addView(appScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        appSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) { renderAppRows(s.toString()); }
            public void afterTextChanged(Editable e) { }
        });
        Button termux = smallButton("TERMUX CONNECTION");
        termux.setOnClickListener(v -> { closeDrawer(); connectTermux(); });
        drawerPanel.addView(termux);
        renderAppRows("");
    }

    private void listTermuxProcesses() {
        input.setText("ps -u \"$(id -u)\" -o pid=,comm= | sort -n");
        runCommand();
    }

    private void showStopProcessDialog() {
        EditText pidInput = new EditText(this);
        pidInput.setSingleLine(true);
        pidInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        pidInput.setHint("PID from the process list");
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(22), dp(6), dp(22), 0);
        box.addView(pidInput, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("Stop Termux process")
            .setMessage("First use TERMUX RUNNING PROCESSES. Only processes owned by Termux can be stopped.")
            .setView(box).setNegativeButton("Cancel", null)
            .setPositiveButton("Stop", (dialog, which) -> {
                String pid = pidInput.getText().toString().trim();
                if (!pid.matches("[0-9]{1,10}") || "1".equals(pid)) {
                    Toast.makeText(this, "Enter a valid process ID.", Toast.LENGTH_SHORT).show();
                    return;
                }
                input.setText("pid=" + pid + "; owner=$(ps -o uid= -p \"$pid\" 2>/dev/null | tr -d ' '); "
                    + "if [ -z \"$owner\" ]; then echo 'Process not found.'; "
                    + "elif [ \"$owner\" != \"$(id -u)\" ]; then echo 'Refusing: process is not owned by Termux.'; "
                    + "else kill -TERM \"$pid\" && echo \"Sent TERM to PID $pid.\"; fi");
                runCommand();
            }).show();
    }

    private void showStopAllProcessesDialog() {
        new AlertDialog.Builder(this).setTitle("Stop running Termux processes?")
            .setMessage("This sends TERM to running Termux commands. Package managers, shells, and Termux services are protected.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Stop processes", (dialog, which) -> {
                input.setText("uid=$(id -u); ps -u $uid -o pid=,comm= | while read pid comm; do "
                    + "case $comm in bash|sh|apt*|dpkg*|pkg*|termux*|app_process|am|ps|sort|awk) ;; "
                    + "*) kill -TERM $pid 2>/dev/null && echo Stopped $comm PID $pid ;; esac; done");
                runCommand();
            }).show();
    }

    private void showPackageInstallerDialog() {
        EditText packageInput = new EditText(this);
        packageInput.setSingleLine(true);
        packageInput.setHint("Package name, e.g. nano");
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(22), dp(6), dp(22), 0);
        box.addView(packageInput, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("Install Termux package")
            .setMessage("Installs from Termux repositories using pkg. Wait for any other package operation to finish first.")
            .setView(box).setNegativeButton("Cancel", null)
            .setPositiveButton("Install", (dialog, which) -> {
                String name = packageInput.getText().toString().trim();
                if (!name.matches("[A-Za-z0-9][A-Za-z0-9+._-]*")) {
                    Toast.makeText(this, "Enter a valid package name.", Toast.LENGTH_SHORT).show();
                    return;
                }
                input.setText("pkg install -y -- " + name);
                runCommand();
            }).show();
    }

    private List<AppEntry> getLaunchableApps() {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(query, 0);
        LinkedHashMap<String, AppEntry> unique = new LinkedHashMap<>();
        for (ResolveInfo info : found) {
            String pkg = info.activityInfo.packageName;
            if (!unique.containsKey(pkg)) {
                String label = info.loadLabel(getPackageManager()).toString();
                unique.put(pkg, new AppEntry(label, pkg, info.loadIcon(getPackageManager())));
            }
        }
        ArrayList<AppEntry> apps = new ArrayList<>(unique.values());
        Collections.sort(apps, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return apps;
    }

    private void renderAppRows(String filter) {
        if (appRows == null) return;
        appRows.removeAllViews();
        String needle = filter.trim().toLowerCase();
        for (AppEntry app : launchableApps) {
            if (!app.label.toLowerCase().contains(needle)) continue;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(5), dp(8), dp(5));
            ImageView icon = new ImageView(this);
            icon.setImageDrawable(app.icon);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(38), dp(38));
            iconParams.rightMargin = dp(12);
            row.addView(icon, iconParams);
            TextView label = new TextView(this);
            label.setText(app.label);
            label.setTextSize(15);
            label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            row.setOnClickListener(v -> {
                closeDrawer();
                Intent launch = getPackageManager().getLaunchIntentForPackage(app.packageName);
                if (launch != null) startActivity(launch);
                else Toast.makeText(this, "App cannot be opened.", Toast.LENGTH_SHORT).show();
            });
            appRows.addView(row);
        }
        int[] c = palettes[Math.max(0, Math.min(palette, palettes.length - 1))];
        for (int i = 0; i < appRows.getChildCount(); i++) tintViews(appRows.getChildAt(i), c[2], c[3]);
    }

    private void openDrawer() {
        drawerOpen = true;
        drawerScrim.setVisibility(View.VISIBLE);
        drawerScrim.animate().alpha(1f).setDuration(180).start();
        drawerPanel.animate().translationX(0).setDuration(220).start();
        appSearch.setText("");
    }

    private void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        drawerPanel.animate().translationX(-drawerWidth).setDuration(200).start();
        drawerScrim.animate().alpha(0f).setDuration(180).withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
    }

    @Override public void onBackPressed() {
        if (drawerOpen) closeDrawer();
        else super.onBackPressed();
    }

    private void loadCustomCommands() {
        try {
            JSONArray data = new JSONArray(preferences.getString("custom_commands", "[]"));
            for (int i = 0; i < data.length(); i++) {
                JSONObject item = data.getJSONObject(i);
                customCommands.add(new CustomCommand(item.getString("name"), item.getString("command")));
            }
        } catch (Exception ignored) { customCommands.clear(); }
    }

    private void saveCustomCommands() {
        JSONArray data = new JSONArray();
        for (CustomCommand item : customCommands) {
            JSONObject row = new JSONObject();
            try { row.put("name", item.name); row.put("command", item.command); data.put(row); }
            catch (Exception ignored) { }
        }
        preferences.edit().putString("custom_commands", data.toString()).apply();
        renderCustomCommands();
    }

    private void renderCustomCommands() {
        if (customChips == null) return;
        customChips.removeAllViews();
        for (CustomCommand item : customCommands) {
            LinearLayout pair = new LinearLayout(this);
            pair.setGravity(Gravity.CENTER_VERTICAL);
            Button run = smallButton(item.name);
            run.setOnClickListener(v -> { input.setText(item.command); runCommand(); });
            pair.addView(run);
            Button delete = smallButton("×");
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Delete shortcut?").setMessage(item.name)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> { customCommands.remove(item); saveCustomCommands(); })
                .show());
            pair.addView(delete);
            customChips.addView(pair);
        }
        int[] c = palettes[Math.max(0, Math.min(palette, palettes.length - 1))];
        tintViews(customChips, c[1], c[3]);
    }

    private void showAddCustomDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), dp(2));
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Shortcut name");
        box.addView(name);
        EditText command = new EditText(this);
        command.setSingleLine(true);
        command.setHint("Termux command");
        box.addView(command);
        new AlertDialog.Builder(this).setTitle("Add custom command").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add", (dialog, which) -> {
                String label = name.getText().toString().trim();
                String value = command.getText().toString().trim();
                if (label.isEmpty() || value.isEmpty()) {
                    Toast.makeText(this, "Enter both a name and command.", Toast.LENGTH_SHORT).show();
                    return;
                }
                customCommands.add(new CustomCommand(label, value));
                saveCustomCommands();
                Toast.makeText(this, "Shortcut added. Swipe the top bar to see it.", Toast.LENGTH_SHORT).show();
            }).show();
    }

    private void connectTermux() {
        try { getPackageManager().getPackageInfo(TERMUX_PACKAGE, 0); }
        catch (PackageManager.NameNotFoundException e) { append("Termux is not installed. Install Termux first.\n\n"); return; }
        if (checkSelfPermission(RUN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            append("Approve 'Run commands in Termux environment' for termux-vision in Android App info.\n\n");
            requestPermissions(new String[]{RUN_PERMISSION}, 22);
            return;
        }
        append("Termux connection ready. Commands run with Termux permissions.\n\n");
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == 22 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            append("Termux command permission granted.\n\n");
        else if (request == 22) append("Permission not granted. Open Android Settings > Apps > termux-vision > Permissions.\n\n");
    }

    private void runCommand() {
        String command = input.getText().toString().trim();
        if (command.isEmpty()) return;
        if (commandRunning) { append("Wait for the current command to finish.\n"); return; }
        commandHandler.removeCallbacksAndMessages(null);
        input.setText("");
        append("$ " + command + "\n");
        if (command.equals("help")) {
            append("Commands run in Termux. Tap STYLE for appearance settings; use + CUSTOM to save shortcuts.\n\n");
            return;
        }
        if (command.equals("clear")) { output.setText(""); return; }
        if (command.equals("history")) { showHistory(); return; }
        if (command.equals("cd") || command.startsWith("cd ")) {
            String path = command.length() == 2 ? "/data/data/com.termux/files/home" : command.substring(3).trim();
            try {
                String resolved = path;
                if ("~".equals(resolved)) resolved = "/data/data/com.termux/files/home";
                else if (resolved.startsWith("~/")) resolved = "/data/data/com.termux/files/home/" + resolved.substring(2);
                File next = new File(resolved);
                if (!next.isAbsolute()) next = new File(currentDir, resolved);
                currentDir = next.getCanonicalFile();
                preferences.edit().putString("working_directory", currentDir.getAbsolutePath()).apply();
                updateDirectoryLabel();
                append("directory: " + currentDir + "\n");
            } catch (Exception e) { append("cd error: " + e.getMessage() + "\n"); }
            rememberCommand(command);
            return;
        }
        if (checkSelfPermission(RUN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            append("Termux permission required. Tap TERMUX and approve the permission first.\n");
            return;
        }
        rememberCommand(command);
        activeSessionToken = UUID.randomUUID().toString().replace("-", "");
        activeSessionReceivedLines = false;
        commandRunning = true;
        runButton.setEnabled(false);
        commandHandler.removeCallbacks(commandTimeout);
        commandHandler.postDelayed(commandTimeout, 120000L);
        append("[live output]\n");
        try {
            int id = executionIds.incrementAndGet();
            Intent callback = new Intent(this, TermuxResultService.class);
            callback.putExtra("session_token", activeSessionToken);
            int piFlags = PendingIntent.FLAG_ONE_SHOT;
            if (Build.VERSION.SDK_INT >= 31) piFlags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent resultIntent = PendingIntent.getService(this, id, callback, piFlags);
            String quote = Character.toString((char) 34);
            String script = "{\n" + command + "\n} 2>&1 | while IFS= read -r line || [ -n " + quote + "$line" + quote + " ]; do\n"
                + "/data/data/com.termux/files/usr/bin/am broadcast -n com.example.customterminal/.TermuxLogReceiver -a com.example.customterminal.TERMUX_LOG --es session_token " + activeSessionToken + " --es line " + quote + "$line" + quote + " >/dev/null 2>&1\n"
                + "printf '%s\\n' " + quote + "$line" + quote + "\n"
                + "done\ncommand_status=${PIPESTATUS[0]}\nexit " + quote + "$command_status" + quote;
            Intent intent = new Intent("com.termux.RUN_COMMAND");
            intent.setClassName(TERMUX_PACKAGE, "com.termux.app.RunCommandService");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", script});
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", currentDir.getAbsolutePath());
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            intent.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", "termux-vision command");
            intent.putExtra("com.termux.RUN_COMMAND_COMMAND_DESCRIPTION", "Command submitted from termux-vision");
            intent.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", resultIntent);
            startService(intent);
        } catch (Exception e) {
            append("Could not start Termux command: " + e.getMessage() + "\nCheck permission and allow-external-apps.\n");
            activeSessionToken = null;
            commandRunning = false;
            commandHandler.removeCallbacks(commandTimeout);
            runButton.setEnabled(true);
        }
    }

    private void append(String text) {
        output.append(text);
        CharSequence all = output.getText();
        if (all.length() > 16000) output.setText(all.subSequence(all.length() - 12000, all.length()));
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onDestroy() { super.onDestroy(); }
}
