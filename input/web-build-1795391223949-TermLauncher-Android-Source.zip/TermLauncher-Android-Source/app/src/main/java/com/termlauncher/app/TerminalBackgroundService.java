package com.termlauncher.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class TerminalBackgroundService extends Service {

    public static final String CHANNEL_ID = "termlauncher_session_channel";
    public static final int NOTIFICATION_ID = 2026;
    public static final String ACTION_STOP_SESSION = "com.termlauncher.app.ACTION_STOP_SESSION";
    public static final String ACTION_INCOMING_NOTIF = "com.termlauncher.app.ACTION_INCOMING_NOTIF";
    public static final String EXTRA_NOTIF_TITLE = "notif_title";
    public static final String EXTRA_NOTIF_TEXT = "notif_text";
    public static final String EXTRA_NOTIF_PKG = "notif_pkg";

    private static TerminalBackgroundService instance;
    private NotificationCallback callback;

    public interface NotificationCallback {
        void onNotificationReceived(String pkg, String title, String text);
        void onStopSessionRequested();
    }

    private final BroadcastReceiver controlReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            if (ACTION_STOP_SESSION.equals(intent.getAction())) {
                if (callback != null) {
                    callback.onStopSessionRequested();
                }
                stopForeground(true);
                stopSelf();
            } else if (ACTION_INCOMING_NOTIF.equals(intent.getAction())) {
                String pkg = intent.getStringExtra(EXTRA_NOTIF_PKG);
                String title = intent.getStringExtra(EXTRA_NOTIF_TITLE);
                String text = intent.getStringExtra(EXTRA_NOTIF_TEXT);
                if (callback != null) {
                    callback.onNotificationReceived(pkg, title, text);
                }
            }
        }
    };

    public static TerminalBackgroundService getInstance() {
        return instance;
    }

    public void setCallback(NotificationCallback cb) {
        this.callback = cb;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannel();
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_STOP_SESSION);
        filter.addAction(ACTION_INCOMING_NOTIF);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(controlReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(controlReceiver, filter);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP_SESSION.equals(intent.getAction())) {
            if (callback != null) {
                callback.onStopSessionRequested();
            }
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildPersistentNotification("Session active in background"));
        return START_STICKY;
    }

    private Notification buildPersistentNotification(String contentText) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent openPending = PendingIntent.getActivity(this, 10, openIntent, piFlags);

        Intent stopIntent = new Intent(this, TerminalBackgroundService.class);
        stopIntent.setAction(ACTION_STOP_SESSION);
        PendingIntent stopPending = PendingIntent.getService(this, 11, stopIntent, piFlags);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_terminal_app)
            .setContentTitle("TermLauncher")
            .setContentText(contentText)
            .setContentIntent(openPending)
            .setOngoing(true)
            .addAction(R.drawable.ic_close, "Stop Session", stopPending)
            .build();
    }

    public void updateNotificationText(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildPersistentNotification(text));
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                "TermLauncher Background Session",
                NotificationManager.IMPORTANCE_LOW
            );
            ch.setDescription("Keeps terminal session alive in background with Stop Session control");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(ch);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(controlReceiver);
        } catch (Exception ignored) {
        }
        if (instance == this) {
            instance = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
