package com.termlauncher.app;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

public class TermuxRepoManager {

    public interface OutputCallback {
        void onLog(String text);
        void onComplete(boolean success);
    }

    // Official Termux Main Online Repository Mirrors
    private static final String[] REPO_MIRRORS = {
        "https://packages-cf.termux.dev/apt/termux-main/",
        "https://packages.termux.dev/apt/termux-main/"
    };

    private final File rootDir;
    private final File prefixDir;
    private final File binDir;
    private final File cacheDir;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Maps package name -> relative Filename in repo
    private final Map<String, PackageMeta> packageIndex = new HashMap<>();

    public static class PackageMeta {
        public String name;
        public String version;
        public String filename;
        public String size;
        public String description;
    }

    public TermuxRepoManager(File appFilesDir) {
        this.rootDir = appFilesDir;
        this.prefixDir = new File(rootDir, "usr");
        this.binDir = new File(prefixDir, "bin");
        this.cacheDir = new File(rootDir, "cache");
        if (!binDir.exists()) binDir.mkdirs();
        if (!cacheDir.exists()) cacheDir.mkdirs();
    }

    public File getBinDir() {
        return binDir;
    }

    public File getPrefixDir() {
        return prefixDir;
    }

    private String getDeviceArch() {
        String[] abis = Build.SUPPORTED_ABIS;
        if (abis != null && abis.length > 0) {
            String primary = abis[0];
            if (primary.contains("arm64")) return "aarch64";
            if (primary.contains("armeabi")) return "arm";
            if (primary.contains("x86_64")) return "x86_64";
            if (primary.contains("x86")) return "i686";
        }
        return "aarch64";
    }

    private void postLog(OutputCallback cb, String msg) {
        mainHandler.post(() -> cb.onLog(msg + "\n"));
    }

    public void updateRepo(OutputCallback cb) {
        new Thread(() -> {
            String arch = getDeviceArch();
            String indexPath = "dists/stable/main/binary-" + arch + "/Packages.gz";
            postLog(cb, "Get:1 https://packages-cf.termux.dev/apt/termux-main stable InRelease");
            postLog(cb, "Get:2 https://packages-cf.termux.dev/apt/termux-main stable/main " + arch + " Packages");

            boolean fetched = false;
            for (String mirror : REPO_MIRRORS) {
                try {
                    URL url = new URL(mirror + indexPath);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestProperty("User-Agent", "Termux-APT/2.6 (Android)");

                    if (conn.getResponseCode() == 200) {
                        File outGz = new File(cacheDir, "Packages.gz");
                        try (InputStream in = conn.getInputStream();
                             FileOutputStream fos = new FileOutputStream(outGz)) {
                            byte[] buf = new byte[8192];
                            int len;
                            while ((len = in.read(buf)) != -1) {
                                fos.write(buf, 0, len);
                            }
                        }
                        parsePackagesGz(outGz);
                        fetched = true;
                        break;
                    }
                } catch (Exception e) {
                    postLog(cb, "Mirror warning (" + mirror + "): " + e.getMessage());
                }
            }

            if (fetched) {
                postLog(cb, "Fetched Termux " + arch + " index (" + packageIndex.size() + " packages available).");
                postLog(cb, "Reading package lists... Done");
                mainHandler.post(() -> cb.onComplete(true));
            } else {
                postLog(cb, "E: Failed to fetch Termux repository. Check internet connection.");
                mainHandler.post(() -> cb.onComplete(false));
            }
        }).start();
    }

    private void parsePackagesGz(File gzFile) throws Exception {
        packageIndex.clear();
        try (GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(gzFile));
             BufferedReader br = new BufferedReader(new InputStreamReader(gzis))) {
            String line;
            PackageMeta current = new PackageMeta();
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    if (current.name != null && current.filename != null) {
                        packageIndex.put(current.name, current);
                    }
                    current = new PackageMeta();
                } else if (line.startsWith("Package: ")) {
                    current.name = line.substring(9).trim();
                } else if (line.startsWith("Version: ")) {
                    current.version = line.substring(9).trim();
                } else if (line.startsWith("Filename: ")) {
                    current.filename = line.substring(10).trim();
                } else if (line.startsWith("Size: ")) {
                    current.size = line.substring(6).trim();
                } else if (line.startsWith("Description: ")) {
                    current.description = line.substring(13).trim();
                }
            }
        }
    }

    public void searchPackage(String query, OutputCallback cb) {
        if (packageIndex.isEmpty()) {
            postLog(cb, "Package index empty. Run 'pkg update' first.");
            cb.onComplete(false);
            return;
        }
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (PackageMeta meta : packageIndex.values()) {
            if (meta.name.contains(query) || (meta.description != null && meta.description.toLowerCase().contains(query.toLowerCase()))) {
                sb.append(meta.name).append("/stable ").append(meta.version).append("\n");
                if (meta.description != null) {
                    sb.append("  ").append(meta.description).append("\n");
                }
                count++;
                if (count >= 25) {
                    sb.append("... (showing first 25 matches)\n");
                    break;
                }
            }
        }
        if (count == 0) {
            postLog(cb, "No packages found matching '" + query + "'.");
        } else {
            postLog(cb, sb.toString());
        }
        cb.onComplete(true);
    }

    public void installPackage(String pkgName, OutputCallback cb) {
        new Thread(() -> {
            if (packageIndex.isEmpty()) {
                postLog(cb, "Updating Termux package index first...");
                // Synchronously fetch index if empty
                try {
                    String arch = getDeviceArch();
                    URL url = new URL(REPO_MIRRORS[0] + "dists/stable/main/binary-" + arch + "/Packages.gz");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    File outGz = new File(cacheDir, "Packages.gz");
                    try (InputStream in = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(outGz)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                    }
                    parsePackagesGz(outGz);
                } catch (Exception e) {
                    postLog(cb, "E: Unable to reach Termux repo: " + e.getMessage());
                    mainHandler.post(() -> cb.onComplete(false));
                    return;
                }
            }

            PackageMeta meta = packageIndex.get(pkgName);
            if (meta == null) {
                postLog(cb, "E: Unable to locate package " + pkgName);
                mainHandler.post(() -> cb.onComplete(false));
                return;
            }

            postLog(cb, "The following NEW packages will be installed:\n  " + meta.name + " (" + meta.version + ")");
            postLog(cb, "Get:1 " + REPO_MIRRORS[0] + meta.filename + " [" + meta.size + " B]");

            try {
                URL debUrl = new URL(REPO_MIRRORS[0] + meta.filename);
                HttpURLConnection conn = (HttpURLConnection) debUrl.openConnection();
                conn.setRequestProperty("User-Agent", "Termux-APT/2.6");
                File debFile = new File(cacheDir, meta.name + ".deb");

                try (InputStream in = new BufferedInputStream(conn.getInputStream());
                     FileOutputStream fos = new FileOutputStream(debFile)) {
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = in.read(buf)) != -1) {
                        fos.write(buf, 0, len);
                    }
                }

                postLog(cb, "Unpacking " + meta.name + " (" + meta.version + ") ...");
                extractDebPackage(debFile, cb);
                postLog(cb, "Setting up " + meta.name + " (" + meta.version + ") ... Done.");
                mainHandler.post(() -> cb.onComplete(true));
            } catch (Exception e) {
                postLog(cb, "E: Error installing " + pkgName + ": " + e.getMessage());
                mainHandler.post(() -> cb.onComplete(false));
            }
        }).start();
    }

    // Pure Java AR (.deb) extractor to unpack data.tar.* into app's usr/ prefix
    private void extractDebPackage(File debFile, OutputCallback cb) throws Exception {
        try (FileInputStream fis = new FileInputStream(debFile)) {
            byte[] magic = new byte[8];
            if (fis.read(magic) != 8) throw new Exception("Invalid .deb archive");

            while (true) {
                byte[] header = new byte[60];
                int read = fis.read(header);
                if (read < 60) break;

                String name = new String(header, 0, 16).trim();
                String sizeStr = new String(header, 48, 10).trim();
                long size = Long.parseLong(sizeStr);

                if (name.startsWith("data.tar")) {
                    File tarOut = new File(cacheDir, name);
                    try (FileOutputStream fos = new FileOutputStream(tarOut)) {
                        long remaining = size;
                        byte[] buf = new byte[8192];
                        while (remaining > 0) {
                            int toRead = (int) Math.min(buf.length, remaining);
                            int r = fis.read(buf, 0, toRead);
                            if (r <= 0) break;
                            fos.write(buf, 0, r);
                            remaining -= r;
                        }
                    }
                    // Extract tar using system tar if available
                    ProcessBuilder pb = new ProcessBuilder("tar", "-xf", tarOut.getAbsolutePath(), "-C", rootDir.getAbsolutePath());
                    Process p = pb.start();
                    p.waitFor();

                    // Make extracted binaries executable
                    File[] bins = binDir.listFiles();
                    if (bins != null) {
                        for (File b : bins) {
                            b.setExecutable(true, false);
                        }
                    }
                    break;
                } else {
                    long skipBytes = size + (size % 2);
                    fis.skip(skipBytes);
                }
            }
        }
    }
}
