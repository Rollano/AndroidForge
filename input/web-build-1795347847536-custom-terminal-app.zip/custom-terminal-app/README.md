# termux-vision (v5 — Safe App Launch)

Prevents startup crash/freeze when opening the app by guarding keyboard focus on `onCreate`, `PackageManager` queries, and `windowSoftInputMode`.
