# DVA Desktop — AndroidForge source project

A native Android controller for the DVA Termux desktop installer.

## What's included
- Premium dark / neon-green DVA interface.
- Branded splash screen before the main dashboard.
- Automatic Termux package detection (`com.termux`).
- If Termux is missing, the app explains the requirement and offers an official download link, a Later option, and Check Again.
- A second in-app download/check-again area remains available on the dashboard.
- XFCE and LXDE selection cards.
- Install, Start, Stop, and Check Status actions sent to Termux through `RUN_COMMAND`.

## Requirements
- Android 6.0+.
- Termux installed (official project releases): https://github.com/termux/termux-app/releases
- Termux:X11 Android app: https://github.com/termux/termux-x11/releases
- Internet connection and several GB of free storage.
- Termux external command access configured as described below.

## Enable Termux RUN_COMMAND
In Termux, edit `~/.termux/termux.properties` and set:

```properties
allow-external-apps = true
```

Then restart Termux. If Android displays a permission prompt, allow the requested access.

## Build with AndroidForge / Android Studio
Import this ZIP as an Android Gradle project. The project uses Android Gradle Plugin 8.6.1, compile SDK 35, min SDK 23, and Java source. Build a debug APK, install it, and test on your device.

## Important notes
- This ZIP is the Android source project, not a prebuilt APK.
- The app only controls the installer; Debian and XFCE/LXDE run inside Termux PRoot.
- Termux:X11 is a separate Android app and must be installed separately.
- The app checks whether the Termux package is installed. It cannot guarantee Termux is correctly configured or that the desktop installation will succeed.
- Device testing/build verification has not been performed in this environment.
