package com.dva.desktop;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 10, 8);
    private final int PANEL = Color.rgb(15, 25, 19);
    private final int GREEN = Color.rgb(65, 255, 145);
    private final int MUTED = Color.rgb(145, 169, 153);
    private String theme = "xfce";
    private LinearLayout root;
    private TextView termuxStatus, termuxDescription;
    private boolean termuxInstalled;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showSplash();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); return t;
    }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private LinearLayout column() { LinearLayout x = new LinearLayout(this); x.setOrientation(1); return x; }

    private void showSplash() {
        LinearLayout splash = column(); splash.setGravity(Gravity.CENTER); splash.setBackgroundColor(BG);
        TextView logo = text("DVA", 48, GREEN, true); logo.setLetterSpacing(.22f); logo.setGravity(Gravity.CENTER);
        splash.addView(logo);
        TextView line = text("DESKTOP", 12, Color.WHITE, true); line.setLetterSpacing(.38f); line.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(5); splash.addView(line,lp);
        TextView tagline = text("YOUR LINUX WORKSPACE ON ANDROID", 10, MUTED, true); tagline.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2); tp.topMargin=dp(18); splash.addView(tagline,tp);
        ProgressBar progress = new ProgressBar(this); progress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(GREEN));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(42),dp(42)); pp.topMargin=dp(34); splash.addView(progress,pp);
        setContentView(splash);
        new Handler().postDelayed(() -> {
            termuxInstalled = isPackageInstalled("com.termux");
            buildUI();
            if (!termuxInstalled) showTermuxDialog();
        }, 1250);
    }

    private boolean isPackageInstalled(String packageName) {
        try { getPackageManager().getPackageInfo(packageName, 0); return true; }
        catch (PackageManager.NameNotFoundException e) { return false; }
    }

    private void showTermuxDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Termux is required")
            .setMessage("DVA Desktop needs Termux to install and run the Linux desktop. Download Termux first, then return here and tap Check again.")
            .setCancelable(false)
            .setNegativeButton("LATER", (d,w) -> d.dismiss())
            .setNeutralButton("CHECK AGAIN", (d,w) -> {
                termuxInstalled = isPackageInstalled("com.termux"); updateTermuxStatus();
                if (termuxInstalled) buildUI(); else showTermuxDialog();
            })
            .setPositiveButton("DOWNLOAD TERMUX", (d,w) -> openUrl("https://github.com/termux/termux-app/releases"))
            .show();
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this,"Could not open download page.",Toast.LENGTH_LONG).show(); }
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        root = column(); root.setBackgroundColor(BG); pad(root,20,18,20,30); scroll.addView(root); setContentView(scroll);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = column(); TextView logo=text("DVA",25,GREEN,true); logo.setLetterSpacing(.16f); brand.addView(logo);
        TextView small=text("DESKTOP CONTROL CENTER",9,MUTED,true); small.setLetterSpacing(.12f); brand.addView(small);
        top.addView(brand); View spacer=new View(this); top.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        TextView ver=text("V1.1",10,GREEN,true); ver.setBackground(shape(PANEL,GREEN,30)); pad(ver,12,7,12,7); top.addView(ver); root.addView(top);

        LinearLayout hero=column(); hero.setBackground(shape(Color.rgb(12,31,19),Color.rgb(36,91,54),24)); pad(hero,19,21,19,20);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(24); root.addView(hero,hp);
        TextView eyebrow=text("LINUX • TERMUX • ANDROID",10,GREEN,true); eyebrow.setLetterSpacing(.14f); hero.addView(eyebrow);
        TextView headline=text("Build your\nmobile workstation.",29,Color.WHITE,true); pad(headline,0,12,0,7); hero.addView(headline);
        TextView desc=text("A guided Debian desktop setup, powered by Termux and Termux:X11.",13,MUTED,false); desc.setLineSpacing(dp(4),1f); hero.addView(desc);

        LinearLayout status=column(); status.setBackground(shape(PANEL,0,18)); pad(status,16,14,16,14);
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2); stp.topMargin=dp(15); root.addView(status,stp);
        termuxStatus=text("●  "+(termuxInstalled?"TERMUX DETECTED":"TERMUX NOT DETECTED"),12,termuxInstalled?GREEN:Color.rgb(255,190,90),true); status.addView(termuxStatus);
        termuxDescription=text(termuxInstalled?"Termux is installed. Ready for setup.":"Install Termux to enable desktop actions.",12,MUTED,false); pad(termuxDescription,0,6,0,0); status.addView(termuxDescription);
        if (!termuxInstalled) {
            TextView download=text("DOWNLOAD  ↗",11,GREEN,true); pad(download,0,12,0,0); status.addView(download);
            download.setOnClickListener(v -> openUrl("https://github.com/termux/termux-app/releases"));
            TextView check=text("I INSTALLED IT — CHECK AGAIN",10,Color.WHITE,true); pad(check,0,12,0,0); status.addView(check);
            check.setOnClickListener(v -> { termuxInstalled=isPackageInstalled("com.termux"); updateTermuxStatus(); if(termuxInstalled) buildUI(); else showTermuxDialog(); });
        }

        section("01  /  SELECT DESKTOP");
        LinearLayout cards=new LinearLayout(this); cards.setOrientation(0);
        LinearLayout xfce=choiceCard("XFCE","FEATURE RICH  •  CUSTOMIZABLE","xfce".equals(theme));
        LinearLayout lxde=choiceCard("LXDE","LIGHTWEIGHT  •  LOW RESOURCE","lxde".equals(theme));
        LinearLayout.LayoutParams c1=new LinearLayout.LayoutParams(0,-2,1); c1.rightMargin=dp(6); cards.addView(xfce,c1);
        LinearLayout.LayoutParams c2=new LinearLayout.LayoutParams(0,-2,1); c2.leftMargin=dp(6); cards.addView(lxde,c2); root.addView(cards);

        section("02  /  DESKTOP CONTROLS");
        addButton("INSTALL DESKTOP","Set up Debian and the selected desktop",GREEN,BG,()->run("install"));
        addButton("START DESKTOP","Launch your saved desktop session",PANEL,Color.WHITE,()->run("start"));
        addButton("STOP DESKTOP","Close the desktop session safely",PANEL,Color.WHITE,()->run("stop"));
        addButton("CHECK STATUS","Inspect your desktop installation",PANEL,Color.WHITE,()->run("status"));

        section("NEEDED BEFORE FIRST LAUNCH");
        TextView req=text("1. Termux (official GitHub build)\n2. Termux:X11 Android app\n3. Internet + several GB free storage\n4. Enable RUN_COMMAND access in Termux",12,MUTED,false); req.setLineSpacing(dp(5),1f); root.addView(req);
        TextView footer=text("DVA DESKTOP  /  MADE FOR ANDROID",9,MUTED,true); footer.setGravity(Gravity.CENTER); pad(footer,0,26,0,0); root.addView(footer);
    }

    private void updateTermuxStatus() { if(termuxStatus!=null){termuxStatus.setText("●  "+(termuxInstalled?"TERMUX DETECTED":"TERMUX NOT DETECTED"));termuxStatus.setTextColor(termuxInstalled?GREEN:Color.rgb(255,190,90));} }
    private void section(String s) { TextView t=text(s,11,GREEN,true); t.setLetterSpacing(.08f); pad(t,0,23,0,11); root.addView(t); }
    private LinearLayout choiceCard(String title,String desc,boolean active) {
        LinearLayout card=column(); card.setBackground(shape(active?Color.rgb(13,42,25):PANEL,active?GREEN:Color.rgb(35,53,41),18)); pad(card,14,17,12,16);
        TextView t=text(title,19,active?GREEN:Color.WHITE,true); card.addView(t);
        TextView d=text(desc,9,MUTED,true); pad(d,0,7,0,0); card.addView(d);
        TextView selected=text(active?"✓ SELECTED":"TAP TO SELECT",9,active?GREEN:MUTED,true); pad(selected,0,13,0,0); card.addView(selected);
        card.setOnClickListener(v->{theme=title.toLowerCase();buildUI();}); return card;
    }
    private void addButton(String title,String desc,int bg,int fg,Runnable action) {
        LinearLayout box=column(); box.setBackground(shape(bg,bg==GREEN?GREEN:Color.rgb(38,57,44),16)); pad(box,16,14,16,14);
        TextView a=text(title,13,fg,true); box.addView(a); TextView b=text(desc,11,bg==GREEN?Color.rgb(13,48,27):MUTED,false); pad(b,0,4,0,0); box.addView(b);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(8); root.addView(box,p); box.setOnClickListener(v->action.run());
    }
    private void run(String action) {
        termuxInstalled=isPackageInstalled("com.termux"); updateTermuxStatus();
        if(!termuxInstalled){showTermuxDialog();return;}
        String cmd="mkdir -p \"$HOME\"; curl -fsSL https://raw.githubusercontent.com/Rollano/Kali-Pocket/main/DVA-XFCE-Termux/dva-xfce-auto.sh -o \"$HOME/dva-xfce-auto.sh\" && chmod +x \"$HOME/dva-xfce-auto.sh\" && "+
            (action.equals("install")?"bash \"$HOME/dva-xfce-auto.sh\" install "+theme:"bash \"$HOME/dva-xfce-auto.sh\" "+action);
        try {
            Intent i=new Intent("com.termux.RUN_COMMAND"); i.setClassName("com.termux","com.termux.app.RunCommandService");
            i.putExtra("com.termux.RUN_COMMAND_PATH","/data/data/com.termux/files/usr/bin/bash");
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",new String[]{"-lc",cmd});
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR","/data/data/com.termux/files/home");
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND",false); startService(i);
            Toast.makeText(this,"Command sent to Termux. Check its session or notification.",Toast.LENGTH_LONG).show();
        } catch(Exception e) { Toast.makeText(this,"Unable to start Termux. Check RUN_COMMAND permission and setup.",Toast.LENGTH_LONG).show(); }
    }
}
