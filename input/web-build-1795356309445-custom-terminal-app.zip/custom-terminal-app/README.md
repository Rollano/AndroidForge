# termux-vision (v28 — Remove Neofetch Boot Banner & Echo Typed Commands in Terminal)

- Removes the ASCII `neofetch` boot animation so the terminal stays clean and uncluttered on launch.
- Echoes every submitted command (`formatShellPrompt(w) + " " + command`) directly into the terminal output log so typed commands are always clearly visible.
