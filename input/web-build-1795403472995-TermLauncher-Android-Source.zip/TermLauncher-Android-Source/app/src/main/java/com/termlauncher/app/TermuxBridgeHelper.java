package com.termlauncher.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Helper for Termux detection, auto-session triggers when granted/enabled,
 * and safe integration entry points without crashing on Android sandbox restrictions.
 */
public final class TermuxBridgeHelper {

    public static final String TERMUX_PACKAGE = "com.termux";
    public static final String TERMUX_USR_DIR = "/data/data/com.termux/files/usr";
    public static final String TERMUX_BIN_DIR = "/data/data/com.termux/files/usr/bin";
    public static final String TERMUX_HOME_DIR = "/data/data/com.termux/files/home";

    public static final String RUN_COMMAND_SERVICE_CLASS = "com.termux.app.RunCommandService";
    public static final String RUN_COMMAND_ACTION = "com.termux.RUN_COMMAND";
    public static final String PERMISSION_RUN_COMMAND = "com.termux.permission.RUN_COMMAND";

    private static final String PREFS_NAME = "termlauncher_termux_bridge";
    private static final String KEY_AUTO_SESSION_GRANTED = "auto_session_granted";
    private static final String KEY_AUTO_SESSION_COMMAND = "auto_session_command";

    private TermuxBridgeHelper() {
    }

    public static boolean isTermuxPackageInstalled(Context context) {
        if (context == null) return false;
        try {
            context.getPackageManager().getPackageInfo(TERMUX_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isRunCommandPermissionGranted(Context context) {
        if (context == null) return false;
        try {
            return context.checkSelfPermission(PERMISSION_RUN_COMMAND) == PackageManager.PERMISSION_GRANTED;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static void setAutoSessionGranted(Context context, boolean granted) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_AUTO_SESSION_GRANTED, granted).apply();
    }

    public static boolean isAutoSessionGranted(Context context) {
        if (context == null) return false;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_AUTO_SESSION_GRANTED, false);
    }

    public static void setAutoSessionCommand(Context context, String command) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_AUTO_SESSION_COMMAND, command == null ? "" : command).apply();
    }

    public static String getAutoSessionCommand(Context context) {
        if (context == null) return "";
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_AUTO_SESSION_COMMAND, "");
    }

    public static boolean isTermuxUsrReadable() {
        File usr = new File(TERMUX_USR_DIR);
        try {
            return usr.exists() && usr.canRead();
        } catch (SecurityException ignored) {
            return false;
        }
    }

    public static boolean isTermuxBinExecutable() {
        File bin = new File(TERMUX_BIN_DIR);
        try {
            return bin.exists() && bin.canExecute();
        } catch (SecurityException ignored) {
            return false;
        }
    }

    public static List<String> getReadableTermuxBinaries() {
        List<String> tools = new ArrayList<>();
        if (!isTermuxBinExecutable()) return tools;
        File binDir = new File(TERMUX_BIN_DIR);
        File[] files = binDir.listFiles();
        if (files == null) return tools;
        for (File f : files) {
            if (f != null && f.isFile() && f.canExecute()) {
                tools.add(f.getName());
            }
        }
        return tools;
    }

    public static Intent createLaunchTermuxIntent(Context context) {
        if (context == null) return null;
        try {
            return context.getPackageManager().getLaunchIntentForPackage(TERMUX_PACKAGE);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static Intent createRunCommandIntent(String command, String workdir, boolean background) {
        Intent intent = new Intent();
        intent.setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE_CLASS);
        intent.setAction(RUN_COMMAND_ACTION);
        intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/sh");
        if (command != null && !command.trim().isEmpty()) {
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-c", command});
        }
        if (workdir != null && !workdir.trim().isEmpty()) {
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", workdir);
        } else {
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME_DIR);
        }
        intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", background);
        return intent;
    }

    /**
     * Automatically starts a Termux session/command if Termux is installed
     * and auto-session access has been granted/enabled in the app.
     */
    public static boolean startSessionIfGranted(Context context, String optionalCommand, boolean background) {
        if (context == null) return false;
        if (!isAutoSessionGranted(context)) return false;
        if (!isTermuxPackageInstalled(context)) return false;

        String cmdToRun = (optionalCommand != null && !optionalCommand.trim().isEmpty())
            ? optionalCommand.trim()
            : getAutoSessionCommand(context);

        try {
            Intent runIntent = createRunCommandIntent(
                cmdToRun.isEmpty() ? "exec $SHELL -l" : cmdToRun,
                TERMUX_HOME_DIR,
                background
            );
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(runIntent);
            } else {
                context.startService(runIntent);
            }
            return true;
        } catch (SecurityException | IllegalStateException e) {
            // Fallback to opening Termux app session if background/service start is restricted
            Intent launchIntent = createLaunchTermuxIntent(context);
            if (launchIntent != null) {
                try {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launchIntent);
                    return true;
                } catch (Exception ignored) {
                }
            }
            return false;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static String buildEnvironmentSummary(Context context) {
        boolean installed = isTermuxPackageInstalled(context);
        boolean permGranted = isRunCommandPermissionGranted(context);
        boolean autoGranted = isAutoSessionGranted(context);
        boolean usrReadable = isTermuxUsrReadable();
        boolean binExec = isTermuxBinExecutable();
        int toolCount = getReadableTermuxBinaries().size();

        StringBuilder sb = new StringBuilder();
        sb.append("Termux Package Installed: ").append(installed ? "Yes" : "No").append("\n");
        sb.append("RUN_COMMAND Permission: ").append(permGranted ? "Granted" : "Not granted").append("\n");
        sb.append("Auto Termux Session: ").append(autoGranted ? "Enabled / Granted" : "Disabled").append("\n");
        sb.append("Termux USR Path: ").append(TERMUX_USR_DIR)
          .append(" (readable=").append(usrReadable).append(")\n");
        sb.append("Termux BIN Path: ").append(TERMUX_BIN_DIR)
          .append(" (executable=").append(binExec).append(", tools=").append(toolCount).append(")\n");
        sb.append("Termux HOME Path: ").append(TERMUX_HOME_DIR);
        return sb.toString();
    }

    public static Uri buildStorageShortcutUri() {
        return Uri.parse("content://com.android.externalstorage.documents/root/primary");
    }
}
