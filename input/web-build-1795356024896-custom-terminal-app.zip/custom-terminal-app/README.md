# termux-vision (v27 — Merge Duplicate `onResume()` cleanly)

- Removes the duplicate `onResume()` definition in `MainActivity.java` and calls `focusTerminalInput()` inside the existing `onResume()` method so the build compiles cleanly with typing/keyboard focus fixes intact.
