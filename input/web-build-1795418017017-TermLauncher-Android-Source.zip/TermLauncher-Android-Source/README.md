# TermLauncher v3.2 (`com.termlauncher.app`)

Includes:
- Terminal shell runner with pinch-to-zoom font sizing
- App Drawer listing launcher apps
- Built-in local Audio (`MediaPlayer`) and Video (`VideoView`) player via `MediaStore`
- Integrated `WebView` browser tab
- Build fixes (`gradle.properties` with AndroidX + nonTransitiveRClass, Java 17, clean resource attributes, single activity class)
