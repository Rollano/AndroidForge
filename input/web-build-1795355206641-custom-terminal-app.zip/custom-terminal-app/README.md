# termux-vision (v25 — Fixed `syncWindowUi()` Call in Root `su` Mode)

- Replaces `updatePromptAndStatus(w)` with `syncWindowUi()` in `MainActivity.java` so `v24`'s root `su` shell and root ADB command support compiles cleanly.
