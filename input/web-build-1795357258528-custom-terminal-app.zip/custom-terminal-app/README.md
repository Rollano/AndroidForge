# termux-vision (v31 — Fix drawerPanel Symbol in dispatchTouchEvent)

- Replaces `drawerContainer` with `drawerPanel` in `MainActivity.java` so `v30`'s tap-anywhere soft keyboard trigger compiles cleanly.
