package com.example.customterminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;

public class ToolsDrawerActivity extends Activity {
    public static final String EXTRA_ACTION = "tools_action";
    public static final String ACTION_STORAGE = "storage";
    public static final String ACTION_MEDIA = "media";
    public static final String ACTION_TERMUX = "termux";
    public static final String ACTION_NEW_WINDOW = "new_window";
    public static final String ACTION_UNLOCK = "unlock";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildFullScreenToolsView();
    }

    private void buildFullScreenToolsView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B1120);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(0xFF1E293B);
        header.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView title = new TextView(this);
        title.setText("TOOLS & PAGES (FULL SCREEN)");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(16);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        Button backBtn = new Button(this);
        backBtn.setText("BACK");
        backBtn.setTextSize(12);
        backBtn.setTextColor(0xFFFFFFFF);
        backBtn.setBackgroundColor(0xFF334155);
        backBtn.setOnClickListener(v -> finish());
        header.addView(backBtn, new LinearLayout.LayoutParams(-2, -2));

        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Dedicated full-screen drawer for pages, storage, media player, root (su), and terminal tools.");
        subtitle.setTextColor(0xFF94A3B8);
        subtitle.setTextSize(12.5f);
        subtitle.setPadding(dp(4), dp(10), dp(4), dp(8));
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        addToolButton(list, "Help Page", "Command reference for navigation, storage, media, root (su), and repos", () -> showFullPageDialog("Help Page", helpText()));
        addToolButton(list, "How To Use Page", "Step-by-step guide for prompt setup, /sdcard files, media playback, and su", () -> showFullPageDialog("How To Use Page", howToText()));
        addToolButton(list, "For Professional Use Only", "Authorized administration, root (su) safety, and operational guidelines", () -> showFullPageDialog("For Professional Use Only", proText()));
        addToolButton(list, "Browse Storage Files (/sdcard)", "Request storage access if needed and open /sdcard file explorer", () -> {
            ensureStorageAccess();
            finishWithAction(ACTION_STORAGE);
        });
        addToolButton(list, "Built-in Music & Video Player", "Pick an audio or video file and play it inside the terminal", () -> {
            ensureStorageAccess();
            finishWithAction(ACTION_MEDIA);
        });
        addToolButton(list, "Termux / Repo Status", "Inspect standalone prefix, Termux availability, and RUN_COMMAND status", () -> finishWithAction(ACTION_TERMUX));
        addToolButton(list, "+ New Terminal Window", "Create and switch to a new terminal window", () -> finishWithAction(ACTION_NEW_WINDOW));
        addToolButton(list, "Unlock / Kill Stuck Process", "Clear running lock and terminate hung child processes", () -> finishWithAction(ACTION_UNLOCK));

        setContentView(root);
    }

    private void addToolButton(LinearLayout parent, String label, String desc, final Runnable onClick) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(0xFF111827);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = dp(10);

        TextView titleTv = new TextView(this);
        titleTv.setText(label);
        titleTv.setTextColor(0xFF38BDF8);
        titleTv.setTextSize(14.5f);
        titleTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        card.addView(titleTv, new LinearLayout.LayoutParams(-1, -2));

        TextView descTv = new TextView(this);
        descTv.setText(desc);
        descTv.setTextColor(0xFFCBD5E1);
        descTv.setTextSize(12);
        LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(-1, -2);
        descParams.topMargin = dp(4);
        card.addView(descTv, descParams);

        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> onClick.run());
        parent.addView(card, cardParams);
    }

    private void finishWithAction(String action) {
        Intent data = new Intent();
        data.putExtra(EXTRA_ACTION, action);
        setResult(RESULT_OK, data);
        finish();
    }

    private void showFullPageDialog(String title, String body) {
        ScrollView sv = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(body);
        tv.setTextSize(13.5f);
        tv.setLineSpacing(0, 1.25f);
        tv.setPadding(dp(20), dp(14), dp(20), dp(14));
        tv.setTextIsSelectable(true);
        sv.addView(tv);

        new AlertDialog.Builder(this)
            .setTitle(title)
            .setView(sv)
            .setPositiveButton("Close", null)
            .show();
    }

    private void ensureStorageAccess() {
        if (Build.VERSION.SDK_INT >= 23) {
            ArrayList<String> perms = new ArrayList<>();
            perms.add("android.permission.READ_EXTERNAL_STORAGE");
            perms.add("android.permission.WRITE_EXTERNAL_STORAGE");
            if (Build.VERSION.SDK_INT >= 33) {
                perms.add("android.permission.READ_MEDIA_AUDIO");
                perms.add("android.permission.READ_MEDIA_VIDEO");
            }
            requestPermissions(perms.toArray(new String[0]), 55);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception ignored) { }
        }
    }

    private String helpText() {
        return
            "HELP & COMMAND REFERENCE\n" +
            "----------------------------------------\n\n" +
            "1. Terminal & Navigation:\n" +
            "   pwd                  Show current directory\n" +
            "   ls [path]            List files in current or target folder\n" +
            "   cd <dir>             Change directory (~ = home, /sdcard = storage)\n" +
            "   cat <file>           Read text file contents\n" +
            "   nano <file>          Edit or create text files\n" +
            "   mkdir <dir>          Create a new folder\n" +
            "   touch <file>         Create an empty file\n" +
            "   rm [-rf] <target>    Remove file or directory\n\n" +
            "2. Storage Explorer Commands:\n" +
            "   storage / sdcard     Open interactive storage file browser\n" +
            "   storage-grant        Request Android storage access permission\n" +
            "   ls /sdcard           List internal shared storage files\n\n" +
            "3. Built-in Terminal Media Player:\n" +
            "   media / player       Pick audio or video file from storage\n" +
            "   play <file>          Play music or video right inside terminal\n" +
            "   music <file.mp3>     Play audio file in embedded player\n" +
            "   video <file.mp4>     Play video inside terminal screen\n" +
            "   stopmedia            Stop and close embedded media player\n\n" +
            "4. Root (`su`) Commands (Rooted Devices Only):\n" +
            "   su                   Verify root UID/GID (`id`)\n" +
            "   su <command>         Run privileged shell command via `su -c`\n" +
            "   su -c \"<cmd>\"       Execute root command string\n\n" +
            "5. Repository & Termux Commands:\n" +
            "   repo select          Pick active package repository\n" +
            "   repo list            List packages in active repo\n" +
            "   repo install <pkg>   Download/install package\n" +
            "   setname <name>       Change prompt name (e.g. mark@terminal $)\n" +
            "   clear / unlock       Clear screen or unlock stuck command";
    }

    private String howToText() {
        return
            "HOW TO USE THIS TERMINAL APP\n" +
            "----------------------------------------\n\n" +
            "Step 1: Set Your Prompt Name\n" +
            "  - Enter your name on first launch or type: setname mark\n" +
            "  - Your prompt will display as: mark@terminal $\n\n" +
            "Step 2: Browse & Manage Storage Files\n" +
            "  - Type 'storage-grant' or open Tools & Pages to allow file access.\n" +
            "  - Use 'cd /sdcard' and 'ls' to inspect folders in shared storage.\n\n" +
            "Step 3: Play Music & Videos Inside the Terminal\n" +
            "  - Type 'play /sdcard/Music/song.mp3' or 'play /sdcard/Movies/clip.mp4'.\n" +
            "  - Playback controls (Play/Pause, Seekbar, Stop) appear in the terminal screen.\n\n" +
            "Step 4: Run Root Commands (`su`) on Rooted Devices\n" +
            "  - Type 'su id' or 'su ls -la /data' and approve superuser prompt.\n\n" +
            "Step 5: Install Packages via Repo or Termux\n" +
            "  - Type 'repo select', 'repo list', and 'repo install <pkg>'.";
    }

    private String proText() {
        return
            "FOR PROFESSIONAL USE ONLY\n" +
            "----------------------------------------\n\n" +
            "INTENDED AUDIENCE & AUTHORIZED ADMINISTRATION:\n" +
            "This terminal environment—including root (`su`) command execution, system file inspection, package repository management, and shell scripting—is designed strictly for qualified developers, system administrators, security researchers, and authorized device owners.\n\n" +
            "RESPONSIBLE USE GUIDELINES:\n" +
            "1. Only execute privileged (`su`) or file-modifying commands on devices you own or are authorized to manage.\n" +
            "2. Root (`su`) commands bypass Android sandbox protections; improper changes can cause bootloops or data loss.\n" +
            "3. Always back up important data before destructive commands (`rm -rf`) or root operations.\n" +
            "4. Comply with applicable laws and platform policies.";
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
