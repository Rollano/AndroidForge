# termux-vision (Fixed — Android Studio & AIDE Ready)

Terminal-like UI with wallpapers/themes that bridges commands to Termux via `RUN_COMMAND`.

## Build Instructions
- **Android Studio**: Extract the ZIP, click `File > Open`, select the `custom-terminal-app` folder, and let Gradle sync & build.
- **AIDE (Android IDE)**: Extract the ZIP to `/storage/emulated/0/AppProjects/custom-terminal-app`, open AIDE, select the project folder, and tap **Run**.

## Termux Requirements
1. Install Termux and set `allow-external-apps = true` in `~/.termux/termux.properties`.
2. Grant `Run commands in Termux environment` (`com.termux.permission.RUN_COMMAND`) to **termux-vision** in Android App Info.
