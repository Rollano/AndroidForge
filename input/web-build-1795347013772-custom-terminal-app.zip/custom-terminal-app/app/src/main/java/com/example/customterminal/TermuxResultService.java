package com.example.customterminal;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TermuxResultService extends Service {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(final Intent intent, int flags, final int startId) {
        executor.execute(() -> {
            try {
                handleResult(intent);
            } finally {
                stopSelf(startId);
            }
        });
        return START_NOT_STICKY;
    }

    private void handleResult(Intent intent) {
        if (intent == null) return;
        String token = intent.getStringExtra("session_token");
        Bundle result = intent.getBundleExtra("result");
        if (result == null) {
            MainActivity.receiveTermuxResult(token, "No result received. Check Termux and allow-external-apps.\n", -1);
            return;
        }
        String stdout = result.getString("stdout", "");
        String stderr = result.getString("stderr", "");
        int exit = result.getInt("exitCode", -1);
        String error = result.getString("errmsg", "");
        String text = stdout + (stderr.isEmpty() ? "" : stderr) + (error.isEmpty() ? "" : "Termux: " + error + "\n");
        MainActivity.receiveTermuxResult(token, text, exit);
    }

    @Override
    public void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
