# termux-vision (v18 — Repository Picker & Termux/Standalone Repo Presets)

- Adds `repo select` (interactive picker dialog) and `repo use <index|url>` so you can choose which repository is active.
- Includes built-in presets (`repo presets`) for Termux (`main`, `root`, `x11` aarch64 APT indexes), Debian Bookworm (`arm64`), and Standalone repo sources, plus `repo list all`.
